const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
process.env.BC_EXCEL = path.join(os.tmpdir(), `bc-test-${process.pid}.xlsx`);

const test = require('node:test');
const assert = require('node:assert');
const { creerServeur } = require('../backend/server');
const base = require('../database/base');
const { lireClasseur } = require('../database/moteur-excel/xlsx');
const { aujourdhui, ajouterJours } = require('../database/temps');

let serveur, adresse;
test.before(async () => {
  serveur = creerServeur();
  await new Promise((ok) => serveur.listen(0, ok));
  adresse = `http://localhost:${serveur.address().port}`;
});
test.after(() => {
  serveur.close();
  fs.rmSync(process.env.BC_EXCEL, { force: true });
  fs.rmSync(path.join(os.tmpdir(), 'sauvegardes'), { recursive: true, force: true });
});

function client() {
  let cookie = '';
  const appeler = async (methode, url, corps) => {
    const rep = await fetch(adresse + url, {
      method: methode,
      headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
      body: corps ? JSON.stringify(corps) : undefined,
    });
    const poser = rep.headers.get('set-cookie');
    if (poser) cookie = poser.split(';')[0].endsWith('=') ? '' : poser.split(';')[0];
    const type = rep.headers.get('content-type') || '';
    return { statut: rep.status, data: type.includes('json') ? await rep.json() : Buffer.from(await rep.arrayBuffer()), entetes: rep.headers };
  };
  return { appeler, effacerCookie: () => { cookie = ''; }, cookie: () => cookie };
}

const admin = client();
const api = admin.appeler;
const article = async (c, ref) => (await c.appeler('GET', '/api/produits')).data.find((p) => p.reference === ref);

async function utilisateurConnecte(nom, identifiant, role) {
  const cree = (await api('POST', '/api/utilisateurs', { nom, identifiant, role })).data;
  const c = client();
  const co = await c.appeler('POST', '/api/connexion', { identifiant, mot_de_passe: cree.mot_de_passe_temporaire });
  assert.strictEqual(co.statut, 200);
  assert.strictEqual(co.data.doit_changer_mdp, true);
  const ch = await c.appeler('POST', '/api/session/mot-de-passe', { ancien: cree.mot_de_passe_temporaire, nouveau: 'MotDePasse123' });
  assert.strictEqual(ch.statut, 200);
  return { c, id: cree.utilisateur.id };
}

test('avant configuration : rien n\'est accessible, la page de configuration est proposée', async () => {
  assert.strictEqual((await api('GET', '/api/info')).data.initialise, false);
  assert.strictEqual((await api('GET', '/api/clients')).statut, 401);
  assert.strictEqual((await api('GET', '/api/factures')).statut, 401);
  assert.strictEqual((await api('GET', '/api/export')).statut, 401);
});

test('configuration initiale : crée l\'administrateur, une seule fois', async () => {
  const faible = await api('POST', '/api/configuration-initiale', { nom: 'Chef', identifiant: 'chef', mot_de_passe: 'court' });
  assert.strictEqual(faible.statut, 400);
  const ok = await api('POST', '/api/configuration-initiale', { nom: 'Directeur BCS', identifiant: 'directeur', mot_de_passe: 'MotDePasse123' });
  assert.strictEqual(ok.statut, 201);
  assert.strictEqual(ok.data.role, 'Administrateur');
  assert.ok(ok.data.permissions.includes('admin.roles'));
  assert.strictEqual((await api('GET', '/api/info')).data.initialise, true);
  assert.strictEqual((await client().appeler('POST', '/api/configuration-initiale', { nom: 'Pirate', identifiant: 'pirate', mot_de_passe: 'MotDePasse123' })).statut, 409);
});

test('les mots de passe ne sont jamais stockés en clair, ni envoyés au navigateur', async () => {
  const brut = JSON.stringify(base.table('utilisateurs').tous());
  assert.ok(!brut.includes('MotDePasse123'));
  assert.match(base.table('utilisateurs').tous()[0].mot_de_passe, /^scrypt\$/);
  const liste = JSON.stringify((await api('GET', '/api/utilisateurs')).data);
  assert.ok(!liste.includes('scrypt') && !liste.includes('mot_de_passe'));
});

test('mauvais mot de passe refusé, puis blocage après 5 essais', async () => {
  const c = client();
  for (let i = 0; i < 5; i++) {
    assert.strictEqual((await c.appeler('POST', '/api/connexion', { identifiant: 'directeur', mot_de_passe: 'faux' + i })).statut, 401);
  }
  const bloque = await c.appeler('POST', '/api/connexion', { identifiant: 'directeur', mot_de_passe: 'MotDePasse123' });
  assert.strictEqual(bloque.statut, 429);
});

test('la session est un cookie HttpOnly, et la déconnexion la détruit', async () => {
  const c = client();
  const rep = await c.appeler('POST', '/api/connexion', { identifiant: 'inconnu', mot_de_passe: 'x' });
  assert.strictEqual(rep.statut, 401);
  const rep2 = await fetch(adresse + '/api/connexion', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ identifiant: 'directeur', mot_de_passe: 'MotDePasse123' }) });
  assert.strictEqual(rep2.status, 429);
  assert.strictEqual((await api('GET', '/api/session')).statut, 200);
  const temp = client();
  const cree = (await api('POST', '/api/utilisateurs', { nom: 'Temp', identifiant: 'temp', role: 'Lecture seule' })).data;
  const connexion = await fetch(adresse + '/api/connexion', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ identifiant: 'temp', mot_de_passe: cree.mot_de_passe_temporaire }) });
  const cookie = connexion.headers.get('set-cookie');
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Strict/);
  void temp;
});

test('un utilisateur au mot de passe temporaire ne peut rien faire avant de le changer', async () => {
  const cree = (await api('POST', '/api/utilisateurs', { nom: 'Nouveau', identifiant: 'nouveau', role: 'Gestionnaire' })).data;
  const c = client();
  await c.appeler('POST', '/api/connexion', { identifiant: 'nouveau', mot_de_passe: cree.mot_de_passe_temporaire });
  const bloque = await c.appeler('GET', '/api/clients');
  assert.strictEqual(bloque.statut, 403);
  assert.strictEqual(bloque.data.code, 'MDP_TEMPORAIRE');
  assert.strictEqual((await c.appeler('POST', '/api/session/mot-de-passe', { ancien: cree.mot_de_passe_temporaire, nouveau: 'court' })).statut, 400);
  assert.strictEqual((await c.appeler('POST', '/api/session/mot-de-passe', { ancien: cree.mot_de_passe_temporaire, nouveau: 'NouveauSecret77' })).statut, 200);
  assert.strictEqual((await c.appeler('GET', '/api/clients')).statut, 200);
});

test('un rôle limité n\'a accès qu\'à ce qu\'on lui a donné', async () => {
  const { c } = await utilisateurConnecte('Magali Magasin', 'magali', 'Magasinier');
  assert.strictEqual((await c.appeler('GET', '/api/produits')).statut, 200);
  assert.strictEqual((await c.appeler('GET', '/api/mouvements')).statut, 200);
  assert.strictEqual((await c.appeler('GET', '/api/clients')).statut, 403);
  assert.strictEqual((await c.appeler('GET', '/api/factures')).statut, 403);
  assert.strictEqual((await c.appeler('GET', '/api/utilisateurs')).statut, 403);
  assert.strictEqual((await c.appeler('GET', '/api/journal')).statut, 403);
  assert.strictEqual((await c.appeler('GET', '/api/export')).statut, 403);
  assert.strictEqual((await c.appeler('PUT', '/api/parametres', { nom: 'Pirate' })).statut, 403);
  const cam = await article(c, 'CAM-IP4');
  assert.strictEqual((await c.appeler('POST', '/api/stock/reception', { produit_id: cam.id, quantite: 1 })).statut, 201);
});

test('lecture seule : on consulte mais on ne modifie rien', async () => {
  const { c } = await utilisateurConnecte('Luc Lecteur', 'luc', 'Lecture seule');
  assert.strictEqual((await c.appeler('GET', '/api/factures')).statut, 200);
  assert.strictEqual((await c.appeler('GET', '/api/dashboard')).statut, 200);
  assert.strictEqual((await c.appeler('POST', '/api/clients', { nom: 'X' })).statut, 403);
  assert.strictEqual((await c.appeler('POST', '/api/factures', { client_id: 1 })).statut, 403);
  assert.strictEqual((await c.appeler('DELETE', '/api/produits/1')).statut, 403);
  assert.strictEqual((await c.appeler('POST', '/api/stock/sortie', { produit_id: 1, quantite: 1, motif: 'x' })).statut, 403);
});

test('sans le droit « coûts d\'achat », le coût n\'est jamais envoyé', async () => {
  const { c } = await utilisateurConnecte('Paul Commercial', 'paul', 'Commercial');
  const p = (await c.appeler('GET', '/api/produits')).data[0];
  assert.ok(!('cout' in p), 'le coût ne doit pas être visible');
  const dash = (await c.appeler('GET', '/api/dashboard'));
  assert.strictEqual(dash.statut, 403);
  const complet = (await api('GET', '/api/produits')).data[0];
  assert.ok('cout' in complet);
});

test('créer un rôle sur mesure : les droits impliqués sont ajoutés, le rôle système est intouchable', async () => {
  const role = (await api('POST', '/api/roles', { nom: 'Caissier', description: 'Encaisse', permissions: ['paiements.enregistrer'] })).data;
  assert.ok(role.permissions.includes('paiements.voir') && role.permissions.includes('factures.voir'));
  assert.ok(!role.permissions.includes('factures.creer'));
  assert.strictEqual((await api('POST', '/api/roles', { nom: 'caissier', permissions: [] })).statut, 400);
  const sys = (await api('GET', '/api/roles')).data.find((r) => r.systeme);
  assert.strictEqual((await api('PUT', `/api/roles/${sys.id}`, { nom: 'Admin2', permissions: [] })).statut, 409);
  assert.strictEqual((await api('DELETE', `/api/roles/${sys.id}`)).statut, 409);
  const utilise = (await api('GET', '/api/roles')).data.find((r) => r.nom === 'Magasinier');
  assert.strictEqual((await api('DELETE', `/api/roles/${utilise.id}`)).statut, 409);
  assert.strictEqual((await api('DELETE', `/api/roles/${role.id}`)).statut, 200);
});

test('changer le rôle ou désactiver un utilisateur s\'applique immédiatement', async () => {
  const { c, id } = await utilisateurConnecte('Rita Rôle', 'rita', 'Gestionnaire');
  assert.strictEqual((await c.appeler('GET', '/api/clients')).statut, 200);
  const u = (await api('GET', '/api/utilisateurs')).data.find((x) => x.id === id);
  await api('PUT', `/api/utilisateurs/${id}`, { nom: u.nom, identifiant: u.identifiant, role: 'Magasinier' });
  assert.strictEqual((await c.appeler('GET', '/api/clients')).statut, 403);
  await api('POST', `/api/utilisateurs/${id}/activation`, { actif: false });
  assert.strictEqual((await c.appeler('GET', '/api/produits')).statut, 401);
  const retour = await client().appeler('POST', '/api/connexion', { identifiant: 'rita', mot_de_passe: 'MotDePasse123' });
  assert.strictEqual(retour.statut, 401);
});

test('impossible de s\'enfermer dehors : il reste toujours un administrateur actif', async () => {
  const moi = (await api('GET', '/api/session')).data;
  assert.strictEqual((await api('POST', `/api/utilisateurs/${moi.id}/activation`, { actif: false })).statut, 409);
  assert.strictEqual((await api('PUT', `/api/utilisateurs/${moi.id}`, { nom: moi.nom, identifiant: moi.identifiant, role: 'Lecture seule' })).statut, 409);
});

test('réinitialiser un mot de passe : nouvel accès temporaire, anciennes sessions coupées', async () => {
  const { c, id } = await utilisateurConnecte('Omar Oubli', 'omar', 'Gestionnaire');
  const reset = (await api('POST', `/api/utilisateurs/${id}/mot-de-passe`)).data;
  assert.ok(reset.mot_de_passe_temporaire.length >= 8);
  assert.strictEqual((await c.appeler('GET', '/api/clients')).statut, 401);
  assert.strictEqual((await client().appeler('POST', '/api/connexion', { identifiant: 'omar', mot_de_passe: 'MotDePasse123' })).statut, 401);
  const nouveau = client();
  const co = await nouveau.appeler('POST', '/api/connexion', { identifiant: 'omar', mot_de_passe: reset.mot_de_passe_temporaire });
  assert.strictEqual(co.data.doit_changer_mdp, true);
});

test('une requête venant d\'un autre site est refusée', async () => {
  const rep = await fetch(adresse + '/api/clients', {
    method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'http://site-malveillant.example' },
    body: JSON.stringify({ nom: 'X' }),
  });
  assert.strictEqual(rep.status, 403);
});

let compta, factureId, stockCam0;

test('brouillon : pas de numéro, pas d\'effet sur le stock ; modifiable', async () => {
  compta = (await utilisateurConnecte('Clara Comptable', 'clara', 'Comptable')).c;
  const cam = await article(admin, 'CAM-IP4');
  stockCam0 = cam.stock;
  const pose = await article(admin, 'POSE-CAM');
  const rep = await compta.appeler('POST', '/api/factures', {
    client_id: 1, date_facture: '2026-10-14', tva: 18, conditions: 30,
    lignes: [{ produit_id: cam.id, quantite: 2, prix_unitaire: 65000 }, { produit_id: pose.id, quantite: 1, prix_unitaire: 25000 }],
  });
  assert.strictEqual(rep.statut, 201);
  assert.strictEqual(rep.data.statut, 'brouillon');
  assert.strictEqual(rep.data.numero, '');
  assert.strictEqual(rep.data.total_ht, 155000);
  assert.strictEqual(rep.data.total_ttc, 182900);
  factureId = rep.data.id;
  assert.strictEqual((await article(admin, 'CAM-IP4')).stock, stockCam0);

  const modif = await compta.appeler('PUT', `/api/factures/${factureId}`, {
    client_id: 1, date_facture: '2026-10-14', tva: 18, conditions: 30, lignes: [{ produit_id: cam.id, quantite: 3, prix_unitaire: 65000 }],
  });
  assert.strictEqual(modif.data.total_ht, 195000);
});

test('validation : numéro définitif, échéance, sortie de stock, non modifiable ensuite', async () => {
  const v = await compta.appeler('POST', `/api/factures/${factureId}/valider`);
  assert.strictEqual(v.statut, 200);
  assert.strictEqual(v.data.numero, 'FAC-2026-0001');
  assert.strictEqual(v.data.statut, 'validée');
  assert.strictEqual(v.data.date_echeance, '2026-11-13');
  assert.strictEqual(v.data.paiement, 'impayée');
  assert.strictEqual((await article(admin, 'CAM-IP4')).stock, stockCam0 - 3);
  assert.strictEqual((await compta.appeler('PUT', `/api/factures/${factureId}`, { client_id: 1 })).statut, 409);
  assert.strictEqual((await compta.appeler('DELETE', `/api/factures/${factureId}`)).statut, 403);
  assert.strictEqual((await api('DELETE', `/api/factures/${factureId}`)).statut, 409);
  const histo = (await compta.appeler('GET', `/api/factures/${factureId}`)).data.historique.map((h) => h.action);
  assert.ok(histo.includes('Création') && histo.includes('Validation'));
});

test('paiements partiels puis solde ; pas de surpaiement', async () => {
  const p1 = await compta.appeler('POST', `/api/factures/${factureId}/paiements`, { montant: 100000, mode: 'Virement', date_paiement: '2026-10-20' });
  assert.strictEqual(p1.statut, 201);
  assert.strictEqual(p1.data.paiement, 'partielle');
  assert.strictEqual(p1.data.reste, 130100);
  assert.strictEqual((await compta.appeler('POST', `/api/factures/${factureId}/paiements`, { montant: 999999 })).statut, 409);
  const p2 = await compta.appeler('POST', `/api/factures/${factureId}/paiements`, { montant: 130100, mode: 'Mobile Money' });
  assert.strictEqual(p2.data.paiement, 'payée');
  assert.strictEqual(p2.data.reste, 0);
  assert.strictEqual((await compta.appeler('POST', `/api/factures/${factureId}/annuler`)).statut, 409);
  assert.strictEqual((await compta.appeler('GET', '/api/paiements')).data.length, 2);
});

test('annuler une facture : le stock est remis (après suppression des paiements)', async () => {
  for (const p of (await compta.appeler('GET', '/api/paiements')).data) {
    assert.strictEqual((await compta.appeler('DELETE', `/api/paiements/${p.id}`)).statut, 200);
  }
  const a = await compta.appeler('POST', `/api/factures/${factureId}/annuler`);
  assert.strictEqual(a.data.statut, 'annulée');
  assert.strictEqual((await article(admin, 'CAM-IP4')).stock, stockCam0);
  assert.strictEqual(a.data.numero, 'FAC-2026-0001');
});

test('validation refusée si le stock est insuffisant (et rien n\'est modifié)', async () => {
  const cam = await article(admin, 'CAM-IP4');
  const b = (await compta.appeler('POST', '/api/factures', { client_id: 1, date_facture: '2026-10-14', tva: 18, lignes: [{ produit_id: cam.id, quantite: 999, prix_unitaire: 1 }] })).data;
  const v = await compta.appeler('POST', `/api/factures/${b.id}/valider`);
  assert.strictEqual(v.statut, 409);
  assert.match(v.data.erreur, /Stock insuffisant/);
  assert.strictEqual((await compta.appeler('GET', `/api/factures/${b.id}`)).data.statut, 'brouillon');
  await api('DELETE', `/api/factures/${b.id}`);
});

test('un commercial ne voit que ses propres factures et ne peut pas valider', async () => {
  const { c } = await utilisateurConnecte('Sam Commercial', 'sam', 'Commercial');
  const cam = await article(admin, 'CAM-IP4');
  const mienne = (await c.appeler('POST', '/api/factures', { client_id: 1, date_facture: '2026-10-15', tva: 18, lignes: [{ produit_id: cam.id, quantite: 1, prix_unitaire: 65000 }] })).data;
  assert.strictEqual((await c.appeler('POST', `/api/factures/${mienne.id}/valider`)).statut, 403);
  assert.strictEqual((await c.appeler('POST', '/api/factures', { client_id: 1, date_facture: '2026-10-15', tva: 18, valider: true, lignes: [{ produit_id: cam.id, quantite: 1, prix_unitaire: 65000 }] })).statut, 403);
  assert.strictEqual((await c.appeler('GET', '/api/factures')).data.length, 1);
  assert.strictEqual((await compta.appeler('GET', '/api/factures')).data.length >= 2, true);
  const autre = (await compta.appeler('GET', '/api/factures')).data.find((f) => f.id !== mienne.id);
  assert.strictEqual((await c.appeler('GET', `/api/factures/${autre.id}`)).statut, 404);
  assert.strictEqual((await c.appeler('DELETE', `/api/factures/${mienne.id}`)).statut, 403);
});

test('réception avec coût moyen, sortie motivée, inventaire physique', async () => {
  const lec = await article(admin, 'LEC-BIO');
  const r = (await api('POST', '/api/stock/reception', { produit_id: lec.id, quantite: 5, cout_unitaire: 95000, fournisseur: 'Dakar Sécurité', reference: 'BL-77' })).data;
  assert.strictEqual(r.stock, 10);
  assert.strictEqual(r.cout, 90000);
  assert.strictEqual((await api('POST', '/api/stock/sortie', { produit_id: lec.id, quantite: 1, motif: '' })).statut, 400);
  assert.strictEqual((await api('POST', '/api/stock/sortie', { produit_id: lec.id, quantite: 99, motif: 'casse' })).statut, 409);
  assert.strictEqual((await api('POST', '/api/stock/sortie', { produit_id: lec.id, quantite: 2, motif: 'Casse au transport' })).data.stock, 8);
  assert.strictEqual((await api('POST', '/api/stock/inventaire', { produit_id: lec.id, quantite_reelle: 8 })).statut, 400);
  assert.strictEqual((await api('POST', '/api/stock/inventaire', { produit_id: lec.id, quantite_reelle: 7 })).data.stock, 7);
  const mv = (await api('GET', `/api/mouvements?produit_id=${lec.id}`)).data.map((m) => m.type);
  assert.deepStrictEqual(mv, ['Inventaire', 'Sortie', 'Réception']);
  assert.strictEqual((await api('POST', '/api/stock/reception', { produit_id: (await article(admin, 'POSE-CAM')).id, quantite: 1 })).statut, 409);
});

test('le stock ne se modifie pas directement depuis la fiche article', async () => {
  const dec = await article(admin, 'DET-FUM');
  await api('PUT', `/api/produits/${dec.id}`, { ...dec, stock: 999 });
  assert.strictEqual((await article(admin, 'DET-FUM')).stock, dec.stock);
});

test('supprimer un client (refusé s\'il a des factures) et un article (factures intactes)', async () => {
  const cli = (await api('POST', '/api/clients', { nom: 'Hôtel Teranga' })).data;
  const sir = await article(admin, 'SIR-EXT');
  const f = (await api('POST', '/api/factures', { client_id: cli.id, date_facture: '2026-10-16', tva: 18, valider: true, lignes: [{ produit_id: sir.id, quantite: 2, prix_unitaire: 22000 }] })).data;
  assert.strictEqual((await api('DELETE', `/api/clients/${cli.id}`)).statut, 409);
  assert.strictEqual((await api('DELETE', `/api/produits/${sir.id}`)).statut, 200);
  const apres = (await api('GET', `/api/factures/${f.id}`)).data;
  assert.strictEqual(apres.lignes[0].designation, 'Sirène extérieure flash');
  assert.strictEqual(apres.total_ht, 44000);
  assert.strictEqual((await api('POST', '/api/clients', { nom: 'À supprimer' })).statut, 201);
  const jetable = (await api('GET', '/api/clients')).data.find((c) => c.nom === 'À supprimer');
  assert.strictEqual((await api('DELETE', `/api/clients/${jetable.id}`)).statut, 200);
});

test('réglages : modification validée, catégories gérées', async () => {
  assert.strictEqual((await api('PUT', '/api/parametres', { tvaParDefaut: 250 })).statut, 400);
  const p = (await api('PUT', '/api/parametres', { adresse: 'Cité Keur Gorgui, Dakar', conditionsParDefaut: 15 })).data;
  assert.strictEqual(p.adresse, 'Cité Keur Gorgui, Dakar');
  assert.strictEqual((await api('GET', '/api/parametres')).data.conditionsParDefaut, 15);
  const cat = (await api('POST', '/api/categories', { nom: 'Domotique' })).data;
  const ren = await api('PUT', `/api/categories/${cat.id}`, { nom: 'Maison connectée' });
  assert.strictEqual(ren.data.nom, 'Maison connectée');
  assert.strictEqual((await api('DELETE', `/api/categories/${(await api('GET', '/api/categories')).data.find((c) => c.nom === 'Vidéosurveillance').id}`)).statut, 409);
  assert.strictEqual((await api('DELETE', `/api/categories/${cat.id}`)).statut, 200);
});

test('l\'export Excel n\'inclut ni utilisateurs, ni rôles, ni journal', async () => {
  const rep = await api('GET', '/api/export');
  assert.strictEqual(rep.statut, 200);
  assert.strictEqual(rep.data.subarray(0, 2).toString(), 'PK');
  const feuilles = Object.keys(lireClasseur(rep.data));
  assert.ok(feuilles.includes('Factures') && feuilles.includes('Paiements') && feuilles.includes('Produits'));
  for (const interne of ['Utilisateurs', 'Roles', 'Journal']) assert.ok(!feuilles.includes(interne), interne + ' ne doit pas être exporté');
  assert.strictEqual((await compta.appeler('GET', '/api/export')).statut, 200);
});

test('le journal retrace qui a fait quoi', async () => {
  const j = (await api('GET', '/api/journal?limite=500')).data;
  const actions = new Set(j.entrees.map((e) => e.action));
  for (const a of ['Connexion', 'Échec de connexion', 'Création', 'Validation', 'Paiement', 'Annulation', 'Mouvement de stock', 'Export', 'Suppression']) {
    assert.ok(actions.has(a), `action manquante au journal : ${a}`);
  }
  const validation = j.entrees.find((e) => e.action === 'Validation' && e.objet === 'Facture FAC-2026-0001');
  assert.strictEqual(validation.utilisateur, 'Clara Comptable');
  assert.strictEqual((await api('GET', '/api/journal?utilisateur=Clara%20Comptable')).data.entrees.every((e) => e.utilisateur === 'Clara Comptable'), true);
});

test('le classeur Excel contient tout, et survit à un rechargement', async () => {
  const avant = (await api('GET', '/api/factures')).data.length;
  base.recharger();
  assert.strictEqual((await api('GET', '/api/factures')).data.length, avant);
  const feuilles = lireClasseur(fs.readFileSync(process.env.BC_EXCEL));
  assert.deepStrictEqual(Object.keys(feuilles), ['Parametres', 'Categories', 'Clients', 'Produits', 'Devis', 'Lignes_Devis', 'Factures', 'Lignes_Facture', 'Paiements', 'Tranches_Paiement', 'Mouvements_Stock', 'Roles', 'Utilisateurs', 'Journal']);
  assert.ok(feuilles.Utilisateurs.length > 5);
});

test('sauvegarde quotidienne : une seule copie par jour', () => {
  const sauvegarde = require('../outils/sauvegarde');
  const dossier = path.join(path.dirname(process.env.BC_EXCEL), 'sauvegardes');
  fs.rmSync(dossier, { recursive: true, force: true });
  assert.ok(sauvegarde.sauvegardeQuotidienne());
  assert.strictEqual(sauvegarde.sauvegardeQuotidienne(), null);
  fs.rmSync(dossier, { recursive: true, force: true });
});

test('devis : numérotation, totaux, validité, et chacun ne voit que les siens', async () => {
  const { c: sam } = await utilisateurConnecte('Awa Commerciale', 'awa', 'Commercial');
  const { c: ben } = await utilisateurConnecte('Ben Commercial', 'ben', 'Commercial');
  const cam = await article(admin, 'CAM-IP4');
  const dateAncienne = ajouterJours(aujourdhui(), -40);
  const corps = { client_id: 1, date_devis: dateAncienne, validite_jours: 15, tva: 18, notes: 'Livraison sous 5 jours',
    lignes: [{ produit_id: cam.id, quantite: 4, prix_unitaire: 65000 }] };
  const rep = await sam.appeler('POST', '/api/devis', corps);
  assert.strictEqual(rep.statut, 201);
  assert.strictEqual(rep.data.numero, `DEV-${dateAncienne.slice(0, 4)}-0001`);
  assert.strictEqual(rep.data.statut, 'brouillon');
  assert.strictEqual(rep.data.total_ttc, 306800);
  assert.strictEqual(rep.data.date_validite, ajouterJours(dateAncienne, 15));
  assert.strictEqual(rep.data.expire, true);
  assert.strictEqual((await sam.appeler('GET', '/api/devis')).data.length, 1);
  assert.strictEqual((await ben.appeler('GET', '/api/devis')).data.length, 0);
  assert.strictEqual((await ben.appeler('GET', `/api/devis/${rep.data.id}`)).statut, 404);
  assert.strictEqual((await admin.appeler('GET', '/api/devis')).data.length >= 1, true);
  assert.strictEqual((await sam.appeler('POST', '/api/devis', { ...corps, lignes: [] })).statut, 400);
  assert.strictEqual((await sam.appeler('POST', '/api/devis', { ...corps, date_validite: ajouterJours(dateAncienne, -1) })).statut, 400);
  assert.strictEqual((await sam.appeler('GET', '/api/devis')).data[0].client_nom.length > 0, true);
});

test('devis : un devis ne touche pas au stock ; cycle brouillon → envoyé → accepté → facturé', async () => {
  const sam = client();
  const cree = (await api('POST', '/api/utilisateurs', { nom: 'Eve Commerciale', identifiant: 'eve', role: 'Commercial' })).data;
  await sam.appeler('POST', '/api/connexion', { identifiant: 'eve', mot_de_passe: cree.mot_de_passe_temporaire });
  await sam.appeler('POST', '/api/session/mot-de-passe', { ancien: cree.mot_de_passe_temporaire, nouveau: 'MotDePasse123' });

  const cam = await article(admin, 'CAM-IP4');
  const stock0 = cam.stock;
  const d = (await sam.appeler('POST', '/api/devis', { client_id: 1, date_devis: aujourdhui(), tva: 18, lignes: [{ produit_id: cam.id, quantite: 2, prix_unitaire: 60000 }] })).data;
  assert.strictEqual(d.expire, false);
  assert.strictEqual((await article(admin, 'CAM-IP4')).stock, stock0);

  assert.strictEqual((await sam.appeler('POST', `/api/devis/${d.id}/statut`, { statut: 'facturé' })).statut, 409);
  assert.strictEqual((await sam.appeler('POST', `/api/devis/${d.id}/statut`, { statut: 'envoyé' })).data.statut, 'envoyé');
  const modif = await sam.appeler('PUT', `/api/devis/${d.id}`, { client_id: 1, date_devis: aujourdhui(), tva: 18, lignes: [{ produit_id: cam.id, quantite: 3, prix_unitaire: 60000 }] });
  assert.strictEqual(modif.data.total_ht, 180000);
  assert.strictEqual((await sam.appeler('POST', `/api/devis/${d.id}/statut`, { statut: 'accepté' })).data.statut, 'accepté');
  assert.strictEqual((await sam.appeler('PUT', `/api/devis/${d.id}`, { client_id: 1, date_devis: aujourdhui(), tva: 18, lignes: [{ produit_id: cam.id, quantite: 9, prix_unitaire: 1 }] })).statut, 409);

  const f = await sam.appeler('POST', `/api/devis/${d.id}/facturer`);
  assert.strictEqual(f.statut, 200);
  assert.strictEqual(f.data.devis.statut, 'facturé');
  assert.strictEqual(f.data.facture.statut, 'brouillon');
  assert.strictEqual(f.data.facture.total_ht, 180000);
  assert.strictEqual(f.data.devis.facture.id, f.data.facture.id);
  assert.strictEqual((await article(admin, 'CAM-IP4')).stock, stock0);
  assert.strictEqual((await sam.appeler('GET', '/api/factures')).data.some((x) => x.id === f.data.facture.id), true);
  assert.strictEqual((await sam.appeler('POST', `/api/devis/${d.id}/facturer`)).statut, 409);
  assert.strictEqual((await sam.appeler('DELETE', `/api/devis/${d.id}`)).statut, 403);
  assert.strictEqual((await api('DELETE', `/api/devis/${d.id}`)).statut, 409);
  const histo = (await api('GET', `/api/factures/${f.data.facture.id}`)).data.historique.map((h) => h.action);
  assert.ok(histo.includes('Conversion'));
});

test('devis : refus, remise en brouillon, suppression ; sans le droit, rien', async () => {
  const cam = await article(admin, 'CAM-IP4');
  const d = (await api('POST', '/api/devis', { client_id: 1, date_devis: aujourdhui(), tva: 18, lignes: [{ produit_id: cam.id, quantite: 1, prix_unitaire: 65000 }] })).data;
  assert.strictEqual((await api('POST', `/api/devis/${d.id}/statut`, { statut: 'refusé' })).data.statut, 'refusé');
  assert.strictEqual((await api('POST', `/api/devis/${d.id}/facturer`)).statut, 409);
  assert.strictEqual((await api('POST', `/api/devis/${d.id}/statut`, { statut: 'brouillon' })).data.statut, 'brouillon');
  assert.strictEqual((await api('DELETE', `/api/devis/${d.id}`)).statut, 200);
  assert.strictEqual((await api('GET', `/api/devis/${d.id}`)).statut, 404);

  const { c: mag } = await utilisateurConnecte('Max Magasin', 'max', 'Magasinier');
  assert.strictEqual((await mag.appeler('GET', '/api/devis')).statut, 403);
  const { c: lect } = await utilisateurConnecte('Lea Lecture', 'lea', 'Lecture seule');
  assert.strictEqual((await lect.appeler('GET', '/api/devis')).statut, 200);
  assert.strictEqual((await lect.appeler('POST', '/api/devis', { client_id: 1 })).statut, 403);
  const dash = (await api('GET', '/api/dashboard')).data;
  assert.ok(dash.devis && dash.devis.a_facturer.nb === 0);
});


test('facture par tranches : échéancier, paiements successifs jusqu\'au solde, retards par tranche', async () => {
  const pose = await article(admin, 'POSE-CAM');
  const cli = (await api('POST', '/api/clients', { nom: 'Chantier Almadies' })).data;
  const debut = ajouterJours(aujourdhui(), -40);
  const f = (await api('POST', '/api/factures', {
    client_id: cli.id, date_facture: debut, tva: 18, valider: true,
    lignes: [{ produit_id: pose.id, quantite: 2, prix_unitaire: 65000 }],
    tranches: [
      { libelle: 'Acompte', pourcentage: 30, delai_jours: 0 },
      { libelle: 'Mi-chantier', pourcentage: 40, delai_jours: 30 },
      { libelle: 'Solde', pourcentage: 30, delai_jours: 60 },
    ],
  })).data;

  assert.strictEqual(f.total_ttc, 153400);
  assert.deepStrictEqual(f.tranches.map((t) => t.montant), [46020, 61360, 46020]);
  assert.strictEqual(f.date_echeance, ajouterJours(debut, 60));
  assert.strictEqual(f.nb_tranches, 3);
  assert.strictEqual(f.en_retard, true);
  assert.strictEqual(f.montant_en_retard, 107380);
  assert.strictEqual(f.prochaine_tranche.libelle, 'Acompte');

  const p1 = (await api('POST', `/api/factures/${f.id}/paiements`, { montant: 50000, mode: 'Espèces' })).data;
  assert.strictEqual(p1.paiement, 'partielle');
  assert.deepStrictEqual(p1.tranches.map((t) => t.statut), ['payée', 'partielle', 'à payer']);
  assert.strictEqual(p1.tranches[1].reste, 57380);
  assert.strictEqual(p1.tranches_payees, 1);
  assert.strictEqual(p1.prochaine_tranche.libelle, 'Mi-chantier');
  assert.strictEqual(p1.montant_en_retard, 57380);

  const p2 = (await api('POST', `/api/factures/${f.id}/paiements`, { montant: 57380, mode: 'Virement' })).data;
  assert.deepStrictEqual(p2.tranches.map((t) => t.statut), ['payée', 'payée', 'à payer']);
  assert.strictEqual(p2.en_retard, false);
  assert.strictEqual(p2.montant_en_retard, 0);
  assert.strictEqual(p2.prochaine_tranche.reste, 46020);

  const clientAvant = (await api('GET', '/api/clients')).data.find((c) => c.id === cli.id);
  assert.strictEqual(clientAvant.reste_du, 46020);

  const p3 = (await api('POST', `/api/factures/${f.id}/paiements`, { montant: 46020, mode: 'Mobile Money' })).data;
  assert.strictEqual(p3.paiement, 'payée');
  assert.strictEqual(p3.prochaine_tranche, null);
  assert.strictEqual(p3.tranches_payees, 3);
  assert.strictEqual((await api('GET', '/api/clients')).data.find((c) => c.id === cli.id).reste_du, 0);
});

test('tranches : total de 100 % exigé, arrondis exacts, un seul paiement possible aussi', async () => {
  const pose = await article(admin, 'POSE-CAM');
  const base0 = { client_id: 1, date_facture: aujourdhui(), tva: 0, lignes: [{ produit_id: pose.id, quantite: 1, prix_unitaire: 100001 }] };
  const invalide = await api('POST', '/api/factures', { ...base0, tranches: [{ pourcentage: 50 }, { pourcentage: 40 }] });
  assert.strictEqual(invalide.statut, 400);
  assert.match(invalide.data.erreur, /100 %/);
  assert.strictEqual((await api('POST', '/api/factures', { ...base0, tranches: [{ pourcentage: 0 }, { pourcentage: 100 }] })).statut, 400);
  assert.strictEqual((await api('POST', '/api/factures', { ...base0, tranches: [{ pourcentage: 100, delai_jours: -3 }] })).statut, 400);

  const f = (await api('POST', '/api/factures', { ...base0, tranches: [{ pourcentage: 33.33 }, { pourcentage: 33.33 }, { pourcentage: 33.34 }] })).data;
  const montants = f.tranches.map((t) => t.montant);
  assert.deepStrictEqual(montants, [33330, 33330, 33341]);
  assert.strictEqual(montants.reduce((s, m) => s + m, 0), 100001);
  assert.strictEqual(f.tranches[0].libelle, 'Tranche 1');

  const sans = (await api('PUT', `/api/factures/${f.id}`, { ...base0 })).data;
  assert.strictEqual(sans.nb_tranches, 0);
  assert.strictEqual(base.table('tranches').compter((t) => t.type === 'facture' && t.document_id === f.id), 0);
  await api('DELETE', `/api/factures/${f.id}`);
});

test('devis par tranches : montants calculés, repris dans la facture, supprimés avec le brouillon', async () => {
  const pose = await article(admin, 'POSE-CAM');
  const d = (await api('POST', '/api/devis', {
    client_id: 1, date_devis: aujourdhui(), tva: 18,
    lignes: [{ produit_id: pose.id, quantite: 1, prix_unitaire: 200000 }],
    tranches: [{ libelle: 'Acompte à la commande', pourcentage: 50, delai_jours: 0 }, { libelle: 'Solde à la livraison', pourcentage: 50, delai_jours: 30 }],
  })).data;
  assert.deepStrictEqual(d.tranches.map((t) => t.montant), [118000, 118000]);

  const r = (await api('POST', `/api/devis/${d.id}/facturer`)).data;
  assert.deepStrictEqual(r.facture.tranches.map((t) => [t.libelle, t.montant, t.delai_jours]), [['Acompte à la commande', 118000, 0], ['Solde à la livraison', 118000, 30]]);
  assert.strictEqual(r.facture.statut, 'brouillon');
  await api('DELETE', `/api/factures/${r.facture.id}`);
  assert.strictEqual(base.table('tranches').compter((t) => t.type === 'facture' && t.document_id === r.facture.id), 0);
  assert.strictEqual(base.table('tranches').compter((t) => t.type === 'devis' && t.document_id === d.id), 2);
});


test('l\'arrêt à distance est réservé : refusé sans session administrateur', async () => {
  const pirate = await fetch(adresse + '/api/arret', { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'http://site-malveillant.example' }, body: '{}' });
  assert.strictEqual(pirate.status, 403);
  const { c } = await utilisateurConnecte('Zoe Zéro', 'zoe', 'Lecture seule');
  const rep = await fetch(adresse + '/api/arret', { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: adresse, Cookie: c.cookie ? c.cookie() : '' }, body: '{}' });
  assert.strictEqual(rep.status, 403);
  assert.strictEqual((await api('GET', '/api/session')).statut, 200);
});

test('la présence est signalée sans connexion et le manifeste est servi', async () => {
  assert.strictEqual((await client().appeler('POST', '/api/presence')).statut, 200);
  const manifeste = await fetch(adresse + '/manifest.webmanifest');
  assert.strictEqual(manifeste.status, 200);
  assert.match(manifeste.headers.get('content-type'), /manifest\+json/);
  assert.strictEqual((await manifeste.json()).short_name, 'BC Services');
  assert.strictEqual((await fetch(adresse + '/img/icone-512.png')).status, 200);
});
