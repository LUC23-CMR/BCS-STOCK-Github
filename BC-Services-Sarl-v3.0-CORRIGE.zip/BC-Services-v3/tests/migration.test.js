const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { ecrireClasseur } = require('../database/moteur-excel/xlsx');

const texte = (titre, largeur = 16) => ({ titre, type: 'texte', largeur });

function classeurAncienneVersion() {
  const feuille = (nom, colonnes, lignes) => ({ nom, colonnes, lignes });
  return ecrireClasseur([
    feuille('Parametres', [texte('Paramètre'), { titre: 'Valeur', type: 'libre' }], [['Nom de l\'entreprise', 'Mon Entreprise'], ['Devise', 'EUR']]),
    feuille('Categories', [texte('Catégorie')], [['Vidéosurveillance'], ['Réseau informatique']]),
    feuille('Clients', [{ titre: 'ID', type: 'entier' }, texte('Nom / société'), texte('Téléphone')], [[1, 'Hôtel Teranga', '771112233']]),
    feuille('Produits', [{ titre: 'ID', type: 'entier' }, texte('Référence'), texte('Désignation'), texte('Catégorie'), texte('Type'),
      { titre: 'Prix unitaire HT', type: 'montant' }, { titre: 'Stock', type: 'entier' }, { titre: 'Seuil d\'alerte', type: 'entier' }],
    [[1, 'CAM', 'Caméra IP', 'Vidéosurveillance', 'produit', 65000, 9, 4]]),
    feuille('Factures', [{ titre: 'ID', type: 'entier' }, texte('Numéro'), { titre: 'Date', type: 'date' }, { titre: 'ID client', type: 'entier' },
      { titre: 'TVA (%)', type: 'nombre' }, { titre: 'Payée', type: 'ouinon' }],
    [[1, 'FAC-2026-0001', '2026-09-10', 1, 18, true], [2, 'FAC-2026-0002', '2026-10-02', 1, 18, false]]),
    feuille('Lignes_Facture', [{ titre: 'ID', type: 'entier' }, texte('Numéro facture'), { titre: 'ID article', type: 'entier' }, texte('Désignation'),
      { titre: 'Quantité', type: 'entier' }, { titre: 'Prix unitaire HT', type: 'montant' }],
    [[1, 'FAC-2026-0001', 1, 'Caméra IP', 2, 65000], [2, 'FAC-2026-0002', 1, 'Caméra IP', 1, 65000]]),
  ]);
}

test('migration : prix, factures, paiements et clients sont repris', () => {
  const dossier = fs.mkdtempSync(path.join(os.tmpdir(), 'bc-migration-'));
  const fichier = path.join(dossier, 'ancien.xlsx');
  fs.writeFileSync(fichier, classeurAncienneVersion());

  const script = `
    const base = require('./database/base');
    const sortie = {
      prix: base.table('produits').tous()[0].prix_unitaire,
      stock: base.table('produits').tous()[0].stock,
      devise: base.parametres().devise,
      statuts: base.table('factures').tous().map((f) => f.statut),
      echeance: base.table('factures').tous()[0].date_echeance,
      lignes: base.table('lignes').tous().map((l) => l.facture_id),
      paiements: base.table('paiements').tous().map((p) => [p.facture_id, p.montant]),
      clients: base.table('clients').tous().map((c) => c.nom),
      roles: base.table('roles').compter(),
      utilisateurs: base.table('utilisateurs').compter(),
    };
    console.log(JSON.stringify(sortie));`;
  const resultat = JSON.parse(execFileSync('node', ['-e', script], {
    cwd: path.join(__dirname, '..'), env: { ...process.env, BC_EXCEL: fichier }, encoding: 'utf8',
  }).trim().split('\n').pop());

  assert.strictEqual(resultat.prix, 65000);
  assert.strictEqual(resultat.stock, 9);
  assert.strictEqual(resultat.devise, 'EUR');
  assert.deepStrictEqual(resultat.statuts, ['validée', 'validée']);
  assert.strictEqual(resultat.echeance, '2026-09-10');
  assert.deepStrictEqual(resultat.lignes, [1, 2]);
  assert.deepStrictEqual(resultat.paiements, [[1, 153400]]);
  assert.deepStrictEqual(resultat.clients, ['Hôtel Teranga']);
  assert.ok(resultat.roles >= 6);
  assert.strictEqual(resultat.utilisateurs, 0);
  assert.ok(fs.readdirSync(path.join(dossier, 'sauvegardes')).some((f) => f.includes('avant-migration')));
  fs.rmSync(dossier, { recursive: true, force: true });
});
