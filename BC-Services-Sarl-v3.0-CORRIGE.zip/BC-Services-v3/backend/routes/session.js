const router = require('../router');
const auth = require('../services/authentification');
const parametres = require('../services/parametres');
const sessions = require('../securite/sessions');

router.get('/api/info', () => ({ application: 'bc-services', initialise: auth.estInitialise() }), { public: true });

router.post('/api/configuration-initiale', (ctx) => {
  const { jeton, utilisateur } = auth.configurerAdministrateur(ctx.corps);
  ctx.entetes['Set-Cookie'] = sessions.enteteCookie(jeton);
  return utilisateur;
}, { public: true });

router.post('/api/connexion', (ctx) => {
  const { jeton, utilisateur } = auth.connexion(ctx.corps.identifiant, ctx.corps.mot_de_passe);
  ctx.entetes['Set-Cookie'] = sessions.enteteCookie(jeton);
  return utilisateur;
}, { public: true, statut: 200 });

router.post('/api/session/reinitialiser-admin', (ctx) => auth.reinitialiserAdministrateur(ctx.corps, ctx.req),
  { public: true, statut: 200 });

router.post('/api/deconnexion', (ctx) => {
  auth.deconnexion(ctx.jeton, ctx.utilisateur);
  ctx.entetes['Set-Cookie'] = sessions.enteteCookie(null);
  return { ok: true };
}, { mdpTemporaire: true, statut: 200 });

router.get('/api/session', (ctx) => auth.vuePublique(ctx.utilisateur), { mdpTemporaire: true });

router.post('/api/session/mot-de-passe',
  (ctx) => auth.changerMotDePasse(ctx.utilisateur, ctx.jeton, ctx.corps.ancien, ctx.corps.nouveau),
  { mdpTemporaire: true, statut: 200 });

router.post('/api/presence', () => ({ ok: true }), { public: true, statut: 200 });

router.get('/api/parametres', () => parametres.lire());
router.get('/api/categories', () => parametres.listerCategories());
