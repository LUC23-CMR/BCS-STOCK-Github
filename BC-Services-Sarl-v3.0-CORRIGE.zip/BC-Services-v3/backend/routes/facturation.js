const router = require('../router');
const clients = require('../services/clients');
const factures = require('../services/factures');
const paiements = require('../services/paiements');

router.get('/api/clients', () => clients.lister(), { droit: 'clients.voir' });
router.post('/api/clients', ({ corps }) => clients.creer(corps), { droit: 'clients.modifier' });
router.put('/api/clients/:id', ({ params, corps }) => clients.modifier(params.id, corps), { droit: 'clients.modifier' });
router.delete('/api/clients/:id', ({ params }) => clients.supprimer(params.id), { droit: 'clients.supprimer' });

router.get('/api/factures', () => factures.lister(), { droit: 'factures.voir' });
router.get('/api/factures/:id', ({ params }) => factures.lire(params.id), { droit: 'factures.voir' });
router.post('/api/factures', ({ corps }) => factures.creer(corps), { droit: 'factures.creer' });
router.put('/api/factures/:id', ({ params, corps }) => factures.modifier(params.id, corps), { droit: 'factures.creer' });
router.post('/api/factures/:id/valider', ({ params }) => factures.valider(params.id), { droit: 'factures.valider', statut: 200 });
router.post('/api/factures/:id/annuler', ({ params }) => factures.annuler(params.id), { droit: 'factures.annuler', statut: 200 });
router.delete('/api/factures/:id', ({ params }) => factures.supprimer(params.id), { droit: 'factures.supprimer' });

router.post('/api/factures/:id/paiements', ({ params, corps }) => paiements.enregistrer(params.id, corps), { droit: 'paiements.enregistrer' });
router.get('/api/paiements', () => paiements.lister(), { droit: 'paiements.voir' });
router.delete('/api/paiements/:id', ({ params }) => paiements.supprimer(params.id), { droit: 'paiements.supprimer' });
