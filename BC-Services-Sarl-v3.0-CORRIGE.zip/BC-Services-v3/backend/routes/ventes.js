const router = require('../router');
const devis = require('../services/devis');
const livraisons = require('../services/livraisons');

router.get('/api/devis', () => devis.lister(), { droit: 'devis.voir' });
router.get('/api/devis/:id', ({ params }) => devis.lire(params.id), { droit: 'devis.voir' });
router.post('/api/devis', ({ corps }) => devis.creer(corps), { droit: 'devis.creer' });
router.put('/api/devis/:id', ({ params, corps }) => devis.modifier(params.id, corps), { droit: 'devis.creer' });
router.post('/api/devis/:id/statut', ({ params, corps }) => devis.changerStatut(params.id, corps.statut, corps.raison_refus), { droit: 'devis.creer', statut: 200 });
router.post('/api/devis/:id/facturer', ({ params }) => devis.facturer(params.id), { droit: 'devis.facturer', statut: 200 });
router.delete('/api/devis/:id', ({ params }) => devis.supprimer(params.id), { droit: 'devis.supprimer' });

router.get('/api/livraisons', () => livraisons.lister(), { droit: 'factures.voir' });
router.get('/api/livraisons/documents', () => livraisons.documentsDisponibles(), { droit: 'factures.voir' });
router.get('/api/livraisons/:id', ({ params }) => livraisons.lire(params.id), { droit: 'factures.voir' });
router.post('/api/livraisons', ({ corps }) => livraisons.creer(corps), { droit: 'factures.creer' });
router.delete('/api/livraisons/:id', ({ params }) => livraisons.supprimer(params.id), { droit: 'factures.supprimer' });
