const path = require('node:path');
const router = require('../router');
const config = require('../config');
const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const auth = require('../services/authentification');
const utilisateurs = require('../services/utilisateurs');
const roles = require('../services/roles');
const journal = require('../services/journal');
const parametres = require('../services/parametres');

router.get('/api/utilisateurs', () => utilisateurs.lister(), { droit: 'admin.utilisateurs' });
router.post('/api/utilisateurs', ({ corps }) => utilisateurs.creer(corps), { droit: 'admin.utilisateurs' });
router.put('/api/utilisateurs/:id', ({ params, corps }) => utilisateurs.modifier(params.id, corps), { droit: 'admin.utilisateurs' });
router.post('/api/utilisateurs/:id/activation', ({ params, corps }) => utilisateurs.definirActif(params.id, corps.actif),
  { droit: 'admin.utilisateurs', statut: 200 });
router.post('/api/utilisateurs/:id/mot-de-passe', ({ params }) => utilisateurs.reinitialiserMotDePasse(params.id),
  { droit: 'admin.utilisateurs', statut: 200 });

router.get('/api/roles', () => roles.lister(), { droit: ['admin.roles', 'admin.utilisateurs'] });
router.get('/api/permissions', () => roles.definitions(), { droit: 'admin.roles' });
router.post('/api/roles', ({ corps }) => roles.creer(corps), { droit: 'admin.roles' });
router.put('/api/roles/:id', ({ params, corps }) => roles.modifier(params.id, corps), { droit: 'admin.roles' });
router.delete('/api/roles/:id', ({ params }) => roles.supprimer(params.id), { droit: 'admin.roles' });

router.get('/api/journal', ({ query }) => journal.lister({
  q: query.get('q') || '', utilisateur: query.get('utilisateur') || '', action: query.get('action') || '', limite: query.get('limite'),
}), { droit: 'admin.journal' });

router.put('/api/parametres', ({ corps }) => parametres.modifier(corps), { droit: 'admin.parametres', statut: 200 });
router.post('/api/categories', ({ corps }) => parametres.creerCategorie(corps), { droit: 'admin.parametres' });
router.put('/api/categories/:id', ({ params, corps }) => parametres.renommerCategorie(params.id, corps), { droit: 'admin.parametres' });
router.delete('/api/categories/:id', ({ params }) => parametres.supprimerCategorie(params.id), { droit: 'admin.parametres' });

router.get('/api/systeme', () => ({
  fichier: path.basename(config.fichierExcel),
  chemin: config.fichierExcel,
  dossier_sauvegardes: path.join(path.dirname(config.fichierExcel), 'sauvegardes'),
}), { droit: 'admin.parametres' });


router.post('/api/systeme/reparer', () => {
  const reparation = require('../../outils/reparation');
  // Sauvegarde de sécurité avant intervention manuelle
  try { require('../../outils/sauvegarde').sauvegarderMaintenant('_avant-reparation-manuelle'); } catch {}
  const resultat = reparation.reparer({ sauvegarder: true });
  try {
    base.transaction(() => journal.ajouter(
      'Réparation',
      'Application',
      resultat.actions.slice(0, 8).join(' · ') + (resultat.actions.length > 8 ? '…' : ''),
    ));
  } catch { /* non bloquant */ }
  return {
    ok: resultat.ok,
    restaure: resultat.restaure,
    actions: resultat.actions,
    message: resultat.ok
      ? (resultat.restaure
        ? 'Application réparée : la base a été restaurée depuis une sauvegarde.'
        : 'Application vérifiée et réparée avec succès.')
      : 'Réparation incomplète. Vérifiez le dossier des sauvegardes ou contactez votre informaticien.',
  };
}, { droit: 'admin.parametres', statut: 200 });

const LOCAL = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);

router.post('/api/arret', (ctx) => {
  const depuisCetOrdinateur = LOCAL.has(ctx.req.socket.remoteAddress) && !ctx.req.headers.origin;
  const utilisateur = depuisCetOrdinateur ? null : auth.depuisJeton(ctx.jeton);
  if (!depuisCetOrdinateur && !(utilisateur && utilisateur.permissions.has('admin.parametres'))) {
    throw new ErreurMetier('Vous n\'avez pas le droit d\'effectuer cette action.', 403);
  }
  base.transaction(() => journal.ajouter('Arrêt', 'Application', 'Arrêt demandé', utilisateur ? utilisateur.nom : 'Système'));
  setTimeout(() => process.exit(0), 400);
  return { ok: true };
}, { public: true, statut: 200 });
