const router = require('../router');
const produits = require('../services/produits');
const stock = require('../services/stock');
const mouvements = require('../services/mouvements');
const fournisseurs = require('../services/fournisseurs');

router.get('/api/produits', () => produits.lister(), { droit: 'articles.voir' });
router.post('/api/produits', ({ corps }) => produits.creer(corps), { droit: 'articles.modifier' });
router.put('/api/produits/:id', ({ params, corps }) => produits.modifier(params.id, corps), { droit: 'articles.modifier' });
router.delete('/api/produits/:id', ({ params }) => produits.supprimer(params.id), { droit: 'articles.supprimer' });

router.get('/api/fournisseurs', () => fournisseurs.lister(), { droit: 'articles.voir' });
router.post('/api/fournisseurs', ({ corps }) => fournisseurs.creer(corps), { droit: 'articles.modifier' });
router.put('/api/fournisseurs/:id', ({ params, corps }) => fournisseurs.modifier(params.id, corps), { droit: 'articles.modifier' });
router.delete('/api/fournisseurs/:id', ({ params }) => fournisseurs.supprimer(params.id), { droit: 'articles.supprimer' });

router.get('/api/mouvements', ({ query }) => mouvements.lister({
  limite: query.get('limite'), produit_id: query.get('produit_id'), type: query.get('type'),
}), { droit: 'stock.voir' });

router.post('/api/stock/reception', ({ corps }) => stock.reception(corps), { droit: 'stock.operer' });
router.post('/api/stock/sortie', ({ corps }) => stock.sortie(corps), { droit: 'stock.operer' });
router.post('/api/stock/inventaire', ({ corps }) => stock.ajustement(corps), { droit: 'stock.operer' });
