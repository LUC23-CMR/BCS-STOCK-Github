const router = require('../router');
const base = require('../../database/base');
const dashboard = require('../services/dashboard');
const journal = require('../services/journal');

router.get('/api/dashboard', () => dashboard.resume(), { droit: 'tableau.voir' });

router.get('/api/export', () => {
  base.transaction(() => journal.ajouter('Export', 'Base de données', 'Export Excel'));
  return {
    telechargement: {
      nom: `BC_Services_Export_${new Date().toISOString().slice(0, 10)}.xlsx`,
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      contenu: base.exporter(),
    },
  };
}, { droit: 'export.excel' });
