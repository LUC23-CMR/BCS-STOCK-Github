const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const { arrondir } = require('../../database/calculs');

function normaliser(brut) {
  if (!Array.isArray(brut) || brut.length === 0) return [];
  if (brut.length > 12) throw new ErreurMetier('Un échéancier compte 12 tranches au maximum.');
  const plan = brut.map((t, i) => {
    const pourcentage = Number(t.pourcentage);
    const delai = t.delai_jours === '' || t.delai_jours === undefined || t.delai_jours === null ? 0 : Number(t.delai_jours);
    if (!(pourcentage > 0 && pourcentage <= 100)) throw new ErreurMetier(`Tranche ${i + 1} : le pourcentage doit être compris entre 0 et 100.`);
    if (!(Number.isInteger(delai) && delai >= 0 && delai <= 730)) throw new ErreurMetier(`Tranche ${i + 1} : le délai doit être un nombre de jours entier.`);
    return {
      ordre: i + 1,
      libelle: String(t.libelle ?? '').trim().slice(0, 60) || `Tranche ${i + 1}`,
      pourcentage: arrondir(pourcentage, 2),
      delai_jours: delai,
    };
  });
  const total = arrondir(plan.reduce((s, t) => s + t.pourcentage, 0), 2);
  if (Math.abs(total - 100) > 0.01) throw new ErreurMetier(`Le total des tranches doit faire 100 % (actuellement ${total} %).`);
  return plan;
}

const lire = (type, documentId) => base.table('tranches')
  .ou((t) => t.type === type && t.document_id === documentId)
  .sort((a, b) => a.ordre - b.ordre);

function tousParDocument(type) {
  const groupes = new Map();
  for (const t of base.table('tranches').ou((x) => x.type === type).sort((a, b) => a.ordre - b.ordre)) {
    if (!groupes.has(t.document_id)) groupes.set(t.document_id, []);
    groupes.get(t.document_id).push(t);
  }
  return groupes;
}

function supprimer(type, documentId) {
  base.table('tranches').supprimerOu((t) => t.type === type && t.document_id === documentId);
}

function ecrire(type, documentId, plan) {
  supprimer(type, documentId);
  for (const t of plan) base.table('tranches').ajouter({ type, document_id: documentId, ordre: t.ordre, libelle: t.libelle, pourcentage: t.pourcentage, delai_jours: t.delai_jours });
}

module.exports = { normaliser, lire, tousParDocument, supprimer, ecrire };
