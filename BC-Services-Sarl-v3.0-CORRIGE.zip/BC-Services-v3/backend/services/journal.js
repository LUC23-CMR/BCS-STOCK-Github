const base = require('../../database/base');
const { maintenant } = require('../../database/temps');
const contexte = require('../contexte');

function ajouter(action, objet = '', detail = '', utilisateur) {
  base.table('journal').ajouter({
    date_heure: maintenant(),
    utilisateur: utilisateur ?? contexte.nomActeur(),
    action, objet, detail,
  });
}

function lister({ q = '', utilisateur = '', action = '', limite = 300 } = {}) {
  const texte = String(q).toLowerCase();
  const toutes = base.table('journal').tous().sort((a, b) => b.id - a.id);
  const filtrees = toutes.filter((e) =>
    (!utilisateur || e.utilisateur === utilisateur) &&
    (!action || e.action === action) &&
    (!texte || `${e.objet} ${e.detail} ${e.utilisateur} ${e.action}`.toLowerCase().includes(texte)));
  return {
    total: filtrees.length,
    entrees: filtrees.slice(0, Math.min(Number(limite) || 300, 2000)),
    utilisateurs: [...new Set(toutes.map((e) => e.utilisateur))].sort(),
    actions: [...new Set(toutes.map((e) => e.action))].sort(),
  };
}

function historique(objets) {
  return base.table('journal').ou((e) => objets.includes(e.objet)).sort((a, b) => a.id - b.id);
}

module.exports = { ajouter, lister, historique };
