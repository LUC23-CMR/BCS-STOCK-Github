const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const journal = require('./journal');
const roles = require('./roles');
const utilisateurs = require('./utilisateurs');
const sessions = require('../securite/sessions');
const mdp = require('../securite/mots-de-passe');
const { maintenant, aujourdhui } = require('../../database/temps');

const estInitialise = () => base.table('utilisateurs').compter() > 0;

function contexteUtilisateur(u) {
  return {
    id: u.id, nom: u.nom, identifiant: u.identifiant, role: u.role,
    permissions: roles.permissionsDuRole(u.role),
    doitChangerMdp: u.doit_changer_mdp,
  };
}

const vuePublique = (c) => ({
  id: c.id, nom: c.nom, identifiant: c.identifiant, role: c.role,
  permissions: [...c.permissions], doit_changer_mdp: c.doitChangerMdp,
});

function configurerAdministrateur(data) {
  if (estInitialise()) throw new ErreurMetier('L\'application est déjà configurée.', 409);
  const nom = String(data.nom ?? '').trim();
  const identifiant = String(data.identifiant ?? '').trim();
  if (!nom) throw new ErreurMetier('Saisissez votre nom.');
  if (!/^[a-z0-9._@-]{3,40}$/i.test(identifiant)) throw new ErreurMetier('Identifiant : 3 à 40 caractères, lettres et chiffres (sans espace).');
  mdp.verifierRegles(data.mot_de_passe);
  const roleAdmin = base.table('roles').premier((r) => r.systeme);

  const u = base.transaction(() => {
    const cree = base.table('utilisateurs').ajouter({
      nom, identifiant, role: roleAdmin.nom, actif: true, doit_changer_mdp: false,
      mot_de_passe: mdp.hacher(data.mot_de_passe), cree_le: aujourdhui(), derniere_connexion: maintenant(),
    });
    journal.ajouter('Création', `Utilisateur ${nom}`, 'Compte administrateur créé à la première utilisation', nom);
    return cree;
  });
  return { jeton: sessions.creer(u.id), utilisateur: vuePublique(contexteUtilisateur(u)) };
}

function connexion(identifiantSaisi, motDePasse) {
  const identifiant = String(identifiantSaisi ?? '').trim().toLowerCase();
  sessions.verifierBlocage(identifiant);

  const u = base.table('utilisateurs').premier((x) => x.identifiant.toLowerCase() === identifiant);
  const motDePasseOk = mdp.verifier(String(motDePasse ?? ''), u ? u.mot_de_passe : mdp.EMPREINTE_FACTICE);

  if (!u || !u.actif || !motDePasseOk) {
    sessions.noterEchec(identifiant);
    base.transaction(() => journal.ajouter('Échec de connexion', identifiant, u && !u.actif ? 'Compte désactivé' : '', identifiant || 'inconnu'));
    throw new ErreurMetier('Identifiant ou mot de passe incorrect.', 401);
  }

  sessions.effacerEchecs(identifiant);
  base.transaction(() => {
    base.table('utilisateurs').modifier(u.id, { derniere_connexion: maintenant() });
    journal.ajouter('Connexion', '', '', u.nom);
  });
  return { jeton: sessions.creer(u.id), utilisateur: vuePublique(contexteUtilisateur(base.table('utilisateurs').trouver(u.id))) };
}

function deconnexion(jeton, utilisateur) {
  if (utilisateur) base.transaction(() => journal.ajouter('Déconnexion', '', '', utilisateur.nom));
  sessions.detruire(jeton);
}

function depuisJeton(jeton) {
  if (!jeton) return null;
  const id = sessions.trouver(jeton);
  if (!id) return null;
  const u = base.table('utilisateurs').trouver(id);
  if (!u || !u.actif) { sessions.detruire(jeton); return null; }
  return contexteUtilisateur(u);
}

function changerMotDePasse(utilisateur, jeton, ancien, nouveau) {
  const u = base.table('utilisateurs').trouver(utilisateur.id);
  if (!mdp.verifier(String(ancien ?? ''), u.mot_de_passe)) throw new ErreurMetier('Le mot de passe actuel est incorrect.', 400);
  mdp.verifierRegles(nouveau);
  if (nouveau === ancien) throw new ErreurMetier('Choisissez un mot de passe différent de l\'ancien.');
  base.transaction(() => {
    base.table('utilisateurs').modifier(u.id, { mot_de_passe: mdp.hacher(nouveau), doit_changer_mdp: false });
    journal.ajouter('Mot de passe', `Utilisateur ${u.nom}`, 'Changé par l\'utilisateur');
  });
  sessions.detruireDeUtilisateur(u.id, jeton);
  return vuePublique(contexteUtilisateur(base.table('utilisateurs').trouver(u.id)));
}

function estAdresseLocale(req) {
  const ip = (req && (req.socket?.remoteAddress || req.connection?.remoteAddress)) || '';
  return ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1' || ip.endsWith('127.0.0.1');
}

/**
 * Réinitialisation du mot de passe administrateur (oubli).
 * Uniquement depuis la machine locale (localhost), sans connexion.
 */
function reinitialiserAdministrateur(data, req) {
  if (!estAdresseLocale(req)) {
    throw new ErreurMetier('Cette opération n\'est autorisée que depuis l\'ordinateur où tourne BC Services.', 403);
  }
  if (!estInitialise()) throw new ErreurMetier('Aucun compte n\'existe encore. Utilisez la configuration initiale.', 400);

  const identifiant = String(data.identifiant ?? '').trim();
  if (!identifiant) throw new ErreurMetier('Indiquez l\'identifiant de l\'administrateur.');

  const u = base.table('utilisateurs').premier((x) => x.identifiant.toLowerCase() === identifiant.toLowerCase());
  if (!u) throw new ErreurMetier('Aucun compte avec cet identifiant.', 404);

  const role = base.table('roles').premier((r) => r.nom === u.role);
  if (!role || !role.systeme) {
    throw new ErreurMetier('Seul le compte administrateur (rôle système) peut être réinitialisé ici. Pour un autre utilisateur, contactez l\'administrateur.', 403);
  }

  mdp.verifierRegles(data.mot_de_passe);
  if (String(data.mot_de_passe) !== String(data.confirmation ?? '')) {
    throw new ErreurMetier('Les deux mots de passe ne sont pas identiques.');
  }

  base.transaction(() => {
    base.table('utilisateurs').modifier(u.id, {
      mot_de_passe: mdp.hacher(data.mot_de_passe),
      doit_changer_mdp: false,
      actif: true,
    });
    sessions.detruireDeUtilisateur(u.id);
    journal.ajouter('Mot de passe', `Utilisateur ${u.nom}`, 'Réinitialisé depuis l\'écran de connexion (mot de passe oublié)', 'Système');
  });

  return { ok: true, message: 'Mot de passe administrateur réinitialisé. Vous pouvez vous connecter.' };
}

module.exports = {
  estInitialise, configurerAdministrateur, connexion, deconnexion, depuisJeton,
  changerMotDePasse, reinitialiserAdministrateur, vuePublique,
};

