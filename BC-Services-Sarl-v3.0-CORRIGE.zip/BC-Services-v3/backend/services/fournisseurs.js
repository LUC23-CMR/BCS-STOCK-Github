const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const journal = require('./journal');
const { aujourdhui } = require('../../database/temps');

function lister() {
  return base.table('fournisseurs').tous()
    .sort((a, b) => a.nom.localeCompare(b.nom, 'fr'));
}

function nettoyer(data) {
  const nom = String(data.nom ?? '').trim();
  if (!nom) throw new ErreurMetier('Saisissez le nom du fournisseur.');
  return {
    nom,
    telephone: String(data.telephone ?? '').trim(),
    email: String(data.email ?? '').trim(),
    adresse: String(data.adresse ?? '').trim(),
    contact: String(data.contact ?? '').trim(),
    notes: String(data.notes ?? '').trim(),
  };
}

function creer(data) {
  const f = nettoyer(data);
  return base.transaction(() => {
    const fournisseur = base.table('fournisseurs').ajouter({ ...f, cree_le: aujourdhui() });
    journal.ajouter('Création', `Fournisseur ${f.nom}`);
    return fournisseur;
  });
}

function modifier(id, data) {
  const f = nettoyer(data);
  return base.transaction(() => {
    const fournisseur = base.table('fournisseurs').modifier(id, f);
    if (!fournisseur) throw new ErreurMetier('Fournisseur introuvable.', 404);
    journal.ajouter('Modification', `Fournisseur ${f.nom}`);
    return fournisseur;
  });
}

function supprimer(id) {
  const fournisseur = base.table('fournisseurs').trouver(id);
  if (!fournisseur) throw new ErreurMetier('Fournisseur introuvable.', 404);
  const nb = base.table('produits').compter((p) => p.fournisseur_id === fournisseur.id);
  if (nb > 0) {
    throw new ErreurMetier(`« ${fournisseur.nom} » est lié à ${nb} article(s) : il ne peut pas être supprimé.`, 409);
  }
  base.transaction(() => {
    base.table('fournisseurs').supprimerOu((f) => f.id === fournisseur.id);
    journal.ajouter('Suppression', `Fournisseur ${fournisseur.nom}`);
  });
  return { ok: true };
}

module.exports = { lister, creer, modifier, supprimer };
