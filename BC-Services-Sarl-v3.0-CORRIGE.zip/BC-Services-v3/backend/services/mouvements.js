const base = require('../../database/base');
const contexte = require('../contexte');
const { aujourdhui } = require('../../database/temps');

function enregistrer(produitId, quantite, type, motif, date) {
  base.table('mouvements').ajouter({
    date_mouvement: date || aujourdhui(), type, produit_id: produitId, quantite, motif, utilisateur: contexte.nomActeur(),
  });
}

function lister({ limite = 100, produit_id, type } = {}) {
  const produits = new Map(base.table('produits').tous().map((p) => [p.id, p]));
  return base.table('mouvements').tous()
    .filter((m) => (!produit_id || m.produit_id === Number(produit_id)) && (!type || m.type === type))
    .sort((a, b) => b.id - a.id)
    .slice(0, Math.min(Number(limite) || 100, 1000))
    .map((m) => ({
      ...m,
      designation: (produits.get(m.produit_id) || {}).designation || '(article supprimé)',
      unite: (produits.get(m.produit_id) || {}).unite || '',
    }));
}

module.exports = { enregistrer, lister };
