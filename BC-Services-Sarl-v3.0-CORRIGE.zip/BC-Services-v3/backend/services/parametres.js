const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const journal = require('./journal');
const { MODES_PAIEMENT, CONDITIONS_PAIEMENT } = require('../../database/constantes');

const lire = () => ({ ...base.parametres(), modesPaiement: MODES_PAIEMENT, conditionsPaiement: CONDITIONS_PAIEMENT });

function modifier(data) {
  const changements = {};
  for (const cle of ['nom', 'adresse', 'telephone', 'email', 'identifiants', 'mentionBancaire', 'devise']) {
    if (cle in data) changements[cle] = String(data[cle] ?? '').trim();
  }
  if (!changements.nom && 'nom' in changements) throw new ErreurMetier('Le nom de l\'entreprise ne peut pas être vide.');
  if ('devise' in changements && !changements.devise) throw new ErreurMetier('Indiquez la devise.');

  const nombre = (cle, min, max, libelle) => {
    if (!(cle in data)) return;
    const n = Number(data[cle]);
    if (!Number.isFinite(n) || n < min || n > max) throw new ErreurMetier(`${libelle} doit être un nombre entre ${min} et ${max}.`);
    changements[cle] = n;
  };
  nombre('tvaParDefaut', 0, 100, 'La TVA');
  nombre('decimales', 0, 3, 'Le nombre de décimales');
  nombre('conditionsParDefaut', 0, 365, 'Le délai de paiement');
  nombre('validiteDevis', 1, 365, 'La validité des devis');
  nombre('majorationVip', 0, 100, 'La majoration VIP');

  if ('prefixeFacture' in data) {
    const prefixe = String(data.prefixeFacture ?? '').trim();
    if (!/^[A-Za-z0-9]{1,10}$/.test(prefixe)) throw new ErreurMetier('Le préfixe des factures : 1 à 10 lettres ou chiffres.');
    changements.prefixeFacture = prefixe;
  }

  if ('prefixeDevis' in data) {
    const prefixe = String(data.prefixeDevis ?? '').trim();
    if (!/^[A-Za-z0-9]{1,10}$/.test(prefixe)) throw new ErreurMetier('Le préfixe des devis : 1 à 10 lettres ou chiffres.');
    changements.prefixeDevis = prefixe;
  }

  if ('prefixeLivraison' in data) {
    const prefixe = String(data.prefixeLivraison ?? '').trim();
    if (!/^[A-Za-z0-9]{1,10}$/.test(prefixe)) throw new ErreurMetier('Le préfixe des bordereaux : 1 à 10 lettres ou chiffres.');
    changements.prefixeLivraison = prefixe;
  }

  base.transaction(() => {
    base.modifierParametres(changements);
    journal.ajouter('Modification', 'Réglages de l\'entreprise', Object.keys(changements).join(', '));
  });
  return lire();
}

const listerCategories = () => base.table('categories').tous().filter((c) => c.nom);

function nomCategorie(data, idExistant) {
  const nom = String(data.nom ?? '').trim();
  if (!nom) throw new ErreurMetier('Saisissez le nom de la catégorie.');
  if (base.table('categories').premier((c) => c.nom.toLowerCase() === nom.toLowerCase() && c.id !== idExistant)) {
    throw new ErreurMetier(`La catégorie « ${nom} » existe déjà.`);
  }
  return nom;
}

function creerCategorie(data) {
  const nom = nomCategorie(data);
  return base.transaction(() => {
    const c = base.table('categories').ajouter({ nom });
    journal.ajouter('Création', `Catégorie ${nom}`);
    return c;
  });
}

function renommerCategorie(id, data) {
  const c = base.table('categories').trouver(id);
  if (!c) throw new ErreurMetier('Catégorie introuvable.', 404);
  const nom = nomCategorie(data, c.id);
  return base.transaction(() => {
    base.table('categories').modifier(c.id, { nom });
    for (const p of base.table('produits').ou((p) => p.categorie === c.nom)) base.table('produits').modifier(p.id, { categorie: nom });
    journal.ajouter('Modification', `Catégorie ${c.nom}`, `Renommée en ${nom}`);
    return { id: c.id, nom };
  });
}

function supprimerCategorie(id) {
  const c = base.table('categories').trouver(id);
  if (!c) throw new ErreurMetier('Catégorie introuvable.', 404);
  const nb = base.table('produits').compter((p) => p.categorie === c.nom);
  if (nb > 0) throw new ErreurMetier(`Cette catégorie contient ${nb} article(s) : déplacez-les d'abord.`, 409);
  base.transaction(() => {
    base.table('categories').supprimerOu((x) => x.id === c.id);
    journal.ajouter('Suppression', `Catégorie ${c.nom}`);
  });
  return { ok: true };
}

module.exports = { lire, modifier, listerCategories, creerCategorie, renommerCategorie, supprimerCategorie };
