const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const contexte = require('../contexte');
const journal = require('./journal');
const { aujourdhui } = require('../../database/temps');
const { STATUT } = require('../../database/constantes');

function enrichir(l) {
  const client = base.table('clients').trouver(l.client_id) || {};
  let document_numero = '';
  if (l.document_type === 'devis' && l.devis_id) {
    document_numero = (base.table('devis').trouver(l.devis_id) || {}).numero || '';
  } else if (l.facture_id) {
    document_numero = (base.table('factures').trouver(l.facture_id) || {}).numero || '';
  }
  return {
    ...l,
    client_nom: client.nom || '',
    document_numero,
    lignes: base.table('lignes_livraison').ou((x) => x.livraison_id === l.id),
  };
}

function lister() {
  return base.table('livraisons').tous()
    .sort((a, b) => (b.date_livraison || '').localeCompare(a.date_livraison || '') || b.id - a.id)
    .map(enrichir);
}

function lire(id) {
  const l = base.table('livraisons').trouver(id);
  if (!l) throw new ErreurMetier('Bordereau introuvable.', 404);
  return enrichir(l);
}

function prochainNumero(annee) {
  const prefixe = `${base.parametres().prefixeLivraison || 'BL'}-${annee}-`;
  const dernier = base.table('livraisons').ou((d) => (d.numero || '').startsWith(prefixe))
    .map((d) => parseInt(String(d.numero).slice(prefixe.length)) || 0)
    .reduce((max, n) => Math.max(max, n), 0);
  return prefixe + String(dernier + 1).padStart(4, '0');
}

function resoudreDocument(data) {
  const type = String(data.document_type || '').toLowerCase();
  if (type === 'devis') {
    const devis = base.table('devis').trouver(data.devis_id || data.document_id);
    if (!devis) throw new ErreurMetier('Choisissez un devis valide pour le bordereau.');
    const client = base.table('clients').trouver(devis.client_id);
    if (!client) throw new ErreurMetier('Client du devis introuvable.');
    const lignesDoc = base.table('lignes_devis').ou((l) => l.devis_id === devis.id);
    return {
      document_type: 'devis',
      devis_id: devis.id,
      facture_id: 0,
      client,
      document_numero: devis.numero,
      lignesDoc,
    };
  }
  if (type === 'facture' || data.facture_id) {
    const facture = base.table('factures').trouver(data.facture_id || data.document_id);
    if (!facture) throw new ErreurMetier('Choisissez une facture valide pour le bordereau.');
    if (facture.statut === STATUT.ANNULEE) throw new ErreurMetier('Impossible de lier un bordereau à une facture annulée.');
    const client = base.table('clients').trouver(facture.client_id);
    if (!client) throw new ErreurMetier('Client de la facture introuvable.');
    const lignesDoc = base.table('lignes').ou((l) => l.facture_id === facture.id);
    return {
      document_type: 'facture',
      devis_id: 0,
      facture_id: facture.id,
      client,
      document_numero: facture.numero || `brouillon #${facture.id}`,
      lignesDoc,
    };
  }
  throw new ErreurMetier('Le bordereau de livraison doit être relié à une facture ou à un devis.');
}

function creer(data) {
  const doc = resoudreDocument(data);
  const date = String(data.date_livraison || aujourdhui()).slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new ErreurMetier('Date de livraison invalide.');

  // Lignes : soit fournies, soit reprises du document lié
  let lignes = Array.isArray(data.lignes) && data.lignes.length ? data.lignes : null;
  if (!lignes) {
    lignes = doc.lignesDoc.map((l) => ({
      produit_id: l.produit_id,
      designation: l.designation,
      quantite: l.quantite,
      unite: (base.table('produits').trouver(l.produit_id) || {}).unite || 'pièce',
    }));
  }
  if (!lignes.length) throw new ErreurMetier('Aucune ligne à livrer sur le document lié.');

  return base.transaction(() => {
    const a = contexte.acteur();
    const numero = prochainNumero(date.slice(0, 4));
    const bl = base.table('livraisons').ajouter({
      numero,
      date_livraison: date,
      client_id: doc.client.id,
      document_type: doc.document_type,
      facture_id: doc.facture_id,
      devis_id: doc.devis_id,
      adresse_livraison: String(data.adresse_livraison || doc.client.adresse || '').trim(),
      statut: 'validé',
      notes: String(data.notes || '').trim(),
      cree_par: a ? a.nom : '',
      cree_par_id: a ? a.id : 0,
    });
    for (const ligne of lignes) {
      const p = base.table('produits').trouver(ligne.produit_id);
      base.table('lignes_livraison').ajouter({
        livraison_id: bl.id,
        numero_livraison: numero,
        produit_id: ligne.produit_id || 0,
        designation: (p && p.designation) || String(ligne.designation || ''),
        quantite: parseInt(ligne.quantite) || 1,
        unite: (p && p.unite) || String(ligne.unite || 'pièce'),
      });
    }
    journal.ajouter(
      'Création',
      `Bordereau ${numero}`,
      `Relié à ${doc.document_type} ${doc.document_numero} — Client : ${doc.client.nom}`,
    );
    return lire(bl.id);
  });
}

function supprimer(id) {
  const bl = base.table('livraisons').trouver(id);
  if (!bl) throw new ErreurMetier('Bordereau introuvable.', 404);
  base.transaction(() => {
    base.table('lignes_livraison').supprimerOu((l) => l.livraison_id === bl.id);
    base.table('livraisons').supprimerOu((l) => l.id === bl.id);
    journal.ajouter('Suppression', `Bordereau ${bl.numero}`);
  });
  return { ok: true };
}

/** Documents disponibles pour créer un bordereau (factures validées + devis acceptés/facturés) */
function documentsDisponibles() {
  const factures = base.table('factures').tous()
    .filter((f) => f.statut === STATUT.VALIDEE || f.statut === STATUT.BROUILLON)
    .map((f) => ({
      type: 'facture',
      id: f.id,
      numero: f.numero || `brouillon #${f.id}`,
      client_id: f.client_id,
      client_nom: (base.table('clients').trouver(f.client_id) || {}).nom || '',
      date: f.date_facture,
      statut: f.statut,
    }));
  const devis = base.table('devis').tous()
    .filter((d) => ['accepté', 'facturé', 'envoyé'].includes(d.statut))
    .map((d) => ({
      type: 'devis',
      id: d.id,
      numero: d.numero,
      client_id: d.client_id,
      client_nom: (base.table('clients').trouver(d.client_id) || {}).nom || '',
      date: d.date_devis,
      statut: d.statut,
    }));
  return [...factures, ...devis].sort((a, b) => String(b.date).localeCompare(String(a.date)));
}

module.exports = { lister, lire, creer, supprimer, documentsDisponibles };
