const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const contexte = require('../contexte');
const journal = require('./journal');
const roles = require('./roles');
const sessions = require('../securite/sessions');
const mdp = require('../securite/mots-de-passe');
const { aujourdhui } = require('../../database/temps');

const IDENTIFIANT = /^[a-z0-9._@-]{3,40}$/i;

function publique(u) {
  const { mot_de_passe, ...reste } = u;
  return reste;
}

function lister() {
  const rolesConnus = new Set(base.table('roles').tous().map((r) => r.nom));
  return base.table('utilisateurs').tous()
    .sort((a, b) => a.nom.localeCompare(b.nom, 'fr'))
    .map((u) => ({ ...publique(u), role_valide: rolesConnus.has(u.role) }));
}

function nettoyer(data, idExistant) {
  const nom = String(data.nom ?? '').trim();
  const identifiant = String(data.identifiant ?? '').trim();
  if (!nom) throw new ErreurMetier('Saisissez le nom de l\'utilisateur.');
  if (!IDENTIFIANT.test(identifiant)) {
    throw new ErreurMetier('L\'identifiant doit faire 3 à 40 caractères : lettres, chiffres, point, tiret, @ (pas d\'espace).');
  }
  if (base.table('utilisateurs').premier((u) => u.identifiant.toLowerCase() === identifiant.toLowerCase() && u.id !== idExistant)) {
    throw new ErreurMetier(`L'identifiant « ${identifiant} » est déjà utilisé.`);
  }
  const role = base.table('roles').premier((r) => r.nom === data.role);
  if (!role) throw new ErreurMetier('Choisissez un rôle.');
  return { nom, identifiant, role: role.nom };
}

function creer(data) {
  const u = nettoyer(data);
  const temporaire = mdp.generer();
  return base.transaction(() => {
    const cree = base.table('utilisateurs').ajouter({
      ...u, actif: true, doit_changer_mdp: true, mot_de_passe: mdp.hacher(temporaire), cree_le: aujourdhui(),
    });
    journal.ajouter('Création', `Utilisateur ${u.nom}`, `Identifiant : ${u.identifiant} · Rôle : ${u.role}`);
    return { utilisateur: publique(cree), mot_de_passe_temporaire: temporaire };
  });
}

function modifier(id, data) {
  const existant = base.table('utilisateurs').trouver(id);
  if (!existant) throw new ErreurMetier('Utilisateur introuvable.', 404);
  const u = nettoyer(data, existant.id);
  return base.transaction(() => {
    const maj = base.table('utilisateurs').modifier(existant.id, u);
    roles.garantirAdministrateur();
    journal.ajouter('Modification', `Utilisateur ${u.nom}`, existant.role !== u.role ? `Rôle : ${existant.role} → ${u.role}` : '');
    return publique(maj);
  });
}

function definirActif(id, actif) {
  const u = base.table('utilisateurs').trouver(id);
  if (!u) throw new ErreurMetier('Utilisateur introuvable.', 404);
  if (!actif && contexte.acteur() && contexte.acteur().id === u.id) {
    throw new ErreurMetier('Vous ne pouvez pas désactiver votre propre compte.', 409);
  }
  return base.transaction(() => {
    const maj = base.table('utilisateurs').modifier(u.id, { actif: !!actif });
    roles.garantirAdministrateur();
    if (!actif) sessions.detruireDeUtilisateur(u.id);
    journal.ajouter(actif ? 'Réactivation' : 'Désactivation', `Utilisateur ${u.nom}`);
    return publique(maj);
  });
}

function reinitialiserMotDePasse(id) {
  const u = base.table('utilisateurs').trouver(id);
  if (!u) throw new ErreurMetier('Utilisateur introuvable.', 404);
  const temporaire = mdp.generer();
  return base.transaction(() => {
    base.table('utilisateurs').modifier(u.id, { mot_de_passe: mdp.hacher(temporaire), doit_changer_mdp: true });
    sessions.detruireDeUtilisateur(u.id);
    journal.ajouter('Mot de passe', `Utilisateur ${u.nom}`, 'Réinitialisé par l\'administrateur');
    return { mot_de_passe_temporaire: temporaire };
  });
}

module.exports = { lister, creer, modifier, definirActif, reinitialiserMotDePasse, publique };
