const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const journal = require('./journal');
const { aujourdhui } = require('../../database/temps');

function lister() {
  const factures = require('./factures');
  const totaux = new Map();
  const nombres = new Map();
  const dus = new Map();
  for (const f of factures.toutesEnrichies().filter((f) => f.statut === 'validée')) {
    totaux.set(f.client_id, (totaux.get(f.client_id) || 0) + f.total_ttc);
    dus.set(f.client_id, (dus.get(f.client_id) || 0) + f.reste);
    nombres.set(f.client_id, (nombres.get(f.client_id) || 0) + 1);
  }
  return base.table('clients').tous()
    .sort((a, b) => a.nom.localeCompare(b.nom, 'fr'))
    .map((c) => ({ ...c, total_facture: totaux.get(c.id) || 0, reste_du: dus.get(c.id) || 0, nb_factures: nombres.get(c.id) || 0 }));
}

function nettoyer(data) {
  const nom = String(data.nom ?? '').trim();
  if (!nom) throw new ErreurMetier('Saisissez le nom du client.');
  const type = String(data.type_client ?? 'Standard').trim();
  if (!['Standard', 'VIP'].includes(type)) throw new ErreurMetier('Type de client invalide (Standard ou VIP).');
  return {
    nom,
    type_client: type,
    telephone: String(data.telephone ?? '').trim(),
    email: String(data.email ?? '').trim(),
    adresse: String(data.adresse ?? '').trim(),
  };
}

function creer(data) {
  const c = nettoyer(data);
  return base.transaction(() => {
    const client = base.table('clients').ajouter({ ...c, cree_le: aujourdhui() });
    journal.ajouter('Création', `Client ${c.nom}`);
    return client;
  });
}

function modifier(id, data) {
  const c = nettoyer(data);
  return base.transaction(() => {
    const client = base.table('clients').modifier(id, c);
    if (!client) throw new ErreurMetier('Client introuvable.', 404);
    journal.ajouter('Modification', `Client ${c.nom}`);
    return client;
  });
}

function supprimer(id) {
  const client = base.table('clients').trouver(id);
  if (!client) throw new ErreurMetier('Client introuvable.', 404);
  const nb = base.table('factures').compter((f) => f.client_id === client.id);
  if (nb > 0) {
    throw new ErreurMetier(`« ${client.nom} » a ${nb} facture(s) : il ne peut pas être supprimé. Supprimez d'abord ses factures si vous en êtes sûr.`, 409);
  }
  base.transaction(() => {
    base.table('clients').supprimerOu((c) => c.id === client.id);
    journal.ajouter('Suppression', `Client ${client.nom}`);
  });
  return { ok: true };
}

module.exports = { lister, creer, modifier, supprimer };
