const base = require('../../database/base');
const contexte = require('../contexte');
const factures = require('./factures');
const devis = require('./devis');
const mouvements = require('./mouvements');
const { STATUT } = require('../../database/constantes');
const { aujourdhui } = require('../../database/temps');

function derniersMois(n = 6) {
  const maintenant = new Date();
  const mois = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(maintenant.getFullYear(), maintenant.getMonth() - i, 1);
    mois.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  }
  return mois;
}

function resume() {
  const resultat = {};

  if (contexte.peut('factures.voir')) {
    const toutes = factures.lister();
    const validees = toutes.filter((f) => f.statut === STATUT.VALIDEE);
    const dues = validees.filter((f) => f.paiement !== 'payée');
    const enRetard = dues.filter((f) => f.en_retard);
    const mois = aujourdhui().slice(0, 7);
    const visibles = new Set(toutes.map((f) => f.id));
    const encaisseMois = base.table('paiements').ou((p) => visibles.has(p.facture_id) && p.date_paiement.startsWith(mois))
      .reduce((s, p) => s + p.montant, 0);
    const somme = (liste, champ) => liste.reduce((s, f) => s + f[champ], 0);

    resultat.facturation = {
      a_encaisser: { nb: dues.length, montant: somme(dues, 'reste') },
      en_retard: { nb: enRetard.length, montant: somme(enRetard, 'montant_en_retard') },
      brouillons: toutes.filter((f) => f.statut === STATUT.BROUILLON).length,
      encaisse_mois: encaisseMois,
      ca_mensuel: derniersMois().map((m) => ({
        mois: m,
        total: somme(validees.filter((f) => f.date_facture.startsWith(m)), 'total_ht'),
      })),
    };
  }

  if (contexte.peut('devis.voir')) {
    const tous = devis.lister();
    const somme = (liste) => liste.reduce((s, d) => s + d.total_ttc, 0);
    const enCours = tous.filter((d) => (d.statut === 'brouillon' || d.statut === 'envoyé') && !d.expire);
    const aFacturer = tous.filter((d) => d.statut === 'accepté');
    resultat.devis = {
      en_cours: { nb: enCours.length, montant: somme(enCours) },
      a_facturer: { nb: aFacturer.length, montant: somme(aFacturer) },
    };
  }

  if (contexte.peut('articles.voir')) {
    const articles = base.table('produits').ou((p) => p.type === 'produit');
    resultat.inventaire = {
      nb_articles: articles.length,
      alertes: articles.filter((p) => p.stock <= p.seuil_alerte).sort((a, b) => a.stock - b.stock)
        .map(({ cout, ...p }) => p),
    };
    if (contexte.peut('articles.couts')) {
      resultat.inventaire.valeur_stock = articles.reduce((s, p) => s + p.stock * (p.cout || p.prix_unitaire), 0);
    }
    if (contexte.peut('stock.voir')) resultat.inventaire.derniers_mouvements = mouvements.lister({ limite: 5 });
  }
  return resultat;
}

module.exports = { resume };
