const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const journal = require('./journal');
const mouvements = require('./mouvements');
const produits = require('./produits');
const { arrondir } = require('../../database/calculs');
const { TYPE_MOUVEMENT } = require('../../database/constantes');

function article(id) {
  const p = base.table('produits').trouver(id);
  if (!p) throw new ErreurMetier('Article introuvable.', 404);
  if (p.type === 'service') throw new ErreurMetier('Un service n\'a pas de stock.', 409);
  return p;
}

function quantite(valeur, libelle = 'La quantité') {
  const q = parseInt(valeur);
  if (!(q > 0)) throw new ErreurMetier(`${libelle} doit être un nombre entier supérieur à 0.`);
  return q;
}

function reception(data) {
  const p = article(data.produit_id);
  const q = quantite(data.quantite, 'La quantité reçue');
  const coutRecu = Number(data.cout_unitaire) || 0;
  if (coutRecu < 0) throw new ErreurMetier('Le coût unitaire doit être positif.');
  const fournisseur = String(data.fournisseur ?? '').trim();
  const reference = String(data.reference ?? '').trim();
  const motif = `Réception${fournisseur ? ' — ' + fournisseur : ''}${reference ? ' (' + reference + ')' : ''}`;

  return base.transaction(() => {
    const changements = { stock: p.stock + q };
    if (coutRecu > 0) {
      changements.cout = p.cout > 0 && p.stock > 0 ? arrondir((p.stock * p.cout + q * coutRecu) / (p.stock + q), 2) : coutRecu;
    }
    const maj = base.table('produits').modifier(p.id, changements);
    mouvements.enregistrer(p.id, q, TYPE_MOUVEMENT.RECEPTION, motif);
    journal.ajouter('Mouvement de stock', p.designation, `+${q} · ${motif}`);
    return produits.masquer(maj);
  });
}

function sortie(data) {
  const p = article(data.produit_id);
  const q = quantite(data.quantite, 'La quantité sortie');
  const motif = String(data.motif ?? '').trim();
  if (!motif) throw new ErreurMetier('Indiquez le motif de la sortie (casse, perte, usage interne…).');
  if (q > p.stock) throw new ErreurMetier(`Stock insuffisant pour « ${p.designation} » : ${p.stock} disponible(s).`, 409);

  return base.transaction(() => {
    const maj = base.table('produits').modifier(p.id, { stock: p.stock - q });
    mouvements.enregistrer(p.id, -q, TYPE_MOUVEMENT.SORTIE, motif);
    journal.ajouter('Mouvement de stock', p.designation, `-${q} · ${motif}`);
    return produits.masquer(maj);
  });
}

function ajustement(data) {
  const p = article(data.produit_id);
  const reel = parseInt(data.quantite_reelle);
  if (!(reel >= 0)) throw new ErreurMetier('La quantité comptée doit être un nombre entier (0 ou plus).');
  const ecart = reel - p.stock;
  if (ecart === 0) throw new ErreurMetier(`Le stock compté (${reel}) est identique au stock enregistré : rien à ajuster.`);
  const motif = String(data.motif ?? '').trim() || 'Inventaire physique';

  return base.transaction(() => {
    const maj = base.table('produits').modifier(p.id, { stock: reel });
    mouvements.enregistrer(p.id, ecart, TYPE_MOUVEMENT.AJUSTEMENT, `${motif} (compté : ${reel}, avant : ${p.stock})`);
    journal.ajouter('Mouvement de stock', p.designation, `Inventaire : ${p.stock} → ${reel}`);
    return produits.masquer(maj);
  });
}

module.exports = { reception, sortie, ajustement };
