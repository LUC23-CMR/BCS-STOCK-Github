const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const contexte = require('../contexte');
const journal = require('./journal');
const factures = require('./factures');
const { arrondir } = require('../../database/calculs');
const { STATUT, MODES_PAIEMENT } = require('../../database/constantes');
const { aujourdhui } = require('../../database/temps');

function lister() {
  const parId = new Map(factures.lister().map((f) => [f.id, f]));
  return base.table('paiements').tous()
    .filter((p) => parId.has(p.facture_id))
    .sort((a, b) => b.date_paiement.localeCompare(a.date_paiement) || b.id - a.id)
    .map((p) => ({ ...p, numero: parId.get(p.facture_id).numero, client_nom: parId.get(p.facture_id).client_nom }));
}

function enregistrer(factureId, data) {
  const facture = factures.lire(factureId);
  if (facture.statut !== STATUT.VALIDEE) throw new ErreurMetier('Seule une facture validée peut être payée.', 409);
  const montant = arrondir(Number(data.montant), 2);
  if (!(montant > 0)) throw new ErreurMetier('Le montant du paiement doit être supérieur à 0.');
  if (montant > facture.reste + 0.0049) throw new ErreurMetier(`Le montant dépasse le reste dû (${facture.reste}).`, 409);
  const date = data.date_paiement || aujourdhui();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date))) throw new ErreurMetier('La date du paiement est invalide.');
  const mode = MODES_PAIEMENT.includes(data.mode) ? data.mode : 'Autre';

  return base.transaction(() => {
    base.table('paiements').ajouter({
      facture_id: facture.id, date_paiement: date, montant, mode,
      reference: String(data.reference ?? '').trim(), utilisateur: contexte.nomActeur(),
    });
    journal.ajouter('Paiement', `Facture ${facture.numero}`, `${montant} ${base.parametres().devise} · ${mode}`);
    return factures.lire(facture.id);
  });
}

function supprimer(id) {
  const p = base.table('paiements').trouver(id);
  if (!p) throw new ErreurMetier('Paiement introuvable.', 404);
  const facture = factures.lire(p.facture_id);
  base.transaction(() => {
    base.table('paiements').supprimerOu((x) => x.id === p.id);
    journal.ajouter('Suppression', `Paiement de la facture ${facture.numero}`, `${p.montant} · ${p.mode}`);
  });
  return { ok: true };
}

module.exports = { lister, enregistrer, supprimer };
