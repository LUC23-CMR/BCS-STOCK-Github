const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const journal = require('./journal');
const { TOUTES, MODULES, IMPLIQUE, avecImplications } = require('../../database/permissions');

function permissionsDuRole(nomRole) {
  const role = base.table('roles').premier((r) => r.nom === nomRole);
  if (!role) return new Set();
  if (role.systeme) return new Set(TOUTES);
  return avecImplications(TOUTES.filter((code) => role[code]));
}

function vue(role) {
  return {
    id: role.id, nom: role.nom, description: role.description, systeme: role.systeme,
    permissions: [...permissionsDuRole(role.nom)],
    nb_utilisateurs: base.table('utilisateurs').compter((u) => u.role === role.nom),
  };
}

const lister = () => base.table('roles').tous().map(vue);

const definitions = () => ({ modules: MODULES, implique: IMPLIQUE });

function garantirAdministrateur() {
  const ok = base.table('utilisateurs').ou((u) => u.actif).some((u) => {
    const droits = permissionsDuRole(u.role);
    return droits.has('admin.utilisateurs') && droits.has('admin.roles');
  });
  if (!ok) throw new ErreurMetier('Il doit rester au moins un administrateur actif (avec les droits « Gérer les utilisateurs » et « Gérer les rôles »).', 409);
}

function nettoyer(data, idExistant) {
  const nom = String(data.nom ?? '').trim();
  if (!nom) throw new ErreurMetier('Saisissez le nom du rôle.');
  if (base.table('roles').premier((r) => r.nom.toLowerCase() === nom.toLowerCase() && r.id !== idExistant)) {
    throw new ErreurMetier(`Un rôle « ${nom} » existe déjà.`);
  }
  const droits = avecImplications(Array.isArray(data.permissions) ? data.permissions : []);
  const ligne = { nom, description: String(data.description ?? '').trim() };
  for (const code of TOUTES) ligne[code] = droits.has(code);
  return ligne;
}

function creer(data) {
  const ligne = nettoyer(data);
  return base.transaction(() => {
    const role = base.table('roles').ajouter({ ...ligne, systeme: false });
    journal.ajouter('Création', `Rôle ${role.nom}`, `${vue(role).permissions.length} droit(s)`);
    return vue(role);
  });
}

function modifier(id, data) {
  const role = base.table('roles').trouver(id);
  if (!role) throw new ErreurMetier('Rôle introuvable.', 404);
  if (role.systeme) throw new ErreurMetier('Le rôle Administrateur ne peut pas être modifié : il a toujours tous les droits.', 409);
  const ligne = nettoyer(data, role.id);
  return base.transaction(() => {
    base.table('roles').modifier(role.id, ligne);
    for (const u of base.table('utilisateurs').ou((u) => u.role === role.nom)) base.table('utilisateurs').modifier(u.id, { role: ligne.nom });
    garantirAdministrateur();
    journal.ajouter('Modification', `Rôle ${ligne.nom}`, 'Droits modifiés');
    return vue(base.table('roles').trouver(role.id));
  });
}

function supprimer(id) {
  const role = base.table('roles').trouver(id);
  if (!role) throw new ErreurMetier('Rôle introuvable.', 404);
  if (role.systeme) throw new ErreurMetier('Le rôle Administrateur ne peut pas être supprimé.', 409);
  const nb = base.table('utilisateurs').compter((u) => u.role === role.nom);
  if (nb > 0) throw new ErreurMetier(`Ce rôle est attribué à ${nb} utilisateur(s) : changez leur rôle d'abord.`, 409);
  base.transaction(() => {
    base.table('roles').supprimerOu((r) => r.id === role.id);
    journal.ajouter('Suppression', `Rôle ${role.nom}`);
  });
  return { ok: true };
}

module.exports = { permissionsDuRole, lister, definitions, creer, modifier, supprimer, garantirAdministrateur };
