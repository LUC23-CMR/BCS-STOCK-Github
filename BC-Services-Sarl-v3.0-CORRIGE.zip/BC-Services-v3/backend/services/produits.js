const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const contexte = require('../contexte');
const journal = require('./journal');
const mouvements = require('./mouvements');
const { TYPE_MOUVEMENT } = require('../../database/constantes');

function masquer(p) {
  if (contexte.peut('articles.couts')) return p;
  const { cout, ...reste } = p;
  return reste;
}

function lister() {
  const ordre = base.table('categories').tous().map((c) => c.nom);
  const fourMap = new Map((base.table('fournisseurs').tous() || []).map((f) => [f.id, f.nom]));
  return base.table('produits').tous()
    .sort((a, b) => ordre.indexOf(a.categorie) - ordre.indexOf(b.categorie) || a.designation.localeCompare(b.designation, 'fr'))
    .map((p) => {
      const enrichi = { ...p, fournisseur_nom: fourMap.get(p.fournisseur_id) || '' };
      return masquer(enrichi);
    });
}

function lire(id) {
  const produit = base.table('produits').trouver(id);
  if (!produit) throw new ErreurMetier('Article introuvable.', 404);
  return masquer(produit);
}

function nettoyer(data) {
  const designation = String(data.designation ?? '').trim();
  if (!designation) throw new ErreurMetier('Saisissez la désignation de l\'article.');

  const categorie = base.table('categories').premier((c) => c.nom.toLowerCase() === String(data.categorie ?? '').trim().toLowerCase());
  if (!categorie) throw new ErreurMetier('Catégorie inconnue. Ajoutez-la d\'abord dans Administration > Réglages.');

  const prix = Number(data.prix_unitaire);
  if (!(prix >= 0)) throw new ErreurMetier('Le prix doit être un nombre positif.');
  const resultat = {
    reference: String(data.reference ?? '').trim(),
    designation,
    categorie: categorie.nom,
    type: data.type === 'service' ? 'service' : 'produit',
    unite: String(data.unite ?? '').trim() || 'pièce',
    prix_unitaire: prix,
    seuil_alerte: parseInt(data.seuil_alerte) || 0,
    fournisseur_id: parseInt(data.fournisseur_id) || 0,
  };
  if ('cout' in data && contexte.peut('articles.couts')) {
    const cout = Number(data.cout) || 0;
    if (cout < 0) throw new ErreurMetier('Le coût d\'achat doit être positif.');
    resultat.cout = cout;
  }
  if (resultat.type === 'service') resultat.seuil_alerte = 0;
  return resultat;
}

function creer(data) {
  const p = nettoyer(data);
  const stockInitial = p.type === 'service' ? 0 : Math.max(0, parseInt(data.stock) || 0);
  return base.transaction(() => {
    const produit = base.table('produits').ajouter({ ...p, stock: stockInitial });
    if (stockInitial > 0) mouvements.enregistrer(produit.id, stockInitial, TYPE_MOUVEMENT.INITIAL, 'Stock initial');
    journal.ajouter('Création', `Article ${p.designation}`, p.reference);
    return masquer(produit);
  });
}

function modifier(id, data) {
  const avant = base.table('produits').trouver(id);
  if (!avant) throw new ErreurMetier('Article introuvable.', 404);
  const p = nettoyer(data);
  if (avant.type === 'produit' && p.type === 'service' && avant.stock !== 0) {
    throw new ErreurMetier('Cet article a du stock : remettez-le à zéro par un inventaire avant d\'en faire un service.', 409);
  }
  return base.transaction(() => {
    const produit = base.table('produits').modifier(id, p);
    journal.ajouter('Modification', `Article ${p.designation}`);
    return masquer(produit);
  });
}

function supprimer(id) {
  const produit = base.table('produits').trouver(id);
  if (!produit) throw new ErreurMetier('Article introuvable.', 404);
  base.transaction(() => {
    for (const l of base.table('lignes').ou((l) => l.produit_id === produit.id)) base.table('lignes').modifier(l.id, { produit_id: 0 });
    base.table('mouvements').supprimerOu((m) => m.produit_id === produit.id);
    base.table('produits').supprimerOu((p) => p.id === produit.id);
    journal.ajouter('Suppression', `Article ${produit.designation}`);
  });
  return { ok: true };
}

module.exports = { lister, lire, creer, modifier, supprimer, masquer };
