const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const contexte = require('../contexte');
const journal = require('./journal');
const mouvements = require('./mouvements');
const tranches = require('./tranches');
const calculs = require('../../database/calculs');
const { STATUT, TYPE_MOUVEMENT } = require('../../database/constantes');
const { aujourdhui, ajouterJours } = require('../../database/temps');

function visible(f) {
  const a = contexte.acteur();
  return !a || a.permissions.has('factures.toutes') || f.cree_par_id === a.id;
}

function grouper(liste, cle) {
  const m = new Map();
  for (const x of liste) { if (!m.has(x[cle])) m.set(x[cle], []); m.get(x[cle]).push(x); }
  return m;
}

function cache() {
  return {
    decimales: base.parametres().decimales,
    clients: new Map(base.table('clients').tous().map((c) => [c.id, c])),
    lignes: grouper(base.table('lignes').tous(), 'facture_id'),
    paiements: grouper(base.table('paiements').tous(), 'facture_id'),
    tranches: tranches.tousParDocument('facture'),
  };
}

function enrichir(f, c) {
  const lignes = c.lignes.get(f.id) || [];
  const totaux = calculs.totauxLignes(lignes, f.tva, c.decimales);
  const paye = calculs.arrondir(calculs.somme(c.paiements.get(f.id) || [], 'montant'), 2);
  const validee = f.statut === STATUT.VALIDEE;
  const paiement = validee ? calculs.etatPaiement(totaux.total_ttc, paye) : null;
  const plan = c.tranches.get(f.id) || [];
  const echeancier = plan.length ? calculs.echeancier(plan, totaux.total_ttc, paye, c.decimales, f.date_facture) : [];
  const reste = validee ? Math.max(0, calculs.arrondir(totaux.total_ttc - paye, 2)) : 0;
  const nonPayee = validee && paiement !== 'payée';
  const enRetard = plan.length
    ? nonPayee && echeancier.some((t) => t.en_retard)
    : !!(nonPayee && f.date_echeance && f.date_echeance < aujourdhui());
  const montantEnRetard = !enRetard ? 0
    : plan.length ? calculs.arrondir(calculs.somme(echeancier.filter((t) => t.en_retard), 'reste'), 2) : reste;
  return {
    ...f,
    client_nom: (c.clients.get(f.client_id) || {}).nom || '(client supprimé)',
    ...totaux,
    paye,
    reste,
    paiement,
    tranches: echeancier,
    nb_tranches: echeancier.length,
    tranches_payees: echeancier.filter((t) => t.statut === 'payée').length,
    prochaine_tranche: nonPayee ? echeancier.find((t) => t.statut !== 'payée') || null : null,
    en_retard: enRetard,
    montant_en_retard: montantEnRetard,
  };
}

function toutesEnrichies() {
  const c = cache();
  return base.table('factures').tous().map((f) => enrichir(f, c));
}

function lister() {
  return toutesEnrichies().filter(visible).sort((a, b) => b.id - a.id);
}

const libelle = (f) => (f.numero ? `Facture ${f.numero}` : `Brouillon #${f.id}`);

function lire(id) {
  const f = base.table('factures').trouver(id);
  if (!f || !visible(f)) throw new ErreurMetier('Facture introuvable.', 404);
  const c = cache();
  return {
    ...enrichir(f, c),
    client: c.clients.get(f.client_id) || { nom: '(client supprimé)', telephone: '', email: '', adresse: '' },
    lignes: (c.lignes.get(f.id) || []).sort((a, b) => a.id - b.id),
    paiements: (c.paiements.get(f.id) || []).sort((a, b) => a.date_paiement.localeCompare(b.date_paiement) || a.id - b.id),
    historique: journal.historique([`Brouillon #${f.id}`, ...(f.numero ? [`Facture ${f.numero}`] : [])]),
  };
}

function verifierDonnees(data) {
  const client = base.table('clients').trouver(data.client_id);
  if (!client) throw new ErreurMetier('Choisissez un client.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(data.date_facture))) throw new ErreurMetier('La date de la facture est invalide.');
  const tva = Number(data.tva);
  if (!(tva >= 0 && tva <= 100)) throw new ErreurMetier('Le taux de TVA est invalide.');
  const conditions = data.conditions === undefined || data.conditions === '' ? base.parametres().conditionsParDefaut : Number(data.conditions);
  if (!(conditions >= 0 && Number.isInteger(conditions))) throw new ErreurMetier('Le délai de paiement est invalide.');
  if (!Array.isArray(data.lignes) || data.lignes.length === 0) throw new ErreurMetier('Ajoutez au moins une ligne à la facture.');

  const lignes = data.lignes.map((l) => {
    const produit = base.table('produits').trouver(l.produit_id);
    if (!produit) throw new ErreurMetier('Un des articles de la facture n\'existe plus.');
    const quantite = parseInt(l.quantite);
    const prix = Number(l.prix_unitaire);
    if (!(quantite > 0)) throw new ErreurMetier(`Quantité invalide pour « ${produit.designation} ».`);
    if (!(prix >= 0)) throw new ErreurMetier(`Prix invalide pour « ${produit.designation} ».`);
    return { produit, quantite, prix };
  });
  const mode = String(data.mode_paiement ?? '').trim();
  const dateEcheanceLibre = data.date_echeance ? String(data.date_echeance).slice(0, 10) : '';
  return {
    client, date: data.date_facture, tva, conditions, lignes, plan: tranches.normaliser(data.tranches),
    mode_paiement: mode, date_echeance: dateEcheanceLibre,
  };
}

function ecrireLignes(factureId, numero, lignes) {
  for (const l of lignes) {
    base.table('lignes').ajouter({
      facture_id: factureId, numero_facture: numero, produit_id: l.produit.id, designation: l.produit.designation,
      quantite: l.quantite, prix_unitaire: l.prix,
    });
  }
}

function creer(data) {
  contexte.exigerDroit('factures.creer');
  if (data.valider) contexte.exigerDroit('factures.valider');
  const d = verifierDonnees(data);
  return base.transaction(() => {
    const a = contexte.acteur();
    const f = base.table('factures').ajouter({
      numero: '', client_id: d.client.id, date_facture: d.date, conditions: d.conditions,
      date_echeance: d.date_echeance || '', mode_paiement: d.mode_paiement,
      tva: d.tva, statut: STATUT.BROUILLON, cree_par: a ? a.nom : '', cree_par_id: a ? a.id : 0,
    });
    ecrireLignes(f.id, '', d.lignes);
    tranches.ecrire('facture', f.id, d.plan);
    journal.ajouter('Création', libelle(f), `Client : ${d.client.nom}`);
    if (data.valider) validerDansTransaction(f.id);
    return lire(f.id);
  });
}

function modifier(id, data) {
  contexte.exigerDroit('factures.creer');
  if (data.valider) contexte.exigerDroit('factures.valider');
  const f = base.table('factures').trouver(id);
  if (!f || !visible(f)) throw new ErreurMetier('Facture introuvable.', 404);
  if (f.statut !== STATUT.BROUILLON) throw new ErreurMetier('Seul un brouillon peut être modifié. Annulez la facture validée pour en refaire une.', 409);
  const d = verifierDonnees(data);
  return base.transaction(() => {
    base.table('factures').modifier(f.id, {
      client_id: d.client.id, date_facture: d.date, conditions: d.conditions, tva: d.tva,
      mode_paiement: d.mode_paiement, date_echeance: d.date_echeance || f.date_echeance || '',
    });
    base.table('lignes').supprimerOu((l) => l.facture_id === f.id);
    ecrireLignes(f.id, '', d.lignes);
    tranches.ecrire('facture', f.id, d.plan);
    journal.ajouter('Modification', libelle(f), `Client : ${d.client.nom}`);
    if (data.valider) validerDansTransaction(f.id);
    return lire(f.id);
  });
}

function prochainNumero(annee) {
  const prefixe = `${base.parametres().prefixeFacture}-${annee}-`;
  const dernier = base.table('factures').ou((f) => f.numero.startsWith(prefixe))
    .map((f) => parseInt(f.numero.slice(prefixe.length)) || 0)
    .reduce((max, n) => Math.max(max, n), 0);
  return prefixe + String(dernier + 1).padStart(4, '0');
}

function validerDansTransaction(id) {
  const f = base.table('factures').trouver(id);
  if (!f || f.statut !== STATUT.BROUILLON) throw new ErreurMetier('Seul un brouillon peut être validé.', 409);
  const lignes = base.table('lignes').ou((l) => l.facture_id === f.id);

  const demandes = new Map();
  for (const l of lignes) {
    const p = base.table('produits').trouver(l.produit_id);
    if (!p) throw new ErreurMetier(`L'article « ${l.designation} » n'existe plus : retirez cette ligne du brouillon.`, 409);
    if (p.type === 'produit') demandes.set(p.id, (demandes.get(p.id) || 0) + l.quantite);
  }
  for (const [produitId, total] of demandes) {
    const p = base.table('produits').trouver(produitId);
    if (total > p.stock) throw new ErreurMetier(`Stock insuffisant pour « ${p.designation} » : ${p.stock} disponible(s).`, 409);
  }

  const numero = prochainNumero(f.date_facture.slice(0, 4));
  for (const l of lignes) {
    base.table('lignes').modifier(l.id, { numero_facture: numero });
    const p = base.table('produits').trouver(l.produit_id);
    if (p.type === 'produit') {
      base.table('produits').modifier(p.id, { stock: p.stock - l.quantite });
      mouvements.enregistrer(p.id, -l.quantite, TYPE_MOUVEMENT.LIVRAISON, `Facture ${numero}`, f.date_facture);
    }
  }
  const plan = tranches.lire('facture', f.id);
  const delaiFinal = plan.length ? Math.max(...plan.map((t) => t.delai_jours)) : f.conditions;
  const echeance = (f.date_echeance && /^\d{4}-\d{2}-\d{2}$/.test(f.date_echeance))
    ? f.date_echeance
    : ajouterJours(f.date_facture, delaiFinal);
  base.table('factures').modifier(f.id, { numero, statut: STATUT.VALIDEE, date_echeance: echeance });
  journal.ajouter('Validation', `Facture ${numero}`, `Brouillon #${f.id} validé`);
}

function valider(id) {
  contexte.exigerDroit('factures.valider');
  const f = base.table('factures').trouver(id);
  if (!f || !visible(f)) throw new ErreurMetier('Facture introuvable.', 404);
  return base.transaction(() => { validerDansTransaction(f.id); return lire(f.id); });
}

function annuler(id) {
  contexte.exigerDroit('factures.annuler');
  const f = base.table('factures').trouver(id);
  if (!f || !visible(f)) throw new ErreurMetier('Facture introuvable.', 404);
  if (f.statut !== STATUT.VALIDEE) throw new ErreurMetier('Seule une facture validée peut être annulée.', 409);
  if (base.table('paiements').compter((p) => p.facture_id === f.id) > 0) {
    throw new ErreurMetier('Cette facture a des paiements : supprimez-les d\'abord (Paiements).', 409);
  }
  return base.transaction(() => {
    for (const l of base.table('lignes').ou((l) => l.facture_id === f.id)) {
      const p = base.table('produits').trouver(l.produit_id);
      if (p && p.type === 'produit') {
        base.table('produits').modifier(p.id, { stock: p.stock + l.quantite });
        mouvements.enregistrer(p.id, l.quantite, TYPE_MOUVEMENT.ANNULATION, `Annulation ${f.numero}`);
      }
    }
    base.table('factures').modifier(f.id, { statut: STATUT.ANNULEE });
    journal.ajouter('Annulation', `Facture ${f.numero}`);
    return lire(f.id);
  });
}

function supprimer(id) {
  contexte.exigerDroit('factures.supprimer');
  const f = base.table('factures').trouver(id);
  if (!f || !visible(f)) throw new ErreurMetier('Facture introuvable.', 404);
  if (f.statut !== STATUT.BROUILLON) throw new ErreurMetier('Une facture validée ne peut pas être supprimée : annulez-la.', 409);
  base.transaction(() => {
    base.table('lignes').supprimerOu((l) => l.facture_id === f.id);
    tranches.supprimer('facture', f.id);
    base.table('factures').supprimerOu((x) => x.id === f.id);
    journal.ajouter('Suppression', libelle(f));
  });
  return { ok: true };
}

module.exports = { lister, lire, creer, modifier, valider, annuler, supprimer, toutesEnrichies, visible, cache, enrichir };
