const base = require('../../database/base');
const { ErreurMetier } = require('../erreurs');
const contexte = require('../contexte');
const journal = require('./journal');
const factures = require('./factures');
const tranches = require('./tranches');
const calculs = require('../../database/calculs');
const { STATUT_DEVIS: S } = require('../../database/constantes');
const { aujourdhui, ajouterJours } = require('../../database/temps');

function visible(d) {
  const a = contexte.acteur();
  return !a || a.permissions.has('devis.toutes') || d.cree_par_id === a.id;
}

function cache() {
  const lignes = new Map();
  for (const l of base.table('lignes_devis').tous()) {
    if (!lignes.has(l.devis_id)) lignes.set(l.devis_id, []);
    lignes.get(l.devis_id).push(l);
  }
  return {
    decimales: base.parametres().decimales,
    clients: new Map(base.table('clients').tous().map((c) => [c.id, c])),
    lignes,
    tranches: tranches.tousParDocument('devis'),
  };
}

function enrichir(d, c) {
  const totaux = calculs.totauxLignes(c.lignes.get(d.id) || [], d.tva, c.decimales);
  const ouvert = d.statut === S.BROUILLON || d.statut === S.ENVOYE;
  return {
    ...d,
    client_nom: (c.clients.get(d.client_id) || {}).nom || '(client supprimé)',
    ...totaux,
    tranches: calculs.repartirTranches(totaux.total_ttc, c.tranches.get(d.id) || [], c.decimales),
    expire: ouvert && !!d.date_validite && d.date_validite < aujourdhui(),
  };
}

function toutesEnrichies() {
  const c = cache();
  return base.table('devis').tous().map((d) => enrichir(d, c));
}

const lister = () => toutesEnrichies().filter(visible).sort((a, b) => b.id - a.id);

function lire(id) {
  const d = base.table('devis').trouver(id);
  if (!d || !visible(d)) throw new ErreurMetier('Devis introuvable.', 404);
  const c = cache();
  const facture = d.facture_id ? base.table('factures').trouver(d.facture_id) : null;
  return {
    ...enrichir(d, c),
    client: c.clients.get(d.client_id) || { nom: '(client supprimé)', telephone: '', email: '', adresse: '' },
    lignes: (c.lignes.get(d.id) || []).sort((a, b) => a.id - b.id),
    facture: facture ? { id: facture.id, numero: facture.numero, statut: facture.statut } : null,
    historique: journal.historique([`Devis ${d.numero}`]),
  };
}

function verifierDonnees(data) {
  const client = base.table('clients').trouver(data.client_id);
  if (!client) throw new ErreurMetier('Choisissez un client.');
  const date = String(data.date_devis);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new ErreurMetier('La date du devis est invalide.');
  const tva = Number(data.tva);
  if (!(tva >= 0 && tva <= 100)) throw new ErreurMetier('Le taux de TVA est invalide.');

  let validite = data.date_validite;
  if (!validite) {
    const jours = data.validite_jours === undefined || data.validite_jours === '' ? base.parametres().validiteDevis : Number(data.validite_jours);
    if (!(jours >= 0 && Number.isInteger(jours))) throw new ErreurMetier('La durée de validité est invalide.');
    validite = ajouterJours(date, jours);
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(validite))) throw new ErreurMetier('La date de validité est invalide.');
  if (validite < date) throw new ErreurMetier('Le devis ne peut pas expirer avant sa date.');

  if (!Array.isArray(data.lignes) || data.lignes.length === 0) throw new ErreurMetier('Ajoutez au moins une ligne au devis.');
  const lignes = data.lignes.map((l) => {
    const produit = base.table('produits').trouver(l.produit_id);
    if (!produit) throw new ErreurMetier('Un des articles du devis n\'existe plus.');
    const quantite = parseInt(l.quantite);
    const prix = Number(l.prix_unitaire);
    if (!(quantite > 0)) throw new ErreurMetier(`Quantité invalide pour « ${produit.designation} ».`);
    if (!(prix >= 0)) throw new ErreurMetier(`Prix invalide pour « ${produit.designation} ».`);
    return { produit, quantite, prix };
  });
  const mode = String(data.mode_paiement ?? '').trim();
  const dateEcheance = data.date_echeance ? String(data.date_echeance).slice(0, 10) : '';
  return {
    client, date, validite, tva, lignes, plan: tranches.normaliser(data.tranches),
    notes: String(data.notes ?? '').trim().slice(0, 1000),
    mode_paiement: mode, date_echeance: dateEcheance,
  };
}

function ecrireLignes(devisId, numero, lignes) {
  for (const l of lignes) {
    base.table('lignes_devis').ajouter({
      devis_id: devisId, numero_devis: numero, produit_id: l.produit.id, designation: l.produit.designation,
      quantite: l.quantite, prix_unitaire: l.prix,
    });
  }
}

function prochainNumero(annee) {
  const prefixe = `${base.parametres().prefixeDevis}-${annee}-`;
  const dernier = base.table('devis').ou((d) => d.numero.startsWith(prefixe))
    .map((d) => parseInt(d.numero.slice(prefixe.length)) || 0)
    .reduce((max, n) => Math.max(max, n), 0);
  return prefixe + String(dernier + 1).padStart(4, '0');
}

function creer(data) {
  const d = verifierDonnees(data);
  return base.transaction(() => {
    const a = contexte.acteur();
    const numero = prochainNumero(d.date.slice(0, 4));
    const devis = base.table('devis').ajouter({
      numero, date_devis: d.date, date_validite: d.validite, client_id: d.client.id, tva: d.tva,
      statut: S.BROUILLON, notes: d.notes, cree_par: a ? a.nom : '', cree_par_id: a ? a.id : 0,
      mode_paiement: d.mode_paiement, date_echeance: d.date_echeance,
    });
    ecrireLignes(devis.id, numero, d.lignes);
    tranches.ecrire('devis', devis.id, d.plan);
    journal.ajouter('Création', `Devis ${numero}`, `Client : ${d.client.nom}`);
    return lire(devis.id);
  });
}

function modifier(id, data) {
  const devis = base.table('devis').trouver(id);
  if (!devis || !visible(devis)) throw new ErreurMetier('Devis introuvable.', 404);
  if (devis.statut !== S.BROUILLON && devis.statut !== S.ENVOYE) {
    throw new ErreurMetier('Ce devis est accepté, refusé ou déjà facturé : il ne peut plus être modifié. Remettez-le en brouillon si besoin.', 409);
  }
  const d = verifierDonnees(data);
  return base.transaction(() => {
    base.table('devis').modifier(devis.id, {
      date_devis: d.date, date_validite: d.validite, client_id: d.client.id, tva: d.tva, notes: d.notes,
      mode_paiement: d.mode_paiement, date_echeance: d.date_echeance,
    });
    base.table('lignes_devis').supprimerOu((l) => l.devis_id === devis.id);
    ecrireLignes(devis.id, devis.numero, d.lignes);
    tranches.ecrire('devis', devis.id, d.plan);
    journal.ajouter('Modification', `Devis ${devis.numero}`, `Client : ${d.client.nom}`);
    return lire(devis.id);
  });
}

const TRANSITIONS = {
  [S.BROUILLON]: [S.ENVOYE, S.ACCEPTE, S.REFUSE],
  [S.ENVOYE]: [S.BROUILLON, S.ACCEPTE, S.REFUSE],
  [S.ACCEPTE]: [S.BROUILLON, S.REFUSE],
  [S.REFUSE]: [S.BROUILLON],
  [S.FACTURE]: [],
};

function changerStatut(id, nouveau, raison_refus = '') {
  const devis = base.table('devis').trouver(id);
  if (!devis || !visible(devis)) throw new ErreurMetier('Devis introuvable.', 404);
  if (!(TRANSITIONS[devis.statut] || []).includes(nouveau)) {
    throw new ErreurMetier(`Un devis « ${devis.statut} » ne peut pas passer à « ${nouveau} ».`, 409);
  }
  if (nouveau === S.REFUSE && !String(raison_refus || '').trim()) {
    throw new ErreurMetier('Indiquez la raison du refus du devis.');
  }
  return base.transaction(() => {
    const maj = { statut: nouveau };
    if (nouveau === S.REFUSE) maj.raison_refus = String(raison_refus).trim();
    else if (nouveau === S.BROUILLON) maj.raison_refus = '';
    base.table('devis').modifier(devis.id, maj);
    const detail = nouveau === S.REFUSE ? `${devis.statut} → ${nouveau} : ${maj.raison_refus}` : `${devis.statut} → ${nouveau}`;
    journal.ajouter('Changement de statut', `Devis ${devis.numero}`, detail);
    return lire(devis.id);
  });
}

function facturer(id) {
  const devis = base.table('devis').trouver(id);
  if (!devis || !visible(devis)) throw new ErreurMetier('Devis introuvable.', 404);
  if (![S.BROUILLON, S.ENVOYE, S.ACCEPTE].includes(devis.statut)) {
    throw new ErreurMetier(devis.statut === S.FACTURE ? 'Ce devis est déjà facturé.' : 'Un devis refusé ne peut pas être facturé : remettez-le en brouillon.', 409);
  }
  const lignes = base.table('lignes_devis').ou((l) => l.devis_id === devis.id).map((l) => {
    if (!base.table('produits').trouver(l.produit_id)) {
      throw new ErreurMetier(`L'article « ${l.designation} » n'existe plus : modifiez le devis avant de le facturer.`, 409);
    }
    return { produit_id: l.produit_id, quantite: l.quantite, prix_unitaire: l.prix_unitaire };
  });

  return base.transaction(() => {
    const facture = factures.creer({
      client_id: devis.client_id, date_facture: aujourdhui(), tva: devis.tva,
      conditions: base.parametres().conditionsParDefaut, lignes,
      tranches: tranches.lire('devis', devis.id).map((t) => ({ libelle: t.libelle, pourcentage: t.pourcentage, delai_jours: t.delai_jours })),
    });
    base.table('devis').modifier(devis.id, { statut: S.FACTURE, facture_id: facture.id });
    journal.ajouter('Facturation', `Devis ${devis.numero}`, `Brouillon de facture #${facture.id} créé`);
    journal.ajouter('Conversion', `Brouillon #${facture.id}`, `Créé depuis le devis ${devis.numero}`);
    return { devis: lire(devis.id), facture };
  });
}

function supprimer(id) {
  const devis = base.table('devis').trouver(id);
  if (!devis || !visible(devis)) throw new ErreurMetier('Devis introuvable.', 404);
  if (devis.statut === S.FACTURE) throw new ErreurMetier('Ce devis a été transformé en facture : il ne peut pas être supprimé.', 409);
  base.transaction(() => {
    base.table('lignes_devis').supprimerOu((l) => l.devis_id === devis.id);
    tranches.supprimer('devis', devis.id);
    base.table('devis').supprimerOu((d) => d.id === devis.id);
    journal.ajouter('Suppression', `Devis ${devis.numero}`);
  });
  return { ok: true };
}

module.exports = { lister, lire, creer, modifier, changerStatut, facturer, supprimer, toutesEnrichies, visible };
