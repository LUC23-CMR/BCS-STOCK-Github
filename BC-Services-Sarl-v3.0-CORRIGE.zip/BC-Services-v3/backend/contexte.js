const { AsyncLocalStorage } = require('node:async_hooks');
const { ErreurMetier } = require('./erreurs');

const stockage = new AsyncLocalStorage();

const executer = (utilisateur, fn) => stockage.run({ utilisateur }, fn);
const acteur = () => (stockage.getStore() || {}).utilisateur || null;
const nomActeur = () => (acteur() ? acteur().nom : 'Système');
const peut = (droit) => !!acteur() && acteur().permissions.has(droit);

function exigerDroit(droit) {
  if (!peut(droit)) throw new ErreurMetier('Vous n\'avez pas le droit d\'effectuer cette action.', 403);
}

module.exports = { executer, acteur, nomActeur, peut, exigerDroit };
