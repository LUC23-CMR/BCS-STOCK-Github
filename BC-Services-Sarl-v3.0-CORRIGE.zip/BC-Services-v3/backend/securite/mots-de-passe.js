const crypto = require('node:crypto');
const { ErreurMetier } = require('../erreurs');

const COUT = 16384;
const LONGUEUR_MIN = 8;

function hacher(motDePasse) {
  const sel = crypto.randomBytes(16);
  const empreinte = crypto.scryptSync(motDePasse, sel, 32, { N: COUT });
  return `scrypt$${COUT}$${sel.toString('hex')}$${empreinte.toString('hex')}`;
}

function verifier(motDePasse, stocke) {
  const [algo, cout, sel, attendu] = String(stocke || '').split('$');
  if (algo !== 'scrypt' || !sel || !attendu) return false;
  const calcule = crypto.scryptSync(String(motDePasse), Buffer.from(sel, 'hex'), 32, { N: Number(cout) });
  const reference = Buffer.from(attendu, 'hex');
  return calcule.length === reference.length && crypto.timingSafeEqual(calcule, reference);
}

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
function generer(longueur = 10) {
  let resultat = '';
  for (let i = 0; i < longueur; i++) resultat += ALPHABET[crypto.randomInt(ALPHABET.length)];
  return resultat;
}

function verifierRegles(motDePasse) {
  if (String(motDePasse || '').length < LONGUEUR_MIN) {
    throw new ErreurMetier(`Le mot de passe doit contenir au moins ${LONGUEUR_MIN} caractères.`);
  }
}

const EMPREINTE_FACTICE = hacher('mot-de-passe-factice');

module.exports = { hacher, verifier, generer, verifierRegles, EMPREINTE_FACTICE, LONGUEUR_MIN };
