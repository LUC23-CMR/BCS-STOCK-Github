const crypto = require('node:crypto');
const config = require('../config');
const { ErreurMetier } = require('../erreurs');

const NOM_COOKIE = 'bc_session';
const sessions = new Map();

function nettoyer() {
  const maintenant = Date.now();
  for (const [jeton, s] of sessions) if (s.expire < maintenant) sessions.delete(jeton);
}

function creer(utilisateurId) {
  nettoyer();
  const jeton = crypto.randomBytes(32).toString('hex');
  sessions.set(jeton, { utilisateurId, expire: Date.now() + config.dureeSessionMs });
  return jeton;
}

function trouver(jeton) {
  const s = sessions.get(jeton);
  if (!s) return null;
  if (s.expire < Date.now()) { sessions.delete(jeton); return null; }
  s.expire = Date.now() + config.dureeSessionMs;
  return s.utilisateurId;
}

const detruire = (jeton) => sessions.delete(jeton);

function detruireDeUtilisateur(utilisateurId, sauf) {
  for (const [jeton, s] of sessions) if (s.utilisateurId === utilisateurId && jeton !== sauf) sessions.delete(jeton);
}

function lireCookie(req) {
  for (const morceau of String(req.headers.cookie || '').split(';')) {
    const [nom, ...valeur] = morceau.trim().split('=');
    if (nom === NOM_COOKIE) return valeur.join('=');
  }
  return null;
}

function enteteCookie(jeton) {
  const duree = jeton ? `Max-Age=${Math.floor(config.dureeSessionMs / 1000)}` : 'Max-Age=0';
  return `${NOM_COOKIE}=${jeton || ''}; HttpOnly; SameSite=Strict; Path=/; ${duree}`;
}

const echecs = new Map();
const MAX_ESSAIS = 5;
const BLOCAGE_MS = 5 * 60 * 1000;

function verifierBlocage(identifiant) {
  const e = echecs.get(identifiant);
  if (e && e.jusqua > Date.now()) {
    const minutes = Math.ceil((e.jusqua - Date.now()) / 60000);
    throw new ErreurMetier(`Trop d'essais. Réessayez dans ${minutes} minute(s).`, 429);
  }
}
function noterEchec(identifiant) {
  const e = echecs.get(identifiant) || { nombre: 0, jusqua: 0 };
  e.nombre = e.jusqua && e.jusqua < Date.now() ? 1 : e.nombre + 1;
  if (e.nombre >= MAX_ESSAIS) { e.jusqua = Date.now() + BLOCAGE_MS; e.nombre = 0; }
  echecs.set(identifiant, e);
}
const effacerEchecs = (identifiant) => echecs.delete(identifiant);

module.exports = { creer, trouver, detruire, detruireDeUtilisateur, lireCookie, enteteCookie, verifierBlocage, noterEchec, effacerEchecs };
