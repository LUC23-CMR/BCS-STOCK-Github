const fs = require('node:fs');
const path = require('node:path');

const racine = path.join(__dirname, '..');

const parDefaut = {
  fichierExcel: 'database/BC_Services_Base.xlsx',
  port: 3000,
  ouvrirNavigateur: true,
  fenetreApplication: true,
  arretAutomatiqueMinutes: 10,
  sauvegardeAuto: true,
  dureeSessionHeures: 8,
  hote: '',
};

function lireConfigurationJson() {
  const fichier = path.join(racine, 'configuration.json');
  if (!fs.existsSync(fichier)) return {};
  try {
    return JSON.parse(fs.readFileSync(fichier, 'utf8').replace(/^\uFEFF/, ''));
  } catch (erreur) {
    throw new Error(`configuration.json est invalide (${erreur.message}). Dans un chemin Windows, écrivez des / ou des \\\\ doublés, par exemple "D:/Donnees/base.xlsx".`);
  }
}

const reglages = { ...parDefaut, ...lireConfigurationJson() };

const fichierExcel = process.env.BC_EXCEL || reglages.fichierExcel;
if (!/\.xlsx$/i.test(fichierExcel)) {
  throw new Error(`"fichierExcel" doit se terminer par .xlsx (valeur actuelle : ${fichierExcel}).`);
}

module.exports = {
  port: Number(process.env.PORT) || Number(reglages.port) || 3000,
  fichierExcel: path.isAbsolute(fichierExcel) ? fichierExcel : path.join(racine, fichierExcel),
  ouvrirNavigateur: reglages.ouvrirNavigateur !== false,
  fenetreApplication: reglages.fenetreApplication !== false,
  arretAutomatiqueMinutes: Math.max(0, Number(reglages.arretAutomatiqueMinutes) || 0),
  dossierProjet: racine,
  sauvegardeAuto: reglages.sauvegardeAuto !== false,
  hote: String(reglages.hote || ''),
  dureeSessionMs: (Number(reglages.dureeSessionHeures) || 8) * 3600 * 1000,
  dossierFrontend: path.join(racine, 'frontend'),
};
