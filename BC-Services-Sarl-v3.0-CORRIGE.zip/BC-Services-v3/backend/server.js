const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { exec, spawn } = require('node:child_process');

const dossierProjetRacine = path.join(__dirname, '..');

function ecrireSignal(nomFichier, contenu) {
  try {
    fs.writeFileSync(path.join(dossierProjetRacine, nomFichier), '\ufeff' + contenu, 'utf16le');
  } catch (e) {
    try { fs.writeFileSync(path.join(dossierProjetRacine, nomFichier), contenu, 'utf8'); } catch {}
  }
}

function arreter(erreur) {
  console.error('\n  ERREUR : ' + erreur.message + '\n');
  ecrireSignal('erreur-demarrage.txt', erreur.message);
  process.exit(1);
}

// Signal immédiat de démarrage (avant tout chargement lourd)
if (require.main === module) {
  try { fs.writeFileSync(path.join(dossierProjetRacine, 'serveur.pid'), String(process.pid), 'utf8'); } catch {}
  console.log('  Démarrage BC Services…');
}

let config, router, base, auth, sessions, contexte;
try {
  config = require('./config');
  // Réparation automatique avant de charger la base (fichiers .tmp, base corrompue → sauvegarde)
  try {
    require('../outils/reparation').reparerAuDemarrage();
  } catch (e) {
    console.log('  [réparation] Avertissement : ' + e.message);
  }
  base = require('../database/base');
  router = require('./router');
  auth = require('./services/authentification');
  sessions = require('./securite/sessions');
  contexte = require('./contexte');
  require('./routes');
} catch (erreur) {
  if (require.main === module) arreter(erreur);
  throw erreur;
}

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json',
  '.webmanifest': 'application/manifest+json', '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
};

const ENTETES_SECURITE = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; frame-ancestors 'none'",
};

function envoyerJson(res, statut, donnees, entetes = {}) {
  res.writeHead(statut, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...ENTETES_SECURITE, ...entetes,
  });
  res.end(JSON.stringify(donnees));
}

function lireCorps(req) {
  return new Promise((resolve, reject) => {
    let texte = '';
    req.on('data', (morceau) => {
      texte += morceau;
      if (texte.length > 1e6) { reject(new Error('Requête trop volumineuse.')); req.destroy(); }
    });
    req.on('end', () => {
      try { resolve(texte ? JSON.parse(texte) : {}); }
      catch { reject(Object.assign(new Error('JSON invalide.'), { statut: 400 })); }
    });
  });
}

function origineAutorisee(req) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) || !req.headers.origin) return true;
  try { return new URL(req.headers.origin).host === req.headers.host; } catch { return false; }
}

async function traiterApi(req, res, url) {
  const trouve = router.trouver(req.method, url.pathname);
  if (!trouve) return envoyerJson(res, 404, { erreur: 'Route inconnue.' });
  const { route, params } = trouve;
  const options = route.options;
  const entetes = {};
  try {
    if (!origineAutorisee(req)) return envoyerJson(res, 403, { erreur: 'Requête refusée.' });
    base.rafraichir();

    const jeton = sessions.lireCookie(req);
    const utilisateur = options.public ? null : auth.depuisJeton(jeton);
    if (!options.public) {
      if (!utilisateur) return envoyerJson(res, 401, { erreur: 'Veuillez vous connecter.', code: 'NON_CONNECTE' });
      if (utilisateur.doitChangerMdp && !options.mdpTemporaire) {
        return envoyerJson(res, 403, { erreur: 'Vous devez d\'abord changer votre mot de passe.', code: 'MDP_TEMPORAIRE' });
      }
      const requis = [].concat(options.droit || []);
      if (requis.length && !requis.some((droit) => utilisateur.permissions.has(droit))) {
        return envoyerJson(res, 403, { erreur: 'Vous n\'avez pas le droit d\'effectuer cette action.', code: 'INTERDIT' });
      }
    }

    const corps = ['POST', 'PUT', 'PATCH'].includes(req.method) ? await lireCorps(req) : {};
    const ctx = { params, query: url.searchParams, corps, utilisateur, jeton, entetes, req };
    const donnees = await contexte.executer(utilisateur, () => route.gestionnaire(ctx));

    if (donnees && donnees.telechargement) {
      const { nom, type, contenu } = donnees.telechargement;
      res.writeHead(200, {
        'Content-Type': type, 'Content-Length': contenu.length, 'Cache-Control': 'no-store',
        'Content-Disposition': `attachment; filename="${nom}"`, ...ENTETES_SECURITE,
      });
      return res.end(contenu);
    }
    envoyerJson(res, route.statut, donnees, entetes);
  } catch (erreur) {
    if (erreur.statut) return envoyerJson(res, erreur.statut, { erreur: erreur.message });
    console.error(erreur);
    envoyerJson(res, 500, { erreur: 'Erreur interne du serveur.' });
  }
}

function servirFichier(res, url) {
  const demande = url.pathname === '/' ? '/index.html' : decodeURIComponent(url.pathname);
  const fichier = path.join(config.dossierFrontend, path.normalize(demande));
  if (!fichier.startsWith(config.dossierFrontend)) { res.writeHead(403); return res.end(); }
  fs.readFile(fichier, (erreur, contenu) => {
    if (erreur) { res.writeHead(404); return res.end('Page introuvable'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(fichier)] || 'application/octet-stream', ...ENTETES_SECURITE });
    res.end(contenu);
  });
}

let derniereActivite = Date.now();

function creerServeur() {
  return http.createServer((req, res) => {
    derniereActivite = Date.now();
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) traiterApi(req, res, url);
    else servirFichier(res, url);
  });
}

function ouvrirNavigateurParDefaut(adresse) {
  const commande = process.platform === 'win32' ? `start "" "${adresse}"`
    : process.platform === 'darwin' ? `open "${adresse}"` : `xdg-open "${adresse}"`;
  exec(commande, () => {});
}

function trouverNavigateur() {
  if (process.platform !== 'win32') return null;
  const racines = [process.env['ProgramFiles(x86)'], process.env.ProgramFiles, process.env.LOCALAPPDATA].filter(Boolean);
  const candidats = [path.join('Microsoft', 'Edge', 'Application', 'msedge.exe'), path.join('Google', 'Chrome', 'Application', 'chrome.exe')];
  for (const candidat of candidats) {
    for (const dossier of racines) {
      const chemin = path.join(dossier, candidat);
      if (fs.existsSync(chemin)) return chemin;
    }
  }
  return null;
}

function ouvrirFenetre(adresse) {
  const navigateur = config.fenetreApplication ? trouverNavigateur() : null;
  if (!navigateur) return ouvrirNavigateurParDefaut(adresse);
  const enfant = spawn(navigateur, [`--app=${adresse}`, '--window-size=1366,860'], { detached: true, stdio: 'ignore' });
  enfant.on('error', () => ouvrirNavigateurParDefaut(adresse));
  enfant.unref();
}

const fichierAdresse = () => path.join(config.dossierProjet, 'adresse-serveur.txt');

function publierAdresse(port) {
  const texte = `http://127.0.0.1:${port}`;
  try {
    fs.writeFileSync(fichierAdresse(), texte, 'utf8');
  } catch {
    try { fs.writeFileSync(fichierAdresse(), '\ufeff' + texte, 'utf16le'); } catch {}
  }
  try { fs.writeFileSync(path.join(config.dossierProjet, 'serveur.pid'), String(process.pid), 'utf8'); } catch {}
}

function surveillerActivite(minutes) {
  if (!(minutes > 0)) return;
  let dernierControle = Date.now();
  const periode = Math.min(30000, Math.max(1000, minutes * 30000));
  setInterval(() => {
    const maintenant = Date.now();
    if (maintenant - dernierControle > periode * 3) derniereActivite = maintenant;
    dernierControle = maintenant;
    if (maintenant - derniereActivite > minutes * 60000) {
      console.log(`  Aucune page ouverte depuis ${minutes} minutes : arrêt de l'application.`);
      process.exit(0);
    }
  }, periode);
}

function ecouter(port) {
  return new Promise((resolve, reject) => {
    const serveur = creerServeur();
    serveur.once('error', (e) => (e.code === 'EADDRINUSE' ? resolve(null) : reject(e)));
    serveur.listen(port, config.hote || undefined, () => resolve(serveur));
  });
}

async function estNotreApplication(port) {
  try {
    const reponse = await fetch(`http://127.0.0.1:${port}/api/info`, { signal: AbortSignal.timeout(1500) });
    return (await reponse.json()).application === 'bc-services';
  } catch {
    return false;
  }
}

function adressesReseau() {
  return Object.values(os.networkInterfaces()).flat()
    .filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
}

async function demarrer() {
  const aOuvrir = config.ouvrirNavigateur && !process.argv.includes('--sans-navigateur');
  const ecrireAdresse = !process.argv.includes('--sans-navigateur');

  for (let port = config.port; port < config.port + 10; port++) {
    const serveur = await ecouter(port);
    const adresse = `http://localhost:${port}`;

    if (serveur) {
      if (config.sauvegardeAuto) {
        try { require('../outils/sauvegarde').sauvegardeQuotidienne(); }
        catch (e) { console.log('  (sauvegarde automatique impossible : ' + e.message + ')'); }
      }
      console.log(`  Application prête : ${adresse}`);
      console.log(`  Base de données   : ${config.fichierExcel}`);
      if (!config.hote) {
        for (const adresseReseau of adressesReseau()) console.log(`  Autres ordinateurs du réseau : http://${adresseReseau}:${port}`);
      }
      try { fs.unlinkSync(path.join(config.dossierProjet, 'erreur-demarrage.txt')); } catch {}
      if (ecrireAdresse) {
        publierAdresse(port);
        const nettoyer = () => {
          try { fs.unlinkSync(fichierAdresse()); } catch {}
          try { fs.unlinkSync(path.join(config.dossierProjet, 'serveur.pid')); } catch {}
          try { fs.unlinkSync(path.join(config.dossierProjet, 'erreur-demarrage.txt')); } catch {}
        };
        process.on('exit', nettoyer);
        process.on('SIGINT', () => process.exit(0));
        process.on('SIGTERM', () => process.exit(0));
      }
      surveillerActivite(config.arretAutomatiqueMinutes);
      if (aOuvrir) ouvrirFenetre(adresse);
      return;
    }
    if (await estNotreApplication(port)) {
      console.log(`  BC Services est déjà ouvert : ${adresse}`);
      if (ecrireAdresse) publierAdresse(port);
      if (aOuvrir) ouvrirFenetre(adresse);
      return;
    }
  }
  arreter(new Error(`Aucun port libre entre ${config.port} et ${config.port + 9}. Changez « port » dans configuration.json.`));
}

if (require.main === module) {
  process.on('uncaughtException', arreter);
  demarrer().catch(arreter);
}

module.exports = { creerServeur };
