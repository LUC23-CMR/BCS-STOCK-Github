const routes = [];

function ajouter(methode, chemin, gestionnaire, statutParDefaut, options = {}) {
  const cles = [];
  const motif = new RegExp(
    '^' + chemin.replace(/:(\w+)/g, (_, nom) => { cles.push(nom); return '([^/]+)'; }) + '/?$'
  );
  routes.push({ methode, motif, cles, gestionnaire, statut: options.statut || statutParDefaut, options });
}

function trouver(methode, chemin) {
  for (const r of routes) {
    if (r.methode !== methode) continue;
    const m = r.motif.exec(chemin);
    if (!m) continue;
    const params = {};
    r.cles.forEach((cle, i) => { params[cle] = decodeURIComponent(m[i + 1]); });
    return { route: r, params };
  }
  return null;
}

module.exports = {
  get:    (chemin, fn, opt) => ajouter('GET', chemin, fn, 200, opt),
  post:   (chemin, fn, opt) => ajouter('POST', chemin, fn, 201, opt),
  put:    (chemin, fn, opt) => ajouter('PUT', chemin, fn, 200, opt),
  patch:  (chemin, fn, opt) => ajouter('PATCH', chemin, fn, 200, opt),
  delete: (chemin, fn, opt) => ajouter('DELETE', chemin, fn, 200, opt),
  trouver,
};
