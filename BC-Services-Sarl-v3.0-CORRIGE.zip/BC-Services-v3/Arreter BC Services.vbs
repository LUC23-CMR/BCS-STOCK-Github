Option Explicit

Dim fso, dossier, fichier, adresse, http, f, reussi

Set fso = CreateObject("Scripting.FileSystemObject")
dossier = fso.GetParentFolderName(WScript.ScriptFullName)
fichier = dossier & "\adresse-serveur.txt"

Function Accents(texte)
  texte = Replace(texte, "{e}", ChrW(233))
  texte = Replace(texte, "{g}", ChrW(232))
  Accents = texte
End Function

If Not fso.FileExists(fichier) Then
  MsgBox Accents("BC Services n'est pas lanc{e}."), vbInformation, "BC Services"
  WScript.Quit
End If

Set f = fso.OpenTextFile(fichier, 1)
adresse = Trim(f.ReadLine)
f.Close

reussi = True
On Error Resume Next
Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
http.setTimeouts 3000, 3000, 3000, 3000
http.open "POST", adresse & "/api/arret", False
http.setRequestHeader "Content-Type", "application/json"
http.send "{}"
If Err.Number <> 0 Then reussi = False
On Error GoTo 0

If reussi Then
  MsgBox Accents("BC Services est arr{e}t{e}. Vous pouvez le relancer quand vous voulez."), vbInformation, "BC Services"
Else
  MsgBox Accents("BC Services ne r{e}pond pas : il n'est probablement plus lanc{e}."), vbInformation, "BC Services"
End If
