module.exports = {
  clients: [
    { nom: 'Client exemple', telephone: '', email: '', adresse: '' },
  ],
  produits: [
    { reference: 'CAM-IP4',  designation: 'Caméra IP 4 MP extérieure',           categorie: 'Vidéosurveillance',     type: 'produit', unite: 'pièce',   prix_unitaire: 65000,  cout: 45000,  stock: 12, seuil_alerte: 4 },
    { reference: 'POSE-CAM', designation: 'Installation caméra (main d\'oeuvre)', categorie: 'Vidéosurveillance',     type: 'service', unite: 'forfait', prix_unitaire: 25000,  cout: 0,      stock: 0,  seuil_alerte: 0 },
    { reference: 'LEC-BIO',  designation: 'Lecteur biométrique',                  categorie: 'Contrôle d\'accès',     type: 'produit', unite: 'pièce',   prix_unitaire: 120000, cout: 85000,  stock: 5,  seuil_alerte: 2 },
    { reference: 'DET-FUM',  designation: 'Détecteur de fumée adressable',        categorie: 'Alarme incendie',       type: 'produit', unite: 'pièce',   prix_unitaire: 18000,  cout: 12000,  stock: 30, seuil_alerte: 10 },
    { reference: 'PAN-450',  designation: 'Panneau solaire 450 W',                categorie: 'Installation solaire',  type: 'produit', unite: 'pièce',   prix_unitaire: 185000, cout: 140000, stock: 8,  seuil_alerte: 3 },
    { reference: 'CAB-3G25', designation: 'Câble 3x2,5 mm² (rouleau 100 m)',      categorie: 'Électricité bâtiment',  type: 'produit', unite: 'rouleau', prix_unitaire: 48000,  cout: 35000,  stock: 3,  seuil_alerte: 5 },
    { reference: 'SW-24P',   designation: 'Switch 24 ports Gigabit',              categorie: 'Réseau informatique',   type: 'produit', unite: 'pièce',   prix_unitaire: 145000, cout: 105000, stock: 4,  seuil_alerte: 2 },
    { reference: 'SIR-EXT',  designation: 'Sirène extérieure flash',              categorie: 'Alarme intrusion',      type: 'produit', unite: 'pièce',   prix_unitaire: 22000,  cout: 15000,  stock: 10, seuil_alerte: 3 },
    { reference: 'LAP-15',   designation: 'Ordinateur portable 15"',              categorie: 'Matériel informatique', type: 'produit', unite: 'pièce',   prix_unitaire: 350000, cout: 280000, stock: 6,  seuil_alerte: 2 },
  ],
};
