const { PARAMETRES } = require('./parametres-defaut');
const { aujourdhui, ajouterJours } = require('./temps');

function arrondir(valeur, decimales = 0) {
  const f = 10 ** decimales;
  return Math.round((valeur + Number.EPSILON) * f) / f;
}

function decimalesDeLaBase(brut) {
  const defini = PARAMETRES.find((p) => p.cle === 'decimales');
  const ligne = brut('parametres').find((l) => l.libelle === defini.libelle);
  const n = Number(ligne ? ligne.valeur : defini.defaut);
  return Number.isFinite(n) ? Math.min(3, Math.max(0, Math.round(n))) : 0;
}

function totauxLignes(lignes, tva, decimales = 0) {
  const ht = arrondir(lignes.reduce((s, l) => s + l.quantite * l.prix_unitaire, 0), decimales);
  const montantTva = arrondir((ht * tva) / 100, decimales);
  return { total_ht: ht, total_tva: montantTva, total_ttc: arrondir(ht + montantTva, decimales) };
}

function etatPaiement(totalTtc, paye) {
  if (paye <= 0.0001) return 'impayée';
  return paye + 0.0049 < totalTtc ? 'partielle' : 'payée';
}

function repartirTranches(totalTtc, tranches, decimales = 0) {
  let cumule = 0;
  return tranches.map((t, i) => {
    const derniere = i === tranches.length - 1;
    const montant = derniere ? arrondir(totalTtc - cumule, decimales) : arrondir((totalTtc * t.pourcentage) / 100, decimales);
    cumule = arrondir(cumule + montant, decimales);
    return { ...t, montant };
  });
}

function echeancier(tranches, totalTtc, paye, decimales, dateReference) {
  const aujourdhuiIso = aujourdhui();
  let disponible = paye;
  return repartirTranches(totalTtc, tranches, decimales).map((t) => {
    const part = Math.min(Math.max(disponible, 0), t.montant);
    disponible = arrondir(disponible - part, 2);
    const reste = arrondir(t.montant - part, 2);
    const statut = reste <= 0.0049 ? 'payée' : part > 0.0001 ? 'partielle' : 'à payer';
    const dateEcheance = ajouterJours(dateReference, t.delai_jours);
    return { ...t, date_echeance: dateEcheance, paye: arrondir(part, 2), reste, statut, en_retard: statut !== 'payée' && dateEcheance < aujourdhuiIso };
  });
}

const somme = (liste, champ) => liste.reduce((s, x) => s + x[champ], 0);

module.exports = { arrondir, decimalesDeLaBase, totauxLignes, etatPaiement, repartirTranches, echeancier, somme };
