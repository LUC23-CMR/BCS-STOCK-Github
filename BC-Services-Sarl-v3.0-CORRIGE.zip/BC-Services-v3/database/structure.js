const { totauxLignes, etatPaiement, somme } = require('./calculs');
const { STATUT, STATUT_DEVIS, MODES_PAIEMENT, TYPE_MOUVEMENT } = require('./constantes');
const { PERMISSIONS } = require('./permissions');
const { PARAMETRES } = require('./parametres-defaut');

const VIOLET = '4B0F87', VERT = '1B7A4A', MARRON = '6B4210', GRIS = '595959';

function infosFacture(f, index) {
  const lignes = index.lignes.get(f.id) || [];
  const totaux = totauxLignes(lignes, f.tva, index.decimales);
  const paye = somme(index.paiements.get(f.id) || [], 'montant');
  return { ...totaux, paye, reste: Math.max(0, totaux.total_ttc - paye) };
}

const TABLES = {
  parametres: {
    feuille: 'Parametres', couleur: VERT,
    colonnes: [
      { cle: 'libelle', titre: 'Paramètre', type: 'texte', largeur: 40 },
      { cle: 'valeur', titre: 'Valeur', type: 'libre', largeur: 44 },
      { cle: 'aide', titre: 'Explication', type: 'texte', largeur: 44,
        calcule: (ligne) => (PARAMETRES.find((p) => p.libelle === ligne.libelle) || {}).aide || '' },
    ],
  },

  categories: {
    feuille: 'Categories', couleur: VERT,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'nom', titre: 'Catégorie', type: 'texte', largeur: 34 },
    ],
  },

  roles: {
    feuille: 'Roles', couleur: GRIS, interne: true, hauteurEntete: 78,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 6 },
      { cle: 'nom', titre: 'Rôle', type: 'texte', largeur: 20 },
      { cle: 'description', titre: 'Description', type: 'texte', largeur: 40 },
      { cle: 'systeme', titre: 'Rôle système (non modifiable)', type: 'ouinon', largeur: 16 },
      ...PERMISSIONS.map((p) => ({ cle: p.code, titre: p.libelle, type: 'ouinon', largeur: 15 })),
    ],
  },

  utilisateurs: {
    feuille: 'Utilisateurs', couleur: GRIS, interne: true,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 6 },
      { cle: 'nom', titre: 'Nom complet', type: 'texte', largeur: 28 },
      { cle: 'identifiant', titre: 'Identifiant', type: 'texte', largeur: 20 },
      { cle: 'role', titre: 'Rôle', type: 'texte', largeur: 20, liste: { feuille: 'Roles', colonne: 'B' } },
      { cle: 'actif', titre: 'Actif', type: 'ouinon', largeur: 8 },
      { cle: 'doit_changer_mdp', titre: 'Doit changer son mot de passe', type: 'ouinon', largeur: 18 },
      { cle: 'derniere_connexion', titre: 'Dernière connexion', type: 'texte', largeur: 20 },
      { cle: 'cree_le', titre: 'Créé le', type: 'date', largeur: 13 },
      { cle: 'mot_de_passe', titre: 'Mot de passe (empreinte)', type: 'texte', largeur: 30, masquee: true },
    ],
  },

  clients: {
    feuille: 'Clients', couleur: VIOLET,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'nom', titre: 'Nom / société', type: 'texte', largeur: 32 },
      { cle: 'type_client', titre: 'Type de client', type: 'texte', largeur: 14, liste: ['Standard', 'VIP'] },
      { cle: 'telephone', titre: 'Téléphone', type: 'texte', largeur: 18 },
      { cle: 'email', titre: 'Email', type: 'texte', largeur: 28 },
      { cle: 'adresse', titre: 'Adresse', type: 'texte', largeur: 34 },
      { cle: 'cree_le', titre: 'Créé le', type: 'date', largeur: 13 },
    ],
  },

  fournisseurs: {
    feuille: 'Fournisseurs', couleur: VERT,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'nom', titre: 'Nom / société', type: 'texte', largeur: 32 },
      { cle: 'telephone', titre: 'Téléphone', type: 'texte', largeur: 18 },
      { cle: 'email', titre: 'Email', type: 'texte', largeur: 28 },
      { cle: 'adresse', titre: 'Adresse', type: 'texte', largeur: 34 },
      { cle: 'contact', titre: 'Personne de contact', type: 'texte', largeur: 24 },
      { cle: 'notes', titre: 'Notes', type: 'texte', largeur: 40 },
      { cle: 'cree_le', titre: 'Créé le', type: 'date', largeur: 13 },
    ],
  },

  produits: {
    feuille: 'Produits', couleur: VIOLET,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'reference', titre: 'Référence', type: 'texte', largeur: 14 },
      { cle: 'designation', titre: 'Désignation', type: 'texte', largeur: 40 },
      { cle: 'categorie', titre: 'Catégorie', type: 'texte', largeur: 24, liste: { feuille: 'Categories', colonne: 'B' } },
      { cle: 'type', titre: 'Type', type: 'texte', largeur: 12, liste: ['produit', 'service'] },
      { cle: 'unite', titre: 'Unité', type: 'texte', largeur: 10 },
      { cle: 'prix_unitaire', titre: 'Prix de vente HT', type: 'montant', largeur: 17, alias: ['Prix unitaire HT'] },
      { cle: 'cout', titre: 'Coût d\'achat', type: 'montant', largeur: 14 },
      { cle: 'fournisseur_id', titre: 'ID fournisseur', type: 'entier', largeur: 14 },
      { cle: 'fournisseur_nom', titre: 'Fournisseur (calculé)', type: 'texte', largeur: 28,
        calcule: (p, index) => (index.fournisseurs && index.fournisseurs.get(p.fournisseur_id) || {}).nom || '' },
      { cle: 'stock', titre: 'Stock', type: 'entier', largeur: 9 },
      { cle: 'seuil_alerte', titre: 'Seuil d\'alerte', type: 'entier', largeur: 14 },
      { cle: 'valeur_stock', titre: 'Valeur du stock (calculé)', type: 'montant', largeur: 24,
        calcule: (p) => (p.type === 'produit' ? p.stock * (p.cout || p.prix_unitaire) : 0) },
    ],
  },

  devis: {
    feuille: 'Devis', couleur: VIOLET,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'numero', titre: 'Numéro', type: 'texte', largeur: 16 },
      { cle: 'date_devis', titre: 'Date', type: 'date', largeur: 13 },
      { cle: 'date_validite', titre: 'Valable jusqu\'au', type: 'date', largeur: 16 },
      { cle: 'client_id', titre: 'ID client', type: 'entier', largeur: 11 },
      { cle: 'client_nom', titre: 'Client (calculé)', type: 'texte', largeur: 28,
        calcule: (d, index) => (index.clients.get(d.client_id) || {}).nom || '' },
      { cle: 'tva', titre: 'TVA (%)', type: 'nombre', largeur: 9 },
      { cle: 'statut', titre: 'Statut', type: 'texte', largeur: 12, liste: Object.values(STATUT_DEVIS) },
      { cle: 'raison_refus', titre: 'Raison du refus', type: 'texte', largeur: 40 },
      { cle: 'mode_paiement', titre: 'Moyen de paiement', type: 'texte', largeur: 18, liste: MODES_PAIEMENT },
      { cle: 'date_echeance', titre: 'Échéance de paiement', type: 'date', largeur: 16 },
      { cle: 'facture_id', titre: 'ID facture liée', type: 'entier', largeur: 14 },
      { cle: 'notes', titre: 'Notes et conditions', type: 'texte', largeur: 40 },
      { cle: 'cree_par', titre: 'Créé par', type: 'texte', largeur: 20 },
      { cle: 'cree_par_id', titre: 'ID créateur', type: 'entier', largeur: 11 },
      { cle: 'total_ht', titre: 'Total HT (calculé)', type: 'montant', largeur: 19,
        calcule: (d, index) => totauxLignes(index.lignesDevis.get(d.id) || [], d.tva, index.decimales).total_ht },
      { cle: 'total_ttc', titre: 'Total TTC (calculé)', type: 'montant', largeur: 20,
        calcule: (d, index) => totauxLignes(index.lignesDevis.get(d.id) || [], d.tva, index.decimales).total_ttc },
    ],
  },

  lignes_devis: {
    feuille: 'Lignes_Devis', couleur: VIOLET,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'devis_id', titre: 'ID devis', type: 'entier', largeur: 11 },
      { cle: 'numero_devis', titre: 'Numéro devis', type: 'texte', largeur: 16 },
      { cle: 'produit_id', titre: 'ID article', type: 'entier', largeur: 11 },
      { cle: 'designation', titre: 'Désignation', type: 'texte', largeur: 40 },
      { cle: 'quantite', titre: 'Quantité', type: 'entier', largeur: 10 },
      { cle: 'prix_unitaire', titre: 'Prix unitaire HT', type: 'montant', largeur: 17 },
      { cle: 'total', titre: 'Total HT (calculé)', type: 'montant', largeur: 19, calcule: (l) => l.quantite * l.prix_unitaire },
    ],
  },

  factures: {
    feuille: 'Factures', couleur: MARRON,
    anciennes: [{ cle: 'payee_ancienne', titre: 'Payée', type: 'ouinon' }],
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'numero', titre: 'Numéro', type: 'texte', largeur: 16 },
      { cle: 'date_facture', titre: 'Date', type: 'date', largeur: 13 },
      { cle: 'client_id', titre: 'ID client', type: 'entier', largeur: 11 },
      { cle: 'client_nom', titre: 'Client (calculé)', type: 'texte', largeur: 28,
        calcule: (f, index) => (index.clients.get(f.client_id) || {}).nom || '' },
      { cle: 'conditions', titre: 'Délai de paiement (jours)', type: 'entier', largeur: 14 },
      { cle: 'date_echeance', titre: 'Échéance', type: 'date', largeur: 13 },
      { cle: 'mode_paiement', titre: 'Moyen de paiement', type: 'texte', largeur: 18, liste: MODES_PAIEMENT },
      { cle: 'tva', titre: 'TVA (%)', type: 'nombre', largeur: 9 },
      { cle: 'statut', titre: 'Statut', type: 'texte', largeur: 12, liste: [STATUT.BROUILLON, STATUT.VALIDEE, STATUT.ANNULEE] },
      { cle: 'cree_par', titre: 'Créé par', type: 'texte', largeur: 20 },
      { cle: 'cree_par_id', titre: 'ID créateur', type: 'entier', largeur: 11 },
      { cle: 'total_ht', titre: 'Total HT (calculé)', type: 'montant', largeur: 19, calcule: (f, index) => infosFacture(f, index).total_ht },
      { cle: 'total_ttc', titre: 'Total TTC (calculé)', type: 'montant', largeur: 20, calcule: (f, index) => infosFacture(f, index).total_ttc },
      { cle: 'paye', titre: 'Payé (calculé)', type: 'montant', largeur: 16, calcule: (f, index) => infosFacture(f, index).paye },
      { cle: 'reste', titre: 'Reste dû (calculé)', type: 'montant', largeur: 18,
        calcule: (f, index) => (f.statut === STATUT.VALIDEE ? infosFacture(f, index).reste : 0) },
    ],
  },

  lignes: {
    feuille: 'Lignes_Facture', couleur: MARRON,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'facture_id', titre: 'ID facture', type: 'entier', largeur: 11 },
      { cle: 'numero_facture', titre: 'Numéro facture', type: 'texte', largeur: 17 },
      { cle: 'produit_id', titre: 'ID article', type: 'entier', largeur: 11 },
      { cle: 'designation', titre: 'Désignation', type: 'texte', largeur: 40 },
      { cle: 'quantite', titre: 'Quantité', type: 'entier', largeur: 10 },
      { cle: 'prix_unitaire', titre: 'Prix unitaire HT', type: 'montant', largeur: 17 },
      { cle: 'total', titre: 'Total HT (calculé)', type: 'montant', largeur: 19, calcule: (l) => l.quantite * l.prix_unitaire },
    ],
  },

  paiements: {
    feuille: 'Paiements', couleur: MARRON,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'facture_id', titre: 'ID facture', type: 'entier', largeur: 11 },
      { cle: 'numero', titre: 'Facture (calculé)', type: 'texte', largeur: 18, calcule: (p, index) => (index.factures.get(p.facture_id) || {}).numero || '' },
      { cle: 'date_paiement', titre: 'Date', type: 'date', largeur: 13 },
      { cle: 'montant', titre: 'Montant', type: 'montant', largeur: 16 },
      { cle: 'mode', titre: 'Mode de paiement', type: 'texte', largeur: 18, liste: MODES_PAIEMENT },
      { cle: 'reference', titre: 'Référence', type: 'texte', largeur: 24 },
      { cle: 'utilisateur', titre: 'Enregistré par', type: 'texte', largeur: 20 },
    ],
  },

  tranches: {
    feuille: 'Tranches_Paiement', couleur: MARRON,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'type', titre: 'Document', type: 'texte', largeur: 12, liste: ['devis', 'facture'] },
      { cle: 'document_id', titre: 'ID du document', type: 'entier', largeur: 15 },
      { cle: 'numero', titre: 'Numéro (calculé)', type: 'texte', largeur: 18,
        calcule: (t, index) => (t.type === 'devis' ? (index.devis.get(t.document_id) || {}).numero || '' : (index.factures.get(t.document_id) || {}).numero || 'brouillon') },
      { cle: 'ordre', titre: 'N° de la tranche', type: 'entier', largeur: 15 },
      { cle: 'libelle', titre: 'Libellé', type: 'texte', largeur: 30 },
      { cle: 'pourcentage', titre: 'Pourcentage', type: 'nombre', largeur: 13 },
      { cle: 'delai_jours', titre: 'Échéance (jours après la date du document)', type: 'entier', largeur: 24 },
    ],
  },

  mouvements: {
    feuille: 'Mouvements_Stock', couleur: MARRON,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'date_mouvement', titre: 'Date', type: 'date', largeur: 13 },
      { cle: 'type', titre: 'Type', type: 'texte', largeur: 14, liste: Object.values(TYPE_MOUVEMENT) },
      { cle: 'produit_id', titre: 'ID article', type: 'entier', largeur: 11 },
      { cle: 'designation', titre: 'Article (calculé)', type: 'texte', largeur: 40, calcule: (m, index) => (index.produits.get(m.produit_id) || {}).designation || '' },
      { cle: 'quantite', titre: 'Quantité (+ entrée, − sortie)', type: 'entier', largeur: 28 },
      { cle: 'motif', titre: 'Motif', type: 'texte', largeur: 36 },
      { cle: 'utilisateur', titre: 'Fait par', type: 'texte', largeur: 20 },
    ],
  },

  livraisons: {
    feuille: 'Bordereaux_Livraison', couleur: MARRON,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'numero', titre: 'Numéro', type: 'texte', largeur: 16 },
      { cle: 'date_livraison', titre: 'Date', type: 'date', largeur: 13 },
      { cle: 'client_id', titre: 'ID client', type: 'entier', largeur: 11 },
      { cle: 'client_nom', titre: 'Client (calculé)', type: 'texte', largeur: 28,
        calcule: (l, index) => (index.clients.get(l.client_id) || {}).nom || '' },
      { cle: 'document_type', titre: 'Type document lié', type: 'texte', largeur: 14, liste: ['facture', 'devis'] },
      { cle: 'facture_id', titre: 'ID facture liée', type: 'entier', largeur: 14 },
      { cle: 'devis_id', titre: 'ID devis lié', type: 'entier', largeur: 12 },
      { cle: 'document_numero', titre: 'N° document lié (calculé)', type: 'texte', largeur: 18,
        calcule: (l, index) => {
          if (l.document_type === 'devis' && l.devis_id) return (index.devis.get(l.devis_id) || {}).numero || '';
          if (l.facture_id) return (index.factures.get(l.facture_id) || {}).numero || '';
          return '';
        } },
      { cle: 'adresse_livraison', titre: 'Adresse de livraison', type: 'texte', largeur: 40 },
      { cle: 'statut', titre: 'Statut', type: 'texte', largeur: 12, liste: ['brouillon', 'validé', 'livré', 'annulé'] },
      { cle: 'notes', titre: 'Notes', type: 'texte', largeur: 40 },
      { cle: 'cree_par', titre: 'Créé par', type: 'texte', largeur: 20 },
      { cle: 'cree_par_id', titre: 'ID créateur', type: 'entier', largeur: 11 },
    ],
  },

  lignes_livraison: {
    feuille: 'Lignes_Livraison', couleur: MARRON,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'livraison_id', titre: 'ID bordereau', type: 'entier', largeur: 12 },
      { cle: 'numero_livraison', titre: 'Numéro bordereau', type: 'texte', largeur: 16 },
      { cle: 'produit_id', titre: 'ID article', type: 'entier', largeur: 11 },
      { cle: 'designation', titre: 'Désignation', type: 'texte', largeur: 40 },
      { cle: 'quantite', titre: 'Quantité', type: 'entier', largeur: 10 },
      { cle: 'unite', titre: 'Unité', type: 'texte', largeur: 10 },
    ],
  },

  journal: {
    feuille: 'Journal', couleur: GRIS, interne: true,
    colonnes: [
      { cle: 'id', titre: 'ID', type: 'entier', largeur: 8 },
      { cle: 'date_heure', titre: 'Date et heure', type: 'texte', largeur: 20 },
      { cle: 'utilisateur', titre: 'Utilisateur', type: 'texte', largeur: 22 },
      { cle: 'action', titre: 'Action', type: 'texte', largeur: 18 },
      { cle: 'objet', titre: 'Objet', type: 'texte', largeur: 30 },
      { cle: 'detail', titre: 'Détail', type: 'texte', largeur: 60 },
    ],
  },
};

const ORDRE = ['parametres', 'categories', 'clients', 'fournisseurs', 'produits', 'devis', 'lignes_devis', 'factures', 'lignes', 'paiements', 'tranches', 'livraisons', 'lignes_livraison', 'mouvements', 'roles', 'utilisateurs', 'journal'];

module.exports = { TABLES, ORDRE };
