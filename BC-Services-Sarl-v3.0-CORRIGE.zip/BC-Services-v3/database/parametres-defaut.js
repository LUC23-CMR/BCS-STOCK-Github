const CATEGORIES_PAR_DEFAUT = [
  'Vidéosurveillance', 'Contrôle d\'accès', 'Alarme incendie', 'Installation solaire',
  'Électricité bâtiment', 'Réseau informatique', 'Alarme intrusion', 'Matériel informatique',
];

const PARAMETRES = [
  { cle: 'nom', libelle: 'Nom de l\'entreprise', defaut: 'BC Services Sarl', aide: 'Affiché sur les factures' },
  { cle: 'adresse', libelle: 'Adresse', defaut: '', aide: 'En-tête des factures' },
  { cle: 'telephone', libelle: 'Téléphone', defaut: '', aide: 'En-tête des factures' },
  { cle: 'email', libelle: 'Email', defaut: '', aide: 'En-tête des factures' },
  { cle: 'identifiants', libelle: 'Identifiants (RCCM, NIF…)', defaut: '', aide: 'En-tête des factures' },
  { cle: 'mentionBancaire', libelle: 'Mention bancaire', defaut: '', aide: 'Texte affiché en bas des factures' },
  { cle: 'tvaParDefaut', libelle: 'TVA par défaut (%)', defaut: 18, type: 'nombre', aide: 'Proposée à chaque nouvelle facture' },
  { cle: 'devise', libelle: 'Devise', defaut: 'FCFA', aide: 'Affichée après chaque montant' },
  { cle: 'decimales', libelle: 'Décimales des montants', defaut: 0, type: 'nombre', aide: '0 pour le FCFA, 2 pour l\'euro' },
  { cle: 'prefixeFacture', libelle: 'Préfixe des factures', defaut: 'FAC', aide: 'Donne FAC-2026-0001, FAC-2026-0002…' },
  { cle: 'prefixeDevis', libelle: 'Préfixe des devis', defaut: 'DEV', aide: 'Donne DEV-2026-0001, DEV-2026-0002…' },
  { cle: 'validiteDevis', libelle: 'Validité des devis (jours)', defaut: 30, type: 'nombre', aide: 'Durée pendant laquelle un devis reste valable' },
  { cle: 'conditionsParDefaut', libelle: 'Délai de paiement par défaut (jours)', defaut: 0, type: 'nombre', aide: '0 = paiement immédiat' },
  { cle: 'majorationVip', libelle: 'Majoration clients VIP (%)', defaut: 10, type: 'nombre', aide: 'Pourcentage ajouté aux prix de vente pour les clients VIP' },
  { cle: 'prefixeLivraison', libelle: 'Préfixe des bordereaux de livraison', defaut: 'BL', aide: 'Donne BL-2026-0001…' },
];

module.exports = { CATEGORIES_PAR_DEFAUT, PARAMETRES };
