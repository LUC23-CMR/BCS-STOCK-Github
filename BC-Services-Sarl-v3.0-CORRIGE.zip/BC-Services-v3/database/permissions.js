const MODULES = [
  { nom: 'Ventes (devis)', permissions: [
    { code: 'devis.voir', libelle: 'Voir les devis' },
    { code: 'devis.toutes', libelle: 'Voir les devis de tous les utilisateurs', aide: 'Sans ce droit, l\'utilisateur ne voit que les devis qu\'il a créés lui-même.' },
    { code: 'devis.creer', libelle: 'Créer et modifier des devis' },
    { code: 'devis.facturer', libelle: 'Transformer un devis en facture', aide: 'Crée un brouillon de facture à partir du devis.' },
    { code: 'devis.supprimer', libelle: 'Supprimer des devis' },
  ] },
  { nom: 'Facturation', permissions: [
    { code: 'factures.voir', libelle: 'Voir les factures' },
    { code: 'factures.toutes', libelle: 'Voir les factures de tous les utilisateurs', aide: 'Sans ce droit, l\'utilisateur ne voit que les factures qu\'il a créées lui-même.' },
    { code: 'factures.creer', libelle: 'Créer et modifier des brouillons' },
    { code: 'factures.valider', libelle: 'Valider les factures', aide: 'Attribue le numéro définitif et sort les articles du stock.' },
    { code: 'factures.annuler', libelle: 'Annuler une facture validée' },
    { code: 'factures.supprimer', libelle: 'Supprimer des brouillons' },
    { code: 'paiements.voir', libelle: 'Voir les paiements' },
    { code: 'paiements.enregistrer', libelle: 'Enregistrer un paiement' },
    { code: 'paiements.supprimer', libelle: 'Supprimer un paiement' },
  ] },
  { nom: 'Contacts', permissions: [
    { code: 'clients.voir', libelle: 'Voir les clients' },
    { code: 'clients.modifier', libelle: 'Créer et modifier des clients' },
    { code: 'clients.supprimer', libelle: 'Supprimer des clients' },
  ] },
  { nom: 'Inventaire', permissions: [
    { code: 'articles.voir', libelle: 'Voir les articles' },
    { code: 'articles.modifier', libelle: 'Créer et modifier des articles' },
    { code: 'articles.supprimer', libelle: 'Supprimer des articles' },
    { code: 'articles.couts', libelle: 'Voir les coûts d\'achat', aide: 'Prix d\'achat, valeur du stock et marges.' },
    { code: 'stock.voir', libelle: 'Voir les mouvements de stock' },
    { code: 'stock.operer', libelle: 'Faire des réceptions, sorties et inventaires' },
  ] },
  { nom: 'Rapports', permissions: [
    { code: 'tableau.voir', libelle: 'Voir le tableau de bord' },
    { code: 'export.excel', libelle: 'Exporter la base en Excel', aide: 'Donne accès à toutes les données de l\'entreprise.' },
  ] },
  { nom: 'Administration', permissions: [
    { code: 'admin.utilisateurs', libelle: 'Gérer les utilisateurs' },
    { code: 'admin.roles', libelle: 'Gérer les rôles et les droits' },
    { code: 'admin.journal', libelle: 'Consulter le journal d\'activité' },
    { code: 'admin.parametres', libelle: 'Modifier les réglages de l\'entreprise' },
  ] },
];

const PERMISSIONS = MODULES.flatMap((m) => m.permissions.map((p) => ({ ...p, module: m.nom })));
const TOUTES = PERMISSIONS.map((p) => p.code);

const IMPLIQUE = {
  'devis.toutes': ['devis.voir'],
  'devis.creer': ['devis.voir', 'clients.voir', 'articles.voir'],
  'devis.facturer': ['devis.creer', 'factures.creer'],
  'devis.supprimer': ['devis.creer'],
  'factures.toutes': ['factures.voir'],
  'factures.creer': ['factures.voir', 'clients.voir', 'articles.voir'],
  'factures.valider': ['factures.creer'],
  'factures.annuler': ['factures.voir'],
  'factures.supprimer': ['factures.creer'],
  'paiements.voir': ['factures.voir'],
  'paiements.enregistrer': ['paiements.voir'],
  'paiements.supprimer': ['paiements.voir'],
  'clients.modifier': ['clients.voir'],
  'clients.supprimer': ['clients.modifier'],
  'articles.modifier': ['articles.voir'],
  'articles.supprimer': ['articles.modifier'],
  'articles.couts': ['articles.voir'],
  'stock.voir': ['articles.voir'],
  'stock.operer': ['stock.voir'],
};

function avecImplications(codes) {
  const resultat = new Set(codes.filter((c) => TOUTES.includes(c)));
  let change = true;
  while (change) {
    change = false;
    for (const code of [...resultat]) {
      for (const requis of IMPLIQUE[code] || []) {
        if (!resultat.has(requis)) { resultat.add(requis); change = true; }
      }
    }
  }
  return resultat;
}

const ROLES_PAR_DEFAUT = [
  { nom: 'Administrateur', systeme: true, description: 'Accès complet : gère aussi les utilisateurs et les droits',
    permissions: TOUTES },
  { nom: 'Gestionnaire', description: 'Facturation, clients, stock et rapports, sans l\'administration',
    permissions: TOUTES.filter((c) => !c.startsWith('admin.')) },
  { nom: 'Comptable', description: 'Valide les factures et enregistre les paiements',
    permissions: ['factures.voir', 'factures.toutes', 'factures.creer', 'factures.valider', 'factures.annuler',
      'paiements.voir', 'paiements.enregistrer', 'paiements.supprimer', 'clients.voir', 'clients.modifier',
      'articles.voir', 'devis.voir', 'devis.toutes', 'tableau.voir', 'export.excel'] },
  { nom: 'Commercial', description: 'Fait des devis et prépare des brouillons de factures ; ne voit que ses propres documents',
    permissions: ['devis.voir', 'devis.creer', 'devis.facturer', 'factures.voir', 'factures.creer', 'clients.voir', 'clients.modifier', 'articles.voir'] },
  { nom: 'Magasinier', description: 'Gère les articles et les mouvements de stock',
    permissions: ['articles.voir', 'articles.modifier', 'articles.couts', 'stock.voir', 'stock.operer'] },
  { nom: 'Lecture seule', description: 'Consulte tout, ne modifie rien',
    permissions: ['devis.voir', 'devis.toutes', 'factures.voir', 'factures.toutes', 'paiements.voir', 'clients.voir', 'articles.voir', 'stock.voir', 'tableau.voir'] },
];

module.exports = { MODULES, PERMISSIONS, TOUTES, IMPLIQUE, avecImplications, ROLES_PAR_DEFAUT };
