const zlib = require('node:zlib');

const TABLE_CRC = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(tampon) {
  let c = 0xffffffff;
  for (let i = 0; i < tampon.length; i++) c = TABLE_CRC[(c ^ tampon[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function creerZip(fichiers) {
  const blocs = [];
  const annuaire = [];
  let position = 0;

  for (const f of fichiers) {
    const nom = Buffer.from(f.nom, 'utf8');
    const brut = Buffer.from(f.contenu, 'utf8');
    const compresse = zlib.deflateRawSync(brut);
    const crc = crc32(brut);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(8, 8);
    local.writeUInt16LE(0x21, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(compresse.length, 18);
    local.writeUInt32LE(brut.length, 22);
    local.writeUInt16LE(nom.length, 26);
    blocs.push(local, nom, compresse);

    const entree = Buffer.alloc(46);
    entree.writeUInt32LE(0x02014b50, 0);
    entree.writeUInt16LE(20, 4);
    entree.writeUInt16LE(20, 6);
    entree.writeUInt16LE(0x0800, 8);
    entree.writeUInt16LE(8, 10);
    entree.writeUInt16LE(0x21, 14);
    entree.writeUInt32LE(crc, 16);
    entree.writeUInt32LE(compresse.length, 20);
    entree.writeUInt32LE(brut.length, 24);
    entree.writeUInt16LE(nom.length, 28);
    entree.writeUInt32LE(position, 42);
    annuaire.push(entree, nom);

    position += local.length + nom.length + compresse.length;
  }

  const tailleAnnuaire = annuaire.reduce((somme, b) => somme + b.length, 0);
  const fin = Buffer.alloc(22);
  fin.writeUInt32LE(0x06054b50, 0);
  fin.writeUInt16LE(fichiers.length, 8);
  fin.writeUInt16LE(fichiers.length, 10);
  fin.writeUInt32LE(tailleAnnuaire, 12);
  fin.writeUInt32LE(position, 16);
  return Buffer.concat([...blocs, ...annuaire, fin]);
}

function lireZip(tampon) {
  let i = tampon.length - 22;
  while (i >= 0 && tampon.readUInt32LE(i) !== 0x06054b50) i--;
  if (i < 0) throw new Error('ce fichier n\'est pas un classeur Excel (.xlsx) valide');

  const nombre = tampon.readUInt16LE(i + 10);
  let p = tampon.readUInt32LE(i + 16);
  const fichiers = new Map();

  for (let k = 0; k < nombre; k++) {
    if (tampon.readUInt32LE(p) !== 0x02014b50) throw new Error('annuaire zip corrompu');
    const methode = tampon.readUInt16LE(p + 10);
    const tailleCompressee = tampon.readUInt32LE(p + 20);
    const lNom = tampon.readUInt16LE(p + 28);
    const lExtra = tampon.readUInt16LE(p + 30);
    const lCommentaire = tampon.readUInt16LE(p + 32);
    const positionLocale = tampon.readUInt32LE(p + 42);
    const nom = tampon.toString('utf8', p + 46, p + 46 + lNom);

    const lNomLocal = tampon.readUInt16LE(positionLocale + 26);
    const lExtraLocal = tampon.readUInt16LE(positionLocale + 28);
    const debut = positionLocale + 30 + lNomLocal + lExtraLocal;
    const brut = tampon.subarray(debut, debut + tailleCompressee);
    fichiers.set(nom, methode === 0 ? Buffer.from(brut) : zlib.inflateRawSync(brut));

    p += 46 + lNom + lExtra + lCommentaire;
  }
  return fichiers;
}

module.exports = { creerZip, lireZip };
