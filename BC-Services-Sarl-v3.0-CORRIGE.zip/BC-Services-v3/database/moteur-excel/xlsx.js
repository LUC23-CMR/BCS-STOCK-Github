const { creerZip, lireZip } = require('./zip');

const echapper = (texte) =>
  String(texte).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function decoder(texte) {
  return texte
    .replace(/&(#x[0-9a-fA-F]+|#\d+|amp|lt|gt|quot|apos);/g, (m, e) => {
      if (e === 'amp') return '&';
      if (e === 'lt') return '<';
      if (e === 'gt') return '>';
      if (e === 'quot') return '"';
      if (e === 'apos') return '\'';
      return String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10));
    })
    .replace(/_x([0-9A-Fa-f]{4})_/g, (m, code) => String.fromCharCode(parseInt(code, 16)));
}

function lettre(index) {
  let resultat = '';
  for (let n = index + 1; n > 0; n = Math.floor((n - 1) / 26)) resultat = String.fromCharCode(65 + ((n - 1) % 26)) + resultat;
  return resultat;
}
function indexDeLettres(lettres) {
  let n = 0;
  for (const c of lettres) n = n * 26 + (c.charCodeAt(0) - 64);
  return n - 1;
}

const ORIGINE = Date.UTC(1899, 11, 30);
function isoVersSerie(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso));
  return m ? Math.round((Date.UTC(+m[1], +m[2] - 1, +m[3]) - ORIGINE) / 86400000) : null;
}
function serieVersIso(serie) {
  return new Date(ORIGINE + Math.floor(serie) * 86400000).toISOString().slice(0, 10);
}

function texteDe(xml) {
  const sansPhonetique = xml.replace(/<rPh\b[\s\S]*?<\/rPh>/g, '');
  let texte = '';
  for (const m of sansPhonetique.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)) texte += decoder(m[1]);
  return texte;
}

function lireChainesPartagees(xml) {
  if (!xml) return [];
  return [...xml.matchAll(/<si\b[^>]*?(?:\/>|>([\s\S]*?)<\/si>)/g)].map((m) => (m[1] ? texteDe(m[1]) : ''));
}

function valeurCellule(type, interieur, partagees) {
  const v = /<v\b[^>]*>([\s\S]*?)<\/v>/.exec(interieur);
  switch (type) {
    case 's': return v ? partagees[Number(v[1])] ?? '' : null;
    case 'inlineStr': return texteDe(interieur);
    case 'str': return v ? decoder(v[1]) : '';
    case 'b': return v ? v[1] === '1' : null;
    case 'e': return null;
    default: return v && v[1] !== '' ? Number(v[1]) : null;
  }
}

function lireFeuille(xml, partagees) {
  const lignes = [];
  for (const rm of xml.matchAll(/<row\b[^>]*?(?:\/>|>([\s\S]*?)<\/row>)/g)) {
    if (rm[1] == null) continue;
    const ouverture = rm[0].slice(0, rm[0].indexOf('>') + 1);
    const numero = /\br="(\d+)"/.exec(ouverture);
    const ligne = [];
    for (const cm of rm[1].matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
      const ref = /\br="([A-Z]+)\d*"/.exec(cm[1]);
      const type = (/\bt="([^"]*)"/.exec(cm[1]) || [])[1];
      ligne[ref ? indexDeLettres(ref[1]) : ligne.length] = valeurCellule(type, cm[2] || '', partagees);
    }
    lignes[numero ? Number(numero[1]) - 1 : lignes.length] = ligne;
  }
  return Array.from(lignes, (l) => (l ? Array.from(l, (c) => (c === undefined ? null : c)) : []));
}

function lireClasseur(tampon) {
  const fichiers = lireZip(tampon);
  const lire = (nom) => (fichiers.has(nom) ? fichiers.get(nom).toString('utf8').replace(/^\uFEFF/, '') : null);

  const classeur = lire('xl/workbook.xml');
  if (!classeur) throw new Error('classeur Excel invalide (workbook.xml manquant)');

  const cibles = {};
  for (const m of (lire('xl/_rels/workbook.xml.rels') || '').matchAll(/<Relationship\b[^>]*>/g)) {
    const id = /\bId="([^"]*)"/.exec(m[0]);
    const cible = /\bTarget="([^"]*)"/.exec(m[0]);
    if (id && cible) cibles[id[1]] = cible[1];
  }

  const partagees = lireChainesPartagees(lire('xl/sharedStrings.xml'));
  const resultat = {};
  for (const m of classeur.matchAll(/<sheet\b[^>]*>/g)) {
    const nom = /\bname="([^"]*)"/.exec(m[0]);
    const rid = /\br:id="([^"]*)"/.exec(m[0]);
    if (!nom || !rid || !cibles[rid[1]]) continue;
    const cible = cibles[rid[1]];
    const xml = lire(cible.startsWith('/') ? cible.slice(1) : 'xl/' + cible);
    if (xml != null) resultat[decoder(nom[1])] = lireFeuille(xml, partagees);
  }
  return resultat;
}

const S = { normal: 0, entete: 1, enteteCalcule: 2, date: 3, montant: 4, calculeNombre: 5, calculeTexte: 6 };

const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="dd/mm/yyyy"/></numFmts>
<fonts count="3">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
<font><sz val="11"/><color rgb="FF595959"/><name val="Calibri"/></font>
</fonts>
<fills count="5">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF4B0F87"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF7F7F7F"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF2F2F2"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="7">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="1" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="3" fontId="2" fillId="4" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/>
<xf numFmtId="0" fontId="2" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

const attributStyle = (s) => (s ? ` s="${s}"` : '');

function celluleTexte(ref, texte, style) {
  return `<c r="${ref}" t="inlineStr"${attributStyle(style)}><is><t xml:space="preserve">${echapper(texte)}</t></is></c>`;
}

function celluleXml(ref, valeur, colonne) {
  if (valeur === null || valeur === undefined || valeur === '') return '';
  const calcule = !!colonne.calcule;

  switch (colonne.type) {
    case 'date': {
      const serie = isoVersSerie(valeur);
      return serie === null ? celluleTexte(ref, valeur, S.normal) : `<c r="${ref}" s="${S.date}"><v>${serie}</v></c>`;
    }
    case 'ouinon':
      return celluleTexte(ref, valeur ? 'Oui' : 'Non', S.normal);
    case 'montant':
    case 'entier':
    case 'nombre': {
      const style = calcule ? S.calculeNombre : colonne.type === 'montant' ? S.montant : S.normal;
      return `<c r="${ref}"${attributStyle(style)}><v>${Number(valeur)}</v></c>`;
    }
    default:
      if (typeof valeur === 'number') return `<c r="${ref}"${attributStyle(calcule ? S.calculeNombre : 0)}><v>${valeur}</v></c>`;
      return celluleTexte(ref, valeur, calcule ? S.calculeTexte : S.normal);
  }
}

function formuleListe(colonne) {
  if (colonne.type === 'ouinon') return '"Oui,Non"';
  if (Array.isArray(colonne.liste)) return `"${colonne.liste.join(',')}"`;
  if (colonne.liste) return `${colonne.liste.feuille}!$${colonne.liste.colonne}$2:$${colonne.liste.colonne}$500`;
  return null;
}

function xmlFeuille(feuille) {
  const nbColonnes = feuille.colonnes.length;
  const derniere = Math.max(feuille.lignes.length + 1, 1);

  const largeurs = feuille.colonnes
    .map((c, i) => `<col min="${i + 1}" max="${i + 1}" width="${c.largeur || 16}" customWidth="1"${c.masquee ? ' hidden="1"' : ''}/>`).join('');

  const entete = `<row r="1" ht="${feuille.hauteurEntete || 22}" customHeight="1">${feuille.colonnes.map((c, i) =>
    celluleTexte(lettre(i) + 1, c.titre, c.calcule ? S.enteteCalcule : S.entete)).join('')}</row>`;

  const corps = feuille.lignes.map((valeurs, n) => {
    const numero = n + 2;
    const cellules = feuille.colonnes.map((c, i) => celluleXml(lettre(i) + numero, valeurs[i], c)).join('');
    return `<row r="${numero}">${cellules}</row>`;
  }).join('');

  const validations = feuille.colonnes
    .map((c, i) => ({ formule: formuleListe(c), colonne: lettre(i) }))
    .filter((v) => v.formule)
    .map((v) => `<dataValidation type="list" allowBlank="1" showErrorMessage="1" errorTitle="Valeur non reconnue" error="Choisissez une valeur dans la liste." sqref="${v.colonne}2:${v.colonne}2000"><formula1>${echapper(v.formule)}</formula1></dataValidation>`);

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetPr><tabColor rgb="FF${feuille.couleur || '4B0F87'}"/></sheetPr>
<dimension ref="A1:${lettre(nbColonnes - 1)}${derniere}"/>
<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
<sheetFormatPr defaultRowHeight="15"/>
<cols>${largeurs}</cols>
<sheetData>${entete}${corps}</sheetData>
<autoFilter ref="A1:${lettre(nbColonnes - 1)}${derniere}"/>
${validations.length ? `<dataValidations count="${validations.length}">${validations.join('')}</dataValidations>` : ''}
<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>
</worksheet>`;
}

function ecrireClasseur(feuilles) {
  const entete = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
  const fichiers = [
    { nom: '[Content_Types].xml', contenu: entete + `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${feuilles.map((f, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>` },
    { nom: '_rels/.rels', contenu: entete + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
    { nom: 'xl/workbook.xml', contenu: entete + `<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${feuilles.map((f, i) => `<sheet name="${echapper(f.nom)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>` },
    { nom: 'xl/_rels/workbook.xml.rels', contenu: entete + `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${feuilles.map((f, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${feuilles.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
    { nom: 'xl/styles.xml', contenu: STYLES },
    ...feuilles.map((f, i) => ({ nom: `xl/worksheets/sheet${i + 1}.xml`, contenu: xmlFeuille(f) })),
  ];
  return creerZip(fichiers);
}

module.exports = { lireClasseur, ecrireClasseur, serieVersIso, isoVersSerie };
