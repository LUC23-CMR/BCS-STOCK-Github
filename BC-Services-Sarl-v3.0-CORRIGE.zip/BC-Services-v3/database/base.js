const fs = require('node:fs');
const path = require('node:path');
const config = require('../backend/config');
const { ErreurMetier } = require('../backend/erreurs');
const { lireClasseur, ecrireClasseur, serieVersIso } = require('./moteur-excel/xlsx');
const { TABLES, ORDRE } = require('./structure');
const { PARAMETRES, CATEGORIES_PAR_DEFAUT } = require('./parametres-defaut');
const { TOUTES, ROLES_PAR_DEFAUT, avecImplications } = require('./permissions');
const { STATUT } = require('./constantes');
const { decimalesDeLaBase, totauxLignes } = require('./calculs');
const { aujourdhui } = require('./temps');
const exemples = require('./donnees_exemple');

const JOURNAL_MAX = 5000;

let donnees = {};
let dateFichier = 0;
let enTransaction = false;

const brut = (nom) => donnees[nom];

const sansAccent = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
const estVide = (v) => v === null || v === undefined || v === '';

function versNombre(v) {
  if (typeof v === 'number') return v;
  const n = Number(String(v ?? '').replace(/\s/g, '').replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
}

function depuisCellule(valeur, type) {
  switch (type) {
    case 'entier': return Math.round(versNombre(valeur));
    case 'nombre':
    case 'montant': return versNombre(valeur);
    case 'date': {
      if (typeof valeur === 'number') return serieVersIso(valeur);
      const texte = String(valeur ?? '').trim();
      if (/^\d{4}-\d{2}-\d{2}/.test(texte)) return texte.slice(0, 10);
      const fr = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(texte);
      return fr ? `${fr[3]}-${fr[2].padStart(2, '0')}-${fr[1].padStart(2, '0')}` : '';
    }
    case 'ouinon':
      return valeur === true || valeur === 1 || /^(oui|o|vrai|true|yes|1|x)$/i.test(String(valeur ?? '').trim());
    case 'libre':
      return typeof valeur === 'number' ? valeur : String(valeur ?? '').trim();
    default:
      return String(valeur ?? '').trim();
  }
}

function valeurParDefaut(type) {
  if (['entier', 'nombre', 'montant'].includes(type)) return 0;
  if (type === 'ouinon') return false;
  return '';
}

const colonnesSaisies = (def) => def.colonnes.filter((c) => !c.calcule);
const colonnesLisibles = (def) => [...colonnesSaisies(def), ...(def.anciennes || [])];

function ligneVide(def) {
  const ligne = {};
  for (const c of colonnesSaisies(def)) ligne[c.cle] = valeurParDefaut(c.type);
  return ligne;
}

function lireTable(def, cellules) {
  const entetes = (cellules[0] || []).map((t) => sansAccent(t ?? ''));
  const correspondance = colonnesLisibles(def)
    .map((c) => ({ c, index: [c.titre, ...(c.alias || [])].map((t) => entetes.indexOf(sansAccent(t))).find((i) => i >= 0) ?? -1 }))
    .filter((x) => x.index >= 0);

  const lignes = [];
  for (const ligneExcel of cellules.slice(1)) {
    if (correspondance.every(({ index }) => estVide(ligneExcel[index]))) continue;
    const ligne = ligneVide(def);
    for (const { c, index } of correspondance) {
      if (!estVide(ligneExcel[index])) ligne[c.cle] = depuisCellule(ligneExcel[index], c.type);
    }
    lignes.push(ligne);
  }
  return lignes;
}

function prochainId(nom) {
  return donnees[nom].reduce((max, l) => Math.max(max, l.id || 0), 0) + 1;
}

function ajouterBrut(nom, valeurs) {
  const ligne = { ...ligneVide(TABLES[nom]), ...valeurs };
  if (TABLES[nom].colonnes.some((c) => c.cle === 'id')) ligne.id = prochainId(nom);
  donnees[nom].push(ligne);
  return ligne;
}

function ligneRole(role) {
  const droits = avecImplications(role.permissions);
  const ligne = { ...ligneVide(TABLES.roles), nom: role.nom, description: role.description || '', systeme: !!role.systeme };
  for (const code of TOUTES) ligne[code] = !!role.systeme || droits.has(code);
  return ligne;
}

function completer() {
  let modifie = false;

  if (donnees.roles.length === 0) {
    for (const r of ROLES_PAR_DEFAUT) donnees.roles.push(ligneRole(r));
    modifie = true;
  }
  if (!donnees.roles.some((r) => r.systeme)) {
    donnees.roles.push(ligneRole(ROLES_PAR_DEFAUT[0]));
    modifie = true;
  }
  for (const role of donnees.roles.filter((r) => r.systeme)) {
    for (const code of TOUTES) if (!role[code]) { role[code] = true; modifie = true; }
  }

  for (const p of PARAMETRES) {
    if (!donnees.parametres.some((l) => l.libelle === p.libelle)) {
      donnees.parametres.push({ libelle: p.libelle, valeur: p.defaut });
      modifie = true;
    }
  }

  for (const nom of ORDRE) {
    if (!TABLES[nom].colonnes.some((c) => c.cle === 'id')) continue;
    for (const ligne of donnees[nom]) {
      if (!ligne.id) { ligne.id = prochainId(nom); modifie = true; }
      if ('cree_le' in ligne && !ligne.cree_le) { ligne.cree_le = aujourdhui(); modifie = true; }
    }
  }

  const factures = donnees.factures;
  const parNumero = new Map(factures.filter((f) => f.numero).map((f) => [f.numero, f]));
  for (const l of donnees.lignes) {
    if (!l.facture_id && l.numero_facture && parNumero.has(l.numero_facture)) {
      l.facture_id = parNumero.get(l.numero_facture).id;
      modifie = true;
    }
  }
  const decimales = decimalesDeLaBase(brut);
  for (const f of factures) {
    if (!f.statut) {
      f.statut = f.numero ? STATUT.VALIDEE : STATUT.BROUILLON;
      if (f.statut === STATUT.VALIDEE && !f.date_echeance) f.date_echeance = f.date_facture;
      modifie = true;
    }
    if ('payee_ancienne' in f) {
      if (f.payee_ancienne && !donnees.paiements.some((p) => p.facture_id === f.id)) {
        const lignes = donnees.lignes.filter((l) => l.facture_id === f.id);
        ajouterBrut('paiements', {
          facture_id: f.id, date_paiement: f.date_facture, montant: totauxLignes(lignes, f.tva, decimales).total_ttc,
          mode: 'Autre', reference: 'Repris de l\'ancienne version', utilisateur: 'Migration',
        });
      }
      delete f.payee_ancienne;
      modifie = true;
    }
  }

  if (donnees.categories.length === 0) {
    for (const nom of CATEGORIES_PAR_DEFAUT) ajouterBrut('categories', { nom });
    modifie = true;
  }
  return modifie;
}

function donneesInitiales() {
  const d = {};
  for (const nom of ORDRE) d[nom] = [];
  donnees = d;
  for (const nom of CATEGORIES_PAR_DEFAUT) ajouterBrut('categories', { nom });
  for (const c of exemples.clients) ajouterBrut('clients', { ...c, cree_le: aujourdhui() });
  for (const p of exemples.produits) ajouterBrut('produits', p);
}

function estAncienneVersion(classeur) {
  const entetes = ((classeur[TABLES.factures.feuille] || [])[0] || []).map((t) => sansAccent(t ?? ''));
  return entetes.includes('payee') && !entetes.includes('statut');
}

function tenterRestaurationAuto(raison) {
  try {
    const { listerSauvegardes } = require('../outils/reparation');
    const backups = listerSauvegardes();
    if (!backups.length) return false;
    const dest = config.fichierExcel.replace(/\.xlsx$/i, '') + '_endommage_' + Date.now() + '.xlsx';
    try { if (fs.existsSync(config.fichierExcel)) fs.copyFileSync(config.fichierExcel, dest); } catch {}
    fs.copyFileSync(backups[0].fichier, config.fichierExcel);
    console.log(`  [réparation] Base restaurée depuis « ${backups[0].nom} » (${raison})`);
    return true;
  } catch (e) {
    console.log('  [réparation] Impossible de restaurer : ' + e.message);
    return false;
  }
}

function charger() {
  if (!fs.existsSync(config.fichierExcel)) {
    donneesInitiales();
    completer();
    sauvegarderFichier();
    return;
  }

  let classeur;
  try {
    classeur = lireClasseur(fs.readFileSync(config.fichierExcel));
  } catch (erreur) {
    console.log('  [réparation] Classeur illisible : ' + erreur.message);
    if (tenterRestaurationAuto(erreur.message)) {
      try {
        classeur = lireClasseur(fs.readFileSync(config.fichierExcel));
      } catch (erreur2) {
        throw new ErreurMetier(
          `Le fichier Excel est illisible même après restauration (${erreur2.message}). Utilisez le bouton « Réparer l'application » dans les Réglages, ou restaurez manuellement un fichier du dossier sauvegardes.`,
          500,
        );
      }
    } else {
      throw new ErreurMetier(
        `Le fichier Excel est illisible (${erreur.message}). Aucune sauvegarde disponible. Placez une copie saine dans database/sauvegardes/ puis relancez, ou utilisez « Réparer l'application ».`,
        500,
      );
    }
  }

  if (estAncienneVersion(classeur)) {
    try { require('../outils/sauvegarde').sauvegarderMaintenant('_avant-migration'); } catch { }
    console.log('  Ancienne version du classeur détectée : migration automatique (une sauvegarde a été faite).');
  }

  const nouvelles = {};
  let modifie = false;
  for (const nom of ORDRE) {
    const cellules = classeur[TABLES[nom].feuille];
    if (cellules) nouvelles[nom] = lireTable(TABLES[nom], cellules);
    else { nouvelles[nom] = []; modifie = true; }
  }
  donnees = nouvelles;
  if (completer()) modifie = true;

  if (modifie) sauvegarderFichier();
  else dateFichier = fs.statSync(config.fichierExcel).mtimeMs;
}

function rafraichir() {
  if (!fs.existsSync(config.fichierExcel) || fs.statSync(config.fichierExcel).mtimeMs !== dateFichier) charger();
}

function construireIndex() {
  const grouper = (liste, cle) => {
    const m = new Map();
    for (const x of liste) { if (!m.has(x[cle])) m.set(x[cle], []); m.get(x[cle]).push(x); }
    return m;
  };
  return {
    decimales: decimalesDeLaBase(brut),
    clients: new Map(donnees.clients.map((c) => [c.id, c])),
    fournisseurs: new Map((donnees.fournisseurs || []).map((f) => [f.id, f])),
    produits: new Map(donnees.produits.map((p) => [p.id, p])),
    factures: new Map(donnees.factures.map((f) => [f.id, f])),
    devis: new Map(donnees.devis.map((d) => [d.id, d])),
    lignes: grouper(donnees.lignes, 'facture_id'),
    lignesDevis: grouper(donnees.lignes_devis, 'devis_id'),
    paiements: grouper(donnees.paiements, 'facture_id'),
  };
}

function construireClasseur(publicSeulement = false) {
  const index = construireIndex();
  const feuilles = ORDRE.filter((nom) => !(publicSeulement && TABLES[nom].interne)).map((nom) => {
    const def = TABLES[nom];
    return {
      nom: def.feuille, couleur: def.couleur, hauteurEntete: def.hauteurEntete, colonnes: def.colonnes,
      lignes: donnees[nom].map((ligne) => def.colonnes.map((c) => (c.calcule ? c.calcule(ligne, index) : ligne[c.cle]))),
    };
  });
  return ecrireClasseur(feuilles);
}

function exporter() {
  rafraichir();
  return construireClasseur(true);
}

function sauvegarderFichier() {
  if (donnees.journal.length > JOURNAL_MAX) donnees.journal.splice(0, donnees.journal.length - JOURNAL_MAX);
  const contenu = construireClasseur(false);

  try {
    fs.mkdirSync(path.dirname(config.fichierExcel), { recursive: true });
  } catch {
    throw new ErreurMetier(`Le dossier de la base de données est introuvable ou inaccessible : ${path.dirname(config.fichierExcel)}. Vérifiez « fichierExcel » dans configuration.json.`, 500);
  }
  const temporaire = config.fichierExcel + '.tmp';
  try {
    fs.writeFileSync(temporaire, contenu);
    fs.renameSync(temporaire, config.fichierExcel);
  } catch (erreur) {
    try { fs.unlinkSync(temporaire); } catch { }
    if (['EBUSY', 'EPERM', 'EACCES'].includes(erreur.code)) {
      throw new ErreurMetier('Enregistrement impossible : le classeur Excel est ouvert. Fermez-le dans Excel puis recommencez.', 409);
    }
    throw erreur;
  }
  dateFichier = fs.statSync(config.fichierExcel).mtimeMs;
}

function transaction(fn) {
  if (enTransaction) return fn();
  rafraichir();
  const copie = structuredClone(donnees);
  enTransaction = true;
  try {
    const resultat = fn();
    sauvegarderFichier();
    return resultat;
  } catch (erreur) {
    donnees = copie;
    throw erreur;
  } finally {
    enTransaction = false;
  }
}

function table(nom) {
  const def = TABLES[nom];
  if (!def) throw new Error(`Table inconnue : ${nom}`);
  const copie = (ligne) => (ligne ? { ...ligne } : null);
  const ecriture = () => { if (!enTransaction) throw new Error('Écriture hors transaction : utilisez base.transaction(() => …)'); };

  return {
    tous: () => donnees[nom].map(copie),
    ou: (test) => donnees[nom].filter(test).map(copie),
    premier: (test) => copie(donnees[nom].find(test)),
    trouver: (id) => copie(donnees[nom].find((l) => l.id === Number(id))),
    compter: (test) => (test ? donnees[nom].filter(test).length : donnees[nom].length),

    ajouter(valeurs) {
      ecriture();
      return copie(ajouterBrut(nom, valeurs));
    },
    modifier(id, changements) {
      ecriture();
      const ligne = donnees[nom].find((l) => l.id === Number(id));
      if (!ligne) return null;
      Object.assign(ligne, changements);
      return copie(ligne);
    },
    supprimerOu(test) {
      ecriture();
      const avant = donnees[nom].length;
      donnees[nom] = donnees[nom].filter((l) => !test(l));
      return avant - donnees[nom].length;
    },
  };
}

function parametres() {
  const resultat = {};
  for (const p of PARAMETRES) {
    const ligne = donnees.parametres.find((l) => l.libelle === p.libelle);
    const valeur = ligne && !estVide(ligne.valeur) ? ligne.valeur : p.defaut;
    resultat[p.cle] = p.type === 'nombre' ? versNombre(valeur) : String(valeur);
  }
  return resultat;
}

function modifierParametres(changements) {
  if (!enTransaction) throw new Error('Écriture hors transaction : utilisez base.transaction(() => …)');
  for (const p of PARAMETRES) {
    if (!(p.cle in changements)) continue;
    let ligne = donnees.parametres.find((l) => l.libelle === p.libelle);
    if (!ligne) { ligne = { libelle: p.libelle, valeur: '' }; donnees.parametres.push(ligne); }
    ligne.valeur = p.type === 'nombre' ? versNombre(changements[p.cle]) : String(changements[p.cle] ?? '').trim();
  }
}

charger();

module.exports = { table, transaction, rafraichir, parametres, modifierParametres, exporter, recharger: charger, sauvegarderFichier };
