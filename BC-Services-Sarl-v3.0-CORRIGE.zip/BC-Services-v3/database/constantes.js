const STATUT = { BROUILLON: 'brouillon', VALIDEE: 'validée', ANNULEE: 'annulée' };

const STATUT_DEVIS = { BROUILLON: 'brouillon', ENVOYE: 'envoyé', ACCEPTE: 'accepté', REFUSE: 'refusé', FACTURE: 'facturé' };

const MODES_PAIEMENT = ['Espèces', 'Virement', 'Chèque', 'Mobile Money', 'Carte bancaire', 'Autre'];

const TYPE_MOUVEMENT = {
  INITIAL: 'Stock initial',
  RECEPTION: 'Réception',
  LIVRAISON: 'Livraison',
  ANNULATION: 'Annulation',
  SORTIE: 'Sortie',
  AJUSTEMENT: 'Inventaire',
};

const CONDITIONS_PAIEMENT = [0, 15, 30, 45, 60];

module.exports = { STATUT, STATUT_DEVIS, MODES_PAIEMENT, TYPE_MOUVEMENT, CONDITIONS_PAIEMENT };
