const deux = (n) => String(n).padStart(2, '0');

const aujourdhui = (d = new Date()) => `${d.getFullYear()}-${deux(d.getMonth() + 1)}-${deux(d.getDate())}`;
const maintenant = (d = new Date()) => `${aujourdhui(d)} ${deux(d.getHours())}:${deux(d.getMinutes())}:${deux(d.getSeconds())}`;

function ajouterJours(iso, jours) {
  const [a, m, j] = iso.split('-').map(Number);
  return aujourdhui(new Date(a, m - 1, j + jours));
}

module.exports = { aujourdhui, maintenant, ajouterJours };
