const base = require('../database/base');
const mdp = require('../backend/securite/mots-de-passe');
const journal = require('../backend/services/journal');

const identifiant = (process.argv[2] || '').trim();
if (!identifiant) {
  console.log('Usage : npm run motdepasse -- identifiant');
  console.log('Comptes existants : ' + base.table('utilisateurs').tous().map((u) => u.identifiant).join(', '));
  process.exit(1);
}
const utilisateur = base.table('utilisateurs').premier((u) => u.identifiant.toLowerCase() === identifiant.toLowerCase());
if (!utilisateur) {
  console.log(`Aucun utilisateur « ${identifiant} ». Comptes existants : ` + base.table('utilisateurs').tous().map((u) => u.identifiant).join(', '));
  process.exit(1);
}

const temporaire = mdp.generer();
base.transaction(() => {
  base.table('utilisateurs').modifier(utilisateur.id, { mot_de_passe: mdp.hacher(temporaire), doit_changer_mdp: true, actif: true });
  journal.ajouter('Mot de passe', `Utilisateur ${utilisateur.nom}`, 'Réinitialisé en ligne de commande (compte réactivé)', 'Système');
});
console.log(`\n  Compte : ${utilisateur.identifiant}\n  Mot de passe temporaire : ${temporaire}\n`);
console.log('  Il devra être changé à la prochaine connexion. Si l\'application tourne, aucun redémarrage n\'est nécessaire.\n');
