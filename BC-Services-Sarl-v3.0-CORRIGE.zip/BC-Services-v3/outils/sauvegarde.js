const fs = require('node:fs');
const path = require('node:path');
const config = require('../backend/config');

const GARDER = 30;

function dossierSauvegardes() {
  return path.join(path.dirname(config.fichierExcel), 'sauvegardes');
}
const nomBase = () => path.basename(config.fichierExcel, path.extname(config.fichierExcel));

function sauvegarderMaintenant(suffixe = '') {
  if (!fs.existsSync(config.fichierExcel)) throw new Error('Aucun classeur à sauvegarder : lancez d\'abord l\'application une fois.');
  fs.mkdirSync(dossierSauvegardes(), { recursive: true });
  const horodatage = new Date().toISOString().slice(0, 16).replace('T', '_').replace(':', 'h');
  const copie = path.join(dossierSauvegardes(), `${nomBase()}_${horodatage}${suffixe}.xlsx`);
  fs.copyFileSync(config.fichierExcel, copie);
  return copie;
}

function sauvegardeQuotidienne() {
  if (!fs.existsSync(config.fichierExcel)) return null;
  const dossier = dossierSauvegardes();
  const copie = path.join(dossier, `${nomBase()}_${new Date().toISOString().slice(0, 10)}.xlsx`);
  if (fs.existsSync(copie)) return null;

  fs.mkdirSync(dossier, { recursive: true });
  fs.copyFileSync(config.fichierExcel, copie);

  const motif = new RegExp(`^${nomBase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}_\\d{4}-\\d{2}-\\d{2}\\.xlsx$`);
  const anciennes = fs.readdirSync(dossier).filter((f) => motif.test(f)).sort().reverse().slice(GARDER);
  for (const f of anciennes) fs.unlinkSync(path.join(dossier, f));
  return copie;
}

module.exports = { sauvegarderMaintenant, sauvegardeQuotidienne };

if (require.main === module) {
  try { console.log('Sauvegarde créée : ' + sauvegarderMaintenant()); }
  catch (e) { console.log(e.message); process.exit(1); }
}
