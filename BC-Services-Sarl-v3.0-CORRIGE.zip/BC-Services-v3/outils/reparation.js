/**
 * Réparation automatique de BC Services :
 * - base Excel illisible ou corrompue → restauration depuis la dernière sauvegarde
 * - structure incomplète → reconstruction des tables / paramètres manquants
 * - fichier .tmp orphelin → nettoyage
 * - journal trop volumineux → truncation
 */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../backend/config');

function dossierSauvegardes() {
  return path.join(path.dirname(config.fichierExcel), 'sauvegardes');
}

function listerSauvegardes() {
  const dossier = dossierSauvegardes();
  if (!fs.existsSync(dossier)) return [];
  const nomBase = path.basename(config.fichierExcel, path.extname(config.fichierExcel));
  return fs.readdirSync(dossier)
    .filter((f) => f.startsWith(nomBase) && f.endsWith('.xlsx'))
    .map((f) => {
      const p = path.join(dossier, f);
      return { fichier: p, nom: f, mtime: fs.statSync(p).mtimeMs };
    })
    .sort((a, b) => b.mtime - a.mtime);
}

function nettoyerTemporaires() {
  const actions = [];
  const tmp = config.fichierExcel + '.tmp';
  if (fs.existsSync(tmp)) {
    try {
      fs.unlinkSync(tmp);
      actions.push('Fichier temporaire .tmp supprimé');
    } catch (e) {
      actions.push(`Impossible de supprimer le .tmp : ${e.message}`);
    }
  }
  // Anciens fichiers de crash éventuels
  const dossier = path.dirname(config.fichierExcel);
  if (fs.existsSync(dossier)) {
    for (const f of fs.readdirSync(dossier)) {
      if (f.endsWith('.tmp') || f.endsWith('.xlsx.bak-crash')) {
        try {
          fs.unlinkSync(path.join(dossier, f));
          actions.push(`Nettoyé : ${f}`);
        } catch { /* ignore */ }
      }
    }
  }
  return actions;
}

function sauvegardeSecours(suffixe = '_avant-reparation') {
  if (!fs.existsSync(config.fichierExcel)) return null;
  try {
    return require('./sauvegarde').sauvegarderMaintenant(suffixe);
  } catch {
    return null;
  }
}

function restaurerDepuisSauvegarde(sauvegarde) {
  if (!sauvegarde || !fs.existsSync(sauvegarde.fichier)) {
    throw new Error('Aucune sauvegarde disponible pour la restauration.');
  }
  // Copie de sécurité de l'actuel si encore présent
  if (fs.existsSync(config.fichierExcel)) {
    try {
      const crash = config.fichierExcel + '.xlsx.bak-crash'.replace('.xlsx.xlsx', '.xlsx');
      // nom plus clair
      const dest = config.fichierExcel.replace(/\.xlsx$/i, '') + '_endommage_' + Date.now() + '.xlsx';
      fs.copyFileSync(config.fichierExcel, dest);
    } catch { /* ignore */ }
  }
  fs.copyFileSync(sauvegarde.fichier, config.fichierExcel);
  return sauvegarde.nom;
}

/**
 * Tente de lire le classeur. Retourne { ok, erreur }.
 */
function testerLisibilite(fichier = config.fichierExcel) {
  if (!fs.existsSync(fichier)) return { ok: false, erreur: 'Fichier absent' };
  try {
    const { lireClasseur } = require('../database/moteur-excel/xlsx');
    const buf = fs.readFileSync(fichier);
    if (buf.length < 100) return { ok: false, erreur: 'Fichier trop petit / vide' };
    lireClasseur(buf);
    return { ok: true };
  } catch (e) {
    return { ok: false, erreur: e.message };
  }
}

/**
 * Réparation complète appelée au démarrage ou manuellement.
 * @returns {{ actions: string[], restaure: boolean, ok: boolean }}
 */
function reparer(options = {}) {
  const actions = [];
  let restaure = false;

  // 1. Nettoyage
  actions.push(...nettoyerTemporaires());

  // 2. Vérifier / créer le dossier
  try {
    fs.mkdirSync(path.dirname(config.fichierExcel), { recursive: true });
  } catch (e) {
    actions.push(`Dossier base inaccessible : ${e.message}`);
  }

  // 3. Test de lisibilité
  const test = testerLisibilite();
  if (!test.ok && fs.existsSync(config.fichierExcel)) {
    actions.push(`Base illisible : ${test.erreur}`);
    const backups = listerSauvegardes();
    if (backups.length) {
      try {
        const nom = restaurerDepuisSauvegarde(backups[0]);
        actions.push(`Restauration depuis la sauvegarde « ${nom} »`);
        restaure = true;
      } catch (e) {
        actions.push(`Échec restauration : ${e.message}`);
      }
    } else {
      actions.push('Aucune sauvegarde trouvée pour restauration');
    }
  } else if (!fs.existsSync(config.fichierExcel)) {
    actions.push('Aucune base trouvée — une base neuve sera créée au chargement');
  } else {
    actions.push('Base lisible');
  }

  // 4. Recharger + compléter structure (tables, paramètres, IDs…)
  try {
    const base = require('../database/base');
    // Forcer un rechargement complet
    base.recharger();
    actions.push('Structure vérifiée et complétée (paramètres, rôles, tables manquantes)');
  } catch (e) {
    // Si le rechargement échoue encore après restauration, tenter la 2e sauvegarde
    const backups = listerSauvegardes();
    if (backups.length > 1 && !restaure) {
      try {
        restaurerDepuisSauvegarde(backups[1]);
        actions.push(`Seconde tentative : sauvegarde « ${backups[1].nom} »`);
        restaure = true;
        const base = require('../database/base');
        base.recharger();
        actions.push('Structure vérifiée après 2e restauration');
      } catch (e2) {
        actions.push(`Réparation incomplète : ${e2.message}`);
        return { actions, restaure, ok: false };
      }
    } else {
      actions.push(`Réparation incomplète : ${e.message}`);
      return { actions, restaure, ok: false };
    }
  }

  // 5. Sauvegarde de sécurité après réparation réussie
  if (options.sauvegarder !== false) {
    try {
      const copie = require('./sauvegarde').sauvegarderMaintenant('_apres-reparation');
      if (copie) actions.push(`Sauvegarde post-réparation : ${path.basename(copie)}`);
    } catch { /* non bloquant */ }
  }

  return { actions, restaure, ok: true };
}

/**
 * Réparation légère au démarrage (sans forcément créer une sauvegarde).
 * Si la base est OK, ne fait que le nettoyage + completer via charger normal.
 */
function reparerAuDemarrage() {
  const actions = nettoyerTemporaires();
  const test = testerLisibilite();
  if (!test.ok && fs.existsSync(config.fichierExcel)) {
    console.log('  [réparation] Base illisible — tentative de restauration…');
    const resultat = reparer({ sauvegarder: true });
    for (const a of resultat.actions) console.log('  [réparation] ' + a);
    return resultat;
  }
  if (actions.length) {
    for (const a of actions) console.log('  [réparation] ' + a);
  }
  return { actions, restaure: false, ok: test.ok || !fs.existsSync(config.fichierExcel) };
}

module.exports = {
  reparer,
  reparerAuDemarrage,
  testerLisibilite,
  listerSauvegardes,
  nettoyerTemporaires,
};

if (require.main === module) {
  console.log('Réparation BC Services…');
  const r = reparer({ sauvegarder: true });
  for (const a of r.actions) console.log('  - ' + a);
  console.log(r.ok ? '\nRéparation terminée avec succès.' : '\nRéparation incomplète.');
  process.exit(r.ok ? 0 : 1);
}
