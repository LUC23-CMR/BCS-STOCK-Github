#Requires -Version 5.1
<#
.SYNOPSIS
  Installateur graphique intelligent — BC Services Sarl
  Devis • Facturation • Stock • Comparateur fournisseurs

.DESCRIPTION
  Assistant d'installation moderne pour Windows.
  - Vérifie et propose Node.js si nécessaire
  - Choix du dossier d'installation
  - Création des raccourcis Bureau + Menu Démarrer
  - Configuration automatique
  - Lancement optionnel de l'application

  Usage :
    Clic droit → « Exécuter avec PowerShell »
    ou : powershell -ExecutionPolicy Bypass -File "Installer BC Services.ps1"
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ─────────────────────────────────────────────
# Constantes & chemins
# ─────────────────────────────────────────────
$AppName        = "BC Services"
$AppFullName    = "BC Services Sarl — Devis, Facturation & Stock"
$AppVersion     = "3.0.0"
$Publisher      = "BC Services Sarl"
$SourceRoot     = $PSScriptRoot
$DefaultInstall = Join-Path $env:ProgramFiles "BC Services"
$IconPath       = Join-Path $SourceRoot "frontend\img\BC_Services.ico"
$LogoPng        = Join-Path $SourceRoot "frontend\img\icone-256.png"

# Couleurs marque (violet / vert)
$ColorPrimary   = [System.Drawing.Color]::FromArgb(59, 11, 107)   # #3b0b6b
$ColorAccent    = [System.Drawing.Color]::FromArgb(27, 122, 74)   # #1b7a4a
$ColorBg        = [System.Drawing.Color]::FromArgb(250, 248, 251) # #faf8fb
$ColorPanel     = [System.Drawing.Color]::White
$ColorText      = [System.Drawing.Color]::FromArgb(35, 27, 43)

# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────
function Test-NodeInstalled {
    try {
        $v = & node -v 2>$null
        if ($v -match '^v(\d+)') {
            return [int]$Matches[1] -ge 18
        }
    } catch {}
    # Cherche aussi un node local éventuel
    $local = Join-Path $SourceRoot "node\node.exe"
    if (Test-Path $local) { return $true }
    return $false
}

function Get-NodeVersion {
    try {
        $v = & node -v 2>$null
        if ($v) { return $v.Trim() }
    } catch {}
    $local = Join-Path $SourceRoot "node\node.exe"
    if (Test-Path $local) {
        try { return (& $local -v).Trim() } catch {}
    }
    return $null
}

function Copy-AppFiles {
    param([string]$Target)

    $exclude = @('serveur.log', 'erreur-demarrage.txt', '.raccourci-cree', 'adresse-serveur.txt',
                 'Installer BC Services.ps1', 'node_modules', '.git', '.vscode')

    if (-not (Test-Path $Target)) {
        New-Item -ItemType Directory -Path $Target -Force | Out-Null
    }

    Get-ChildItem -Path $SourceRoot -Force | ForEach-Object {
        if ($exclude -contains $_.Name) { return }
        $dest = Join-Path $Target $_.Name
        if ($_.PSIsContainer) {
            if ($_.Name -eq 'database') {
                # On conserve un éventuel BC_Services_Base.xlsx existant
                $srcDb = Join-Path $_.FullName "BC_Services_Base.xlsx"
                $dstDb = Join-Path $dest "BC_Services_Base.xlsx"
                if ((Test-Path $srcDb) -and -not (Test-Path $dstDb)) {
                    Copy-Item $_.FullName $dest -Recurse -Force
                } elseif (-not (Test-Path $dest)) {
                    Copy-Item $_.FullName $dest -Recurse -Force
                } else {
                    # Copie tout sauf le xlsx s'il existe déjà
                    Get-ChildItem $_.FullName | ForEach-Object {
                        if ($_.Name -ne 'BC_Services_Base.xlsx' -or -not (Test-Path (Join-Path $dest $_.Name))) {
                            Copy-Item $_.FullName (Join-Path $dest $_.Name) -Recurse -Force
                        }
                    }
                }
            } else {
                Copy-Item $_.FullName $dest -Recurse -Force
            }
        } else {
            Copy-Item $_.FullName $dest -Force
        }
    }
}

function New-Shortcut {
    param(
        [string]$Path,
        [string]$TargetPath,
        [string]$Arguments = "",
        [string]$WorkingDirectory,
        [string]$IconLocation,
        [string]$Description
    )
    $wsh = New-Object -ComObject WScript.Shell
    $sc = $wsh.CreateShortcut($Path)
    $sc.TargetPath       = $TargetPath
    $sc.Arguments        = $Arguments
    $sc.WorkingDirectory = $WorkingDirectory
    if ($IconLocation -and (Test-Path $IconLocation)) {
        $sc.IconLocation = $IconLocation
    }
    $sc.Description = $Description
    $sc.Save()
}

function Create-Shortcuts {
    param([string]$InstallDir)

    $vbsStart = Join-Path $InstallDir "Demarrer BC Services.vbs"
    $vbsStop  = Join-Path $InstallDir "Arreter BC Services.vbs"
    $ico      = Join-Path $InstallDir "frontend\img\BC_Services.ico"

    # Bureau
    $desktop = [Environment]::GetFolderPath("Desktop")
    New-Shortcut -Path (Join-Path $desktop "BC Services.lnk") `
                 -TargetPath "$env:WINDIR\System32\wscript.exe" `
                 -Arguments "`"$vbsStart`"" `
                 -WorkingDirectory $InstallDir `
                 -IconLocation $ico `
                 -Description $AppFullName

    # Menu Démarrer
    $startMenu = Join-Path ([Environment]::GetFolderPath("StartMenu")) "Programs\BC Services"
    if (-not (Test-Path $startMenu)) { New-Item -ItemType Directory -Path $startMenu -Force | Out-Null }

    New-Shortcut -Path (Join-Path $startMenu "BC Services.lnk") `
                 -TargetPath "$env:WINDIR\System32\wscript.exe" `
                 -Arguments "`"$vbsStart`"" `
                 -WorkingDirectory $InstallDir `
                 -IconLocation $ico `
                 -Description $AppFullName

    New-Shortcut -Path (Join-Path $startMenu "Arrêter BC Services.lnk") `
                 -TargetPath "$env:WINDIR\System32\wscript.exe" `
                 -Arguments "`"$vbsStop`"" `
                 -WorkingDirectory $InstallDir `
                 -IconLocation $ico `
                 -Description "Arrêter le serveur BC Services"
}

# ─────────────────────────────────────────────
# Interface graphique
# ─────────────────────────────────────────────
$form = New-Object System.Windows.Forms.Form
$form.Text = "Installation — $AppName"
$form.Size = New-Object System.Drawing.Size(720, 520)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = $ColorBg
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)
if (Test-Path $IconPath) {
    $form.Icon = New-Object System.Drawing.Icon($IconPath)
}

# Barre latérale gauche (branding)
$side = New-Object System.Windows.Forms.Panel
$side.Location = New-Object System.Drawing.Point(0, 0)
$side.Size = New-Object System.Drawing.Size(220, 520)
$side.BackColor = $ColorPrimary
$form.Controls.Add($side)

# Logo
if (Test-Path $LogoPng) {
    $pic = New-Object System.Windows.Forms.PictureBox
    $pic.Image = [System.Drawing.Image]::FromFile($LogoPng)
    $pic.SizeMode = "Zoom"
    $pic.Size = New-Object System.Drawing.Size(120, 120)
    $pic.Location = New-Object System.Drawing.Point(50, 40)
    $side.Controls.Add($pic)
}

$lblBrand = New-Object System.Windows.Forms.Label
$lblBrand.Text = "BC SERVICES"
$lblBrand.ForeColor = [System.Drawing.Color]::White
$lblBrand.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblBrand.AutoSize = $true
$lblBrand.Location = New-Object System.Drawing.Point(40, 175)
$side.Controls.Add($lblBrand)

$lblSub = New-Object System.Windows.Forms.Label
$lblSub.Text = "Devis • Facturation`nStock • Fournisseurs"
$lblSub.ForeColor = [System.Drawing.Color]::FromArgb(200, 180, 230)
$lblSub.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lblSub.Size = New-Object System.Drawing.Size(180, 50)
$lblSub.Location = New-Object System.Drawing.Point(40, 210)
$side.Controls.Add($lblSub)

$lblVer = New-Object System.Windows.Forms.Label
$lblVer.Text = "Version $AppVersion"
$lblVer.ForeColor = [System.Drawing.Color]::FromArgb(160, 140, 200)
$lblVer.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$lblVer.AutoSize = $true
$lblVer.Location = New-Object System.Drawing.Point(40, 460)
$side.Controls.Add($lblVer)

# Zone de contenu
$content = New-Object System.Windows.Forms.Panel
$content.Location = New-Object System.Drawing.Point(220, 0)
$content.Size = New-Object System.Drawing.Size(500, 420)
$content.BackColor = $ColorPanel
$form.Controls.Add($content)

# Boutons bas
$btnPanel = New-Object System.Windows.Forms.Panel
$btnPanel.Location = New-Object System.Drawing.Point(220, 420)
$btnPanel.Size = New-Object System.Drawing.Size(500, 80)
$btnPanel.BackColor = $ColorBg
$form.Controls.Add($btnPanel)

$btnBack = New-Object System.Windows.Forms.Button
$btnBack.Text = "← Précédent"
$btnBack.Size = New-Object System.Drawing.Size(110, 34)
$btnBack.Location = New-Object System.Drawing.Point(20, 22)
$btnBack.FlatStyle = "Flat"
$btnBack.Enabled = $false
$btnPanel.Controls.Add($btnBack)

$btnNext = New-Object System.Windows.Forms.Button
$btnNext.Text = "Suivant →"
$btnNext.Size = New-Object System.Drawing.Size(110, 34)
$btnNext.Location = New-Object System.Drawing.Point(250, 22)
$btnNext.BackColor = $ColorPrimary
$btnNext.ForeColor = [System.Drawing.Color]::White
$btnNext.FlatStyle = "Flat"
$btnNext.FlatAppearance.BorderSize = 0
$btnPanel.Controls.Add($btnNext)

$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Text = "Annuler"
$btnCancel.Size = New-Object System.Drawing.Size(90, 34)
$btnCancel.Location = New-Object System.Drawing.Point(370, 22)
$btnCancel.FlatStyle = "Flat"
$btnPanel.Controls.Add($btnCancel)

# ─────────────────────────────────────────────
# Étapes
# ─────────────────────────────────────────────
$script:step = 0
$script:installPath = $DefaultInstall
$script:launchAfter = $true
$script:nodeOk = Test-NodeInstalled

function Clear-Content {
    $content.Controls.Clear()
}

function Show-Step0 {
    # Bienvenue
    Clear-Content
    $t = New-Object System.Windows.Forms.Label
    $t.Text = "Bienvenue dans l'installation de`n$AppFullName"
    $t.Font = New-Object System.Drawing.Font("Segoe UI", 13, [System.Drawing.FontStyle]::Bold)
    $t.ForeColor = $ColorText
    $t.Size = New-Object System.Drawing.Size(460, 60)
    $t.Location = New-Object System.Drawing.Point(25, 30)
    $content.Controls.Add($t)

    $d = New-Object System.Windows.Forms.Label
    $d.Text = @"
Cet assistant va installer l'application de gestion :
• Devis et facturation (paiements par tranches)
• Inventaire et mouvements de stock
• Comparateur de prix fournisseurs
• Inventaire global (valeur stock, alertes, catégories)

L'installation est rapide et ne nécessite pas de droits administrateur
si vous choisissez un dossier dans votre profil utilisateur.
"@
    $d.Size = New-Object System.Drawing.Size(450, 160)
    $d.Location = New-Object System.Drawing.Point(25, 110)
    $d.ForeColor = $ColorText
    $content.Controls.Add($d)

    $note = New-Object System.Windows.Forms.Label
    $note.Text = "Services couverts : vidéosurveillance • contrôle d'accès • alarme • solaire • électricité • réseau"
    $note.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
    $note.ForeColor = $ColorAccent
    $note.Size = New-Object System.Drawing.Size(450, 40)
    $note.Location = New-Object System.Drawing.Point(25, 300)
    $content.Controls.Add($note)

    $btnBack.Enabled = $false
    $btnNext.Text = "Suivant →"
    $btnNext.Enabled = $true
}

function Show-Step1 {
    # Choix du dossier
    Clear-Content
    $t = New-Object System.Windows.Forms.Label
    $t.Text = "Dossier d'installation"
    $t.Font = New-Object System.Drawing.Font("Segoe UI", 13, [System.Drawing.FontStyle]::Bold)
    $t.ForeColor = $ColorText
    $t.AutoSize = $true
    $t.Location = New-Object System.Drawing.Point(25, 30)
    $content.Controls.Add($t)

    $d = New-Object System.Windows.Forms.Label
    $d.Text = "Choisissez l'emplacement où l'application sera installée."
    $d.Size = New-Object System.Drawing.Size(450, 30)
    $d.Location = New-Object System.Drawing.Point(25, 70)
    $content.Controls.Add($d)

    $tb = New-Object System.Windows.Forms.TextBox
    $tb.Text = $script:installPath
    $tb.Size = New-Object System.Drawing.Size(340, 28)
    $tb.Location = New-Object System.Drawing.Point(25, 110)
    $tb.Name = "pathBox"
    $content.Controls.Add($tb)

    $browse = New-Object System.Windows.Forms.Button
    $browse.Text = "Parcourir…"
    $browse.Size = New-Object System.Drawing.Size(100, 28)
    $browse.Location = New-Object System.Drawing.Point(375, 108)
    $browse.FlatStyle = "Flat"
    $browse.Add_Click({
        $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
        $fbd.Description = "Sélectionnez le dossier d'installation"
        $fbd.SelectedPath = $tb.Text
        if ($fbd.ShowDialog() -eq "OK") {
            $tb.Text = Join-Path $fbd.SelectedPath "BC Services"
            $script:installPath = $tb.Text
        }
    })
    $content.Controls.Add($browse)

    $info = New-Object System.Windows.Forms.Label
    $info.Text = "Conseil : laissez le dossier par défaut (Program Files) si vous êtes administrateur.`nSinon, choisissez un dossier dans Documents ou votre profil."
    $info.Size = New-Object System.Drawing.Size(450, 50)
    $info.Location = New-Object System.Drawing.Point(25, 160)
    $info.ForeColor = [System.Drawing.Color]::FromArgb(100, 90, 110)
    $content.Controls.Add($info)

    $btnBack.Enabled = $true
    $btnNext.Text = "Suivant →"
}

function Show-Step2 {
    # Prérequis
    Clear-Content
    $t = New-Object System.Windows.Forms.Label
    $t.Text = "Vérification des prérequis"
    $t.Font = New-Object System.Drawing.Font("Segoe UI", 13, [System.Drawing.FontStyle]::Bold)
    $t.ForeColor = $ColorText
    $t.AutoSize = $true
    $t.Location = New-Object System.Drawing.Point(25, 30)
    $content.Controls.Add($t)

    $nodeOk = Test-NodeInstalled
    $script:nodeOk = $nodeOk
    $ver = Get-NodeVersion

    $status = New-Object System.Windows.Forms.Label
    $status.Size = New-Object System.Drawing.Size(450, 80)
    $status.Location = New-Object System.Drawing.Point(25, 80)
    if ($nodeOk) {
        $status.Text = "✅ Node.js est installé ($ver)`nL'application peut démarrer immédiatement."
        $status.ForeColor = $ColorAccent
    } else {
        $status.Text = "⚠ Node.js 18 ou supérieur n'a pas été détecté.`nIl est nécessaire pour faire tourner l'application."
        $status.ForeColor = [System.Drawing.Color]::FromArgb(180, 90, 20)
    }
    $content.Controls.Add($status)

    if (-not $nodeOk) {
        $help = New-Object System.Windows.Forms.Label
        $help.Text = "Cliquez sur le bouton ci-dessous pour ouvrir la page de téléchargement officielle (version LTS recommandée). Après l'installation de Node.js, relancez cet installateur."
        $help.Size = New-Object System.Drawing.Size(450, 60)
        $help.Location = New-Object System.Drawing.Point(25, 170)
        $content.Controls.Add($help)

        $btnNode = New-Object System.Windows.Forms.Button
        $btnNode.Text = "Télécharger Node.js LTS"
        $btnNode.Size = New-Object System.Drawing.Size(200, 36)
        $btnNode.Location = New-Object System.Drawing.Point(25, 240)
        $btnNode.BackColor = $ColorAccent
        $btnNode.ForeColor = [System.Drawing.Color]::White
        $btnNode.FlatStyle = "Flat"
        $btnNode.FlatAppearance.BorderSize = 0
        $btnNode.Add_Click({
            Start-Process "https://nodejs.org/fr/download/"
        })
        $content.Controls.Add($btnNode)
    } else {
        $ok = New-Object System.Windows.Forms.Label
        $ok.Text = "Tout est prêt. Cliquez sur « Installer » pour continuer."
        $ok.Size = New-Object System.Drawing.Size(450, 30)
        $ok.Location = New-Object System.Drawing.Point(25, 180)
        $ok.ForeColor = $ColorText
        $content.Controls.Add($ok)
    }

    $btnBack.Enabled = $true
    $btnNext.Text = "Installer"
    $btnNext.Enabled = $true
}

function Show-Step3 {
    # Installation en cours + résultat
    Clear-Content
    $t = New-Object System.Windows.Forms.Label
    $t.Text = "Installation en cours…"
    $t.Font = New-Object System.Drawing.Font("Segoe UI", 13, [System.Drawing.FontStyle]::Bold)
    $t.ForeColor = $ColorText
    $t.AutoSize = $true
    $t.Location = New-Object System.Drawing.Point(25, 30)
    $content.Controls.Add($t)

    $log = New-Object System.Windows.Forms.TextBox
    $log.Multiline = $true
    $log.ReadOnly = $true
    $log.ScrollBars = "Vertical"
    $log.Size = New-Object System.Drawing.Size(450, 260)
    $log.Location = New-Object System.Drawing.Point(25, 80)
    $log.Font = New-Object System.Drawing.Font("Consolas", 9)
    $log.BackColor = [System.Drawing.Color]::FromArgb(245, 243, 248)
    $content.Controls.Add($log)

    $form.Refresh()
    $log.AppendText("Dossier cible : $($script:installPath)`r`n")
    $form.Refresh()

    try {
        $log.AppendText("Copie des fichiers…`r`n")
        $form.Refresh()
        Copy-AppFiles -Target $script:installPath
        $log.AppendText("  → Fichiers copiés.`r`n")

        $log.AppendText("Création des raccourcis…`r`n")
        $form.Refresh()
        Create-Shortcuts -InstallDir $script:installPath
        $log.AppendText("  → Raccourci Bureau créé.`r`n")
        $log.AppendText("  → Entrées Menu Démarrer créées.`r`n")

        # Marqueur pour éviter de recréer le raccourci VBS au premier lancement
        $marker = Join-Path $script:installPath ".raccourci-cree"
        if (-not (Test-Path $marker)) {
            New-Item -ItemType File -Path $marker -Force | Out-Null
            (Get-Item $marker).Attributes = "Hidden"
        }

        $log.AppendText("`r`nInstallation terminée avec succès.`r`n")
        $script:installSuccess = $true
    } catch {
        $log.AppendText("`r`nERREUR : $($_.Exception.Message)`r`n")
        $script:installSuccess = $false
    }

    $btnBack.Enabled = $false
    $btnNext.Text = "Terminer"
    $btnNext.Enabled = $true
}

function Show-Step4 {
    # Fin
    Clear-Content
    $t = New-Object System.Windows.Forms.Label
    $t.Text = if ($script:installSuccess) { "Installation réussie !" } else { "Installation incomplète" }
    $t.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
    $t.ForeColor = if ($script:installSuccess) { $ColorAccent } else { [System.Drawing.Color]::DarkRed }
    $t.AutoSize = $true
    $t.Location = New-Object System.Drawing.Point(25, 40)
    $content.Controls.Add($t)

    if ($script:installSuccess) {
        $d = New-Object System.Windows.Forms.Label
        $d.Text = "L'application a été installée dans :`n$($script:installPath)`n`nUn raccourci « BC Services » a été placé sur le Bureau et dans le Menu Démarrer."
        $d.Size = New-Object System.Drawing.Size(450, 100)
        $d.Location = New-Object System.Drawing.Point(25, 90)
        $content.Controls.Add($d)

        $cb = New-Object System.Windows.Forms.CheckBox
        $cb.Text = "Lancer BC Services maintenant"
        $cb.Checked = $true
        $cb.AutoSize = $true
        $cb.Location = New-Object System.Drawing.Point(25, 210)
        $cb.Name = "launchCb"
        $content.Controls.Add($cb)
    } else {
        $d = New-Object System.Windows.Forms.Label
        $d.Text = "Une erreur est survenue. Vérifiez les droits d'écriture sur le dossier choisi`nou relancez l'installateur en tant qu'administrateur."
        $d.Size = New-Object System.Drawing.Size(450, 80)
        $d.Location = New-Object System.Drawing.Point(25, 100)
        $content.Controls.Add($d)
    }

    $btnBack.Enabled = $false
    $btnNext.Text = "Fermer"
}

# Navigation
$btnNext.Add_Click({
    if ($script:step -eq 1) {
        $tb = $content.Controls["pathBox"]
        if ($tb) { $script:installPath = $tb.Text.Trim() }
        if ([string]::IsNullOrWhiteSpace($script:installPath)) {
            [System.Windows.Forms.MessageBox]::Show("Veuillez indiquer un dossier d'installation.", "Attention")
            return
        }
    }

    if ($script:step -eq 2) {
        # Lancer l'installation
        $script:step = 3
        Show-Step3
        return
    }

    if ($script:step -eq 3) {
        $script:step = 4
        Show-Step4
        return
    }

    if ($script:step -eq 4) {
        $cb = $content.Controls["launchCb"]
        if ($cb -and $cb.Checked -and $script:installSuccess) {
            $vbs = Join-Path $script:installPath "Demarrer BC Services.vbs"
            if (Test-Path $vbs) {
                Start-Process -FilePath "wscript.exe" -ArgumentList "`"$vbs`"" -WorkingDirectory $script:installPath
            }
        }
        $form.Close()
        return
    }

    $script:step++
    switch ($script:step) {
        0 { Show-Step0 }
        1 { Show-Step1 }
        2 { Show-Step2 }
        3 { Show-Step3 }
        4 { Show-Step4 }
    }
})

$btnBack.Add_Click({
    if ($script:step -gt 0) {
        $script:step--
        switch ($script:step) {
            0 { Show-Step0 }
            1 { Show-Step1 }
            2 { Show-Step2 }
        }
    }
})

$btnCancel.Add_Click({
    if ([System.Windows.Forms.MessageBox]::Show("Voulez-vous vraiment annuler l'installation ?", "Annuler", "YesNo") -eq "Yes") {
        $form.Close()
    }
})

# Démarrage
Show-Step0
[void]$form.ShowDialog()
