@echo off
cd /d "%~dp0"
title BC Services - mode diagnostic
echo.
echo   Mode diagnostic : les messages du serveur s'affichent ici.
echo   Fermez cette fenetre pour arreter l'application.
echo.
echo   Dossier : %CD%
echo.

where node >nul 2>nul
if errorlevel 1 (
  if exist "node\node.exe" (
    set "PATH=%CD%\node;%PATH%"
    echo   Node local trouve dans node\
  ) else (
    echo   ERREUR : Node.js n'est pas installe ou pas dans le PATH.
    echo   Telechargez la version LTS sur https://nodejs.org/fr/download
    echo.
    pause
    exit /b 1
  )
)

node -v
echo.
node backend\server.js
echo.
echo   Le serveur s'est arrete.
pause
