@echo off
title Installation BC Services
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer BC Services.ps1"
if errorlevel 1 pause
