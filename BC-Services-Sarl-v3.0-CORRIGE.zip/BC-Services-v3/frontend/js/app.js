import { api } from './api.js';
import { session, peut, definirSession } from './session.js';
import { charger as chargerParametres, parametres } from './parametres.js';
import { echapper } from './utils.js';
import { definirNavigation } from './navigation.js';
import { ecranConnexion, ecranConfiguration, ecranMotDePasseTemporaire } from './ecrans.js';
import { ouvrirCompte } from './pages/compte.js';
import * as dashboard from './pages/dashboard.js';
import * as devis from './pages/devis.js';
import * as administration from './pages/administration.js';
import * as factures from './pages/factures.js';
import * as paiements from './pages/paiements.js';
import * as clients from './pages/clients.js';
import * as articles from './pages/articles.js';
import * as comparateur from './pages/comparateur.js';
import * as inventaireGlobal from './pages/inventaire-global.js';
import * as mouvements from './pages/mouvements.js';
import * as livraisons from './pages/livraisons.js';
import * as utilisateurs from './pages/utilisateurs.js';
import * as roles from './pages/roles.js';
import * as journal from './pages/journal.js';
import * as reglages from './pages/reglages.js';

const racine = document.getElementById('racine');
const fenetre = document.getElementById('fenetre');

const PAGES = { administration, devis, dashboard, factures, paiements, clients, articles, comparateur, 'inventaire-global': inventaireGlobal, mouvements, livraisons, utilisateurs, roles, journal, reglages };
const MENU = [
  { titre: 'Ventes', entrees: [
    { page: 'devis', libelle: 'Devis', droit: 'devis.voir' },
    { page: 'livraisons', libelle: 'Bordereaux de livraison', droit: 'factures.voir' },
  ] },
  { titre: 'Facturation', entrees: [
    { page: 'dashboard', libelle: 'Tableau de bord', droit: 'tableau.voir' },
    { page: 'factures', libelle: 'Factures', droit: 'factures.voir' },
    { page: 'paiements', libelle: 'Paiements', droit: 'paiements.voir' },
    { page: 'clients', libelle: 'Clients', droit: 'clients.voir' },
  ] },
  { titre: 'Inventaire', entrees: [
    { page: 'articles', libelle: 'Articles & inventaire', droit: 'articles.voir' },
    { page: 'inventaire-global', libelle: 'Inventaire global', droit: 'articles.voir' },
    { page: 'comparateur', libelle: 'Comparateur de prix', droit: 'articles.voir' },
    { page: 'mouvements', libelle: 'Mouvements de stock', droit: 'stock.voir' },
  ] },
  { titre: 'Administration', entrees: [
    { page: 'administration', libelle: 'Centre d\'administration', droit: ['admin.utilisateurs', 'admin.roles', 'admin.journal', 'admin.parametres'] },
    { page: 'utilisateurs', libelle: 'Utilisateurs', droit: 'admin.utilisateurs' },
    { page: 'roles', libelle: 'Rôles et droits', droit: 'admin.roles' },
    { page: 'journal', libelle: 'Journal d\'activité', droit: 'admin.journal' },
    { page: 'reglages', libelle: 'Réglages', droit: 'admin.parametres' },
  ] },
];

const permis = (entree) => [].concat(entree.droit).some(peut);
const entreesPermises = () => MENU.flatMap((s) => s.entrees).filter(permis);

function afficherApplication() {
  const sections = MENU
    .map((s) => ({ ...s, entrees: s.entrees.filter(permis) }))
    .filter((s) => s.entrees.length);

  racine.innerHTML = `
    <div class="app">
      <aside>
        <img src="img/icone-256.png" alt="Logo BC Services Sarl" width="84" height="84">
        <h1>${echapper(parametres.nom)}</h1>
        <nav id="menu">
          ${sections.map((s) => `
            <div class="menu-titre">${s.titre}</div>
            ${s.entrees.map((e) => `<button data-page="${e.page}">${e.libelle}</button>`).join('')}`).join('')}
        </nav>
        <div class="pied-menu">
          ${peut('export.excel') ? '<a class="export" href="/api/export" download>Exporter en Excel</a>' : ''}
          <button class="compte" id="bouton-compte">${echapper(session.utilisateur.nom)}<small>${echapper(session.utilisateur.role)}</small></button>
        </div>
      </aside>
      <main id="contenu"></main>
    </div>`;

  document.getElementById('menu').addEventListener('click', (e) => {
    if (e.target.dataset.page) aller(e.target.dataset.page);
  });
  document.getElementById('bouton-compte').onclick = () => ouvrirCompte(deconnexion);

  const permises = entreesPermises();
  const premiere = permises.find((e) => e.page === 'dashboard') || permises[0];
  if (premiere) aller(premiere.page);
  else document.getElementById('contenu').innerHTML = '<p class="vide">Votre rôle ne donne accès à aucune page. Contactez l\'administrateur.</p>';
}

async function aller(page, options = {}) {
  const zone = document.getElementById('contenu');
  if (!zone) return;
  for (const bouton of document.querySelectorAll('#menu button')) bouton.classList.toggle('actif', bouton.dataset.page === page);
  zone.onclick = null;
  zone.oninput = null;
  try {
    await PAGES[page].afficher(zone, options);
  } catch (erreur) {
    if (erreur.statut === 401 || erreur.code === 'MDP_TEMPORAIRE') return;
    zone.innerHTML = `<p class="vide">${echapper(erreur.message)}</p>`;
  }
}
definirNavigation(aller);

async function apresConnexion(utilisateur) {
  definirSession(utilisateur);
  if (utilisateur.doit_changer_mdp) return ecranMotDePasseTemporaire(racine, apresConnexion);
  await chargerParametres();
  afficherApplication();
}

async function deconnexion() {
  try { await api.deconnexion(); } catch { }
  definirSession(null);
  ecranConnexion(racine, apresConnexion);
}

window.addEventListener('session-expiree', () => {
  if (fenetre.open) fenetre.close();
  if (!session.utilisateur) return;
  definirSession(null);
  ecranConnexion(racine, apresConnexion, 'Votre session a expiré. Reconnectez-vous.');
});
window.addEventListener('mot-de-passe-temporaire', () => {
  if (fenetre.open) fenetre.close();
  ecranMotDePasseTemporaire(racine, apresConnexion);
});

async function demarrer() {
  try {
    const info = await api.info();
    if (!info.initialise) return ecranConfiguration(racine, apresConnexion);
    try {
      await apresConnexion(await api.session());
    } catch (erreur) {
      if (erreur.statut === 401) return ecranConnexion(racine, apresConnexion);
      throw erreur;
    }
  } catch (erreur) {
    racine.innerHTML = `<div class="ecran-acces"><div class="carte-acces"><h1>BC Services</h1><div class="erreur">${echapper(erreur.message)}</div></div></div>`;
  }
}

const signaler = () => fetch('/api/presence', { method: 'POST' }).catch(() => {});
signaler();
setInterval(signaler, 30000);

demarrer();
