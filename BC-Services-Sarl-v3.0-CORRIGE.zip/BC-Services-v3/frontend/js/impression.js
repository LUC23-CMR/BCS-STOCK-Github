import { parametres } from './parametres.js';

/**
 * Impression professionnelle fiable :
 * - fenêtre dédiée (sans URL localhost dans le document)
 * - styles d'impression intégrés (pas de dépendance au chargement CSS externe)
 * - attente du logo avant d'ouvrir la boîte d'impression
 * - repli sur impression de la page si les popups sont bloquées
 */
export function imprimerDocument(titreDoc = 'Document') {
  const source = document.getElementById('facture-imprimable');
  const titrePage = `${parametres.nom || 'BC Services'} — ${titreDoc}`;

  if (!source) {
    imprimerPageCourante(titrePage);
    return;
  }

  const clone = source.cloneNode(true);
  // Chemins absolus pour les images
  clone.querySelectorAll('img').forEach((img) => {
    const src = img.getAttribute('src');
    if (!src) return;
    try {
      img.src = new URL(src, window.location.href).href;
    } catch (_) {}
  });

  const html = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>${echapperTitre(titrePage)}</title>
  <style>${cssImpressionAutonome()}</style>
</head>
<body>
  ${clone.outerHTML}
</body>
</html>`;

  // Ne PAS utiliser "noopener" : sinon document.write est impossible dans certains navigateurs
  const fenetre = window.open('', '_blank', 'width=920,height=1240');
  if (!fenetre) {
    imprimerPageCourante(titrePage);
    return;
  }

  fenetre.document.open();
  fenetre.document.write(html);
  fenetre.document.close();
  fenetre.focus();

  attendreImagesPuisImprimer(fenetre);
}

function attendreImagesPuisImprimer(fenetre) {
  const lancer = () => {
    try {
      fenetre.focus();
      fenetre.print();
    } catch (_) {
      // ignore
    }
  };

  const docs = fenetre.document;
  const images = Array.from(docs.images || []);
  if (!images.length) {
    setTimeout(lancer, 200);
    return;
  }

  let restantes = images.length;
  const done = () => {
    restantes -= 1;
    if (restantes <= 0) setTimeout(lancer, 150);
  };

  images.forEach((img) => {
    if (img.complete) done();
    else {
      img.addEventListener('load', done, { once: true });
      img.addEventListener('error', done, { once: true });
    }
  });

  // Sécurité : ne pas attendre indéfiniment
  setTimeout(lancer, 2500);
}

function imprimerPageCourante(titrePage) {
  const ancien = document.title;
  document.title = titrePage;
  // S'assurer que le document est bien visible pour @media print
  const source = document.getElementById('facture-imprimable');
  if (source) {
    source.classList.add('en-impression');
  }
  const apres = () => {
    document.title = ancien;
    if (source) source.classList.remove('en-impression');
    window.removeEventListener('afterprint', apres);
  };
  window.addEventListener('afterprint', apres);
  setTimeout(() => window.print(), 50);
}

function echapperTitre(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** CSS minimal autonome pour un rendu pro sans dépendre des fichiers externes */
function cssImpressionAutonome() {
  return `
    * { box-sizing: border-box; }
    html, body {
      margin: 0;
      padding: 0;
      background: #e8e8e8;
      color: #1a1a1a;
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      font-size: 13px;
      line-height: 1.45;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    body {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      min-height: 100vh;
      padding: 16px 0;
    }
    #facture-imprimable, .doc-pro {
      width: 190mm;
      max-width: 190mm;
      margin: 0 auto;
      padding: 10mm 12mm;
      background: #fff;
      box-shadow: 0 2px 12px rgba(0,0,0,.12);
    }
    .doc-bande-haute {
      height: 6px;
      background: linear-gradient(90deg, #4b0f87 0%, #1b7a4a 100%);
      margin-bottom: 18px;
    }
    .doc-entete {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 24px;
      margin-bottom: 22px;
      padding-bottom: 16px;
      border-bottom: 2px solid #e8e4ef;
    }
    .doc-emetteur { display: flex; align-items: flex-start; gap: 14px; max-width: 58%; }
    .doc-logo { height: 72px; width: auto; object-fit: contain; border-radius: 6px; }
    .doc-emetteur-texte { font-size: 12px; color: #444; }
    .doc-raison-sociale {
      font-size: 18px; font-weight: 800; color: #4b0f87; margin-bottom: 4px;
    }
    .doc-ligne { margin: 1px 0; color: #555; }
    .doc-ligne.identifiants { margin-top: 4px; font-size: 11px; color: #666; white-space: pre-line; }
    .doc-titre-bloc { text-align: right; min-width: 180px; }
    .doc-titre {
      margin: 4px 0 8px; font-size: 26px; font-weight: 800; color: #4b0f87;
      letter-spacing: 0.04em; text-transform: uppercase;
    }
    .doc-meta { display: flex; flex-direction: column; gap: 3px; font-size: 12px; }
    .doc-meta-item { display: flex; justify-content: flex-end; gap: 8px; }
    .doc-meta-label { color: #777; font-weight: 600; }
    .doc-meta-valeur { color: #222; font-weight: 700; min-width: 110px; text-align: right; }
    .doc-parties { margin-bottom: 18px; }
    .doc-bloc-client {
      background: #f8f6fb; border-left: 4px solid #4b0f87;
      padding: 12px 16px; border-radius: 0 8px 8px 0; max-width: 420px;
    }
    .doc-bloc-titre {
      font-size: 11px; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.06em; color: #4b0f87; margin-bottom: 6px;
    }
    .doc-client-nom { font-size: 15px; font-weight: 800; color: #222; margin-bottom: 2px; }
    .doc-badge-vip {
      display: inline-block; margin: 2px 0 4px; padding: 2px 8px; border-radius: 99px;
      font-size: 11px; font-weight: 700; background: #f0e6c0; color: #7a5c00;
    }
    .doc-table {
      width: 100%; border-collapse: collapse; margin: 8px 0 16px; font-size: 12.5px;
    }
    .doc-table th {
      background: #4b0f87; color: #fff; font-weight: 700; text-align: left;
      padding: 9px 10px; border: none;
    }
    .doc-table th.n, .doc-table td.n { text-align: right; }
    .doc-table td {
      padding: 8px 10px; border-bottom: 1px solid #eee; color: #333; vertical-align: top;
    }
    .doc-table tbody tr:nth-child(even) { background: #faf9fc; }
    .doc-totaux { margin-left: auto; width: 280px; margin-bottom: 18px; }
    .doc-total-ligne {
      display: flex; justify-content: space-between; padding: 5px 0;
      font-size: 13px; border-bottom: 1px solid #eee;
    }
    .doc-total-ligne.doc-ttc {
      margin-top: 4px; padding: 10px 0; font-size: 16px; font-weight: 800;
      color: #1b7a4a; border-bottom: 2px solid #1b7a4a; border-top: 2px solid #1b7a4a;
    }
    .doc-total-ligne.doc-reste { font-weight: 800; color: #b45309; }
    .doc-notes {
      margin: 16px 0 10px; padding: 10px 14px; background: #fafafa;
      border: 1px solid #e5e5e5; border-radius: 6px; font-size: 12px;
    }
    .doc-notes-corps { margin-top: 4px; white-space: pre-line; color: #444; }
    .doc-mention-bancaire {
      margin: 10px 0; padding: 8px 12px; font-size: 12px; background: #f0f7f3;
      border-left: 3px solid #1b7a4a; color: #333;
    }
    .doc-signatures {
      display: flex; justify-content: space-between; gap: 40px; margin: 28px 0 20px;
    }
    .doc-sig { flex: 1; max-width: 240px; }
    .doc-sig-titre { font-weight: 700; font-size: 12px; color: #4b0f87; margin-bottom: 6px; }
    .doc-sig-zone {
      min-height: 56px; border: 1px dashed #ccc; border-radius: 6px;
      padding: 8px; font-size: 11px; color: #999; display: flex; align-items: flex-end;
    }
    .doc-pied { margin-top: 12px; padding-top: 10px; }
    .doc-pied-bande {
      height: 3px; background: linear-gradient(90deg, #4b0f87 0%, #1b7a4a 100%); margin-bottom: 8px;
    }
    .doc-pied-texte { font-size: 10px; color: #777; text-align: center; line-height: 1.4; }
    .doc-pied-merci { text-align: center; font-size: 11px; font-weight: 700; color: #4b0f87; margin-top: 4px; }
    .doc-section-titre { font-size: 13px; font-weight: 800; color: #4b0f87; margin: 14px 0 6px; }
    .tampon {
      display: inline-block; padding: 3px 10px; border-radius: 4px; font-size: 11px;
      font-weight: 800; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 4px;
    }
    .tampon.payee { background: #dcfce7; color: #166534; }
    .tampon.partielle { background: #fef3c7; color: #92400e; }
    .tampon.brouillon { background: #e5e7eb; color: #374151; }
    .tampon.annulee { background: #fee2e2; color: #991b1b; }

    @page { size: A4 portrait; margin: 12mm 14mm; }
    @media print {
      html, body {
        background: #fff !important;
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        display: block !important;
      }
      body { padding: 0 !important; }
      #facture-imprimable, .doc-pro {
        width: 100% !important;
        max-width: 100% !important;
        margin: 0 auto !important;
        padding: 0 !important;
        box-shadow: none !important;
      }
    }
  `;
}
