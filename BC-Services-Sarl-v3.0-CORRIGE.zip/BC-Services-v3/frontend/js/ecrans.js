import { api } from './api.js';
import { echapper } from './utils.js';

function carte(titre, sousTitre, contenu) {
  return `
    <div class="ecran-acces"><form class="carte-acces" id="formulaire-acces" autocomplete="on">
      <img src="img/icone-256.png" alt="BC Services Sarl">
      <h1>${titre}</h1>
      <p class="sous-titre">${sousTitre}</p>
      ${contenu}
      <div id="message-acces"></div>
    </form></div>`;
}

function brancher(racine, envoyer) {
  const formulaire = racine.querySelector('#formulaire-acces');
  const message = racine.querySelector('#message-acces');
  formulaire.onsubmit = async (e) => {
    e.preventDefault();
    const bouton = formulaire.querySelector('button[type=submit]');
    bouton.disabled = true;
    message.innerHTML = '';
    try {
      await envoyer(Object.fromEntries(new FormData(formulaire)));
    } catch (erreur) {
      message.innerHTML = `<div class="erreur">${echapper(erreur.message)}</div>`;
      bouton.disabled = false;
    }
  };
  const premier = formulaire.querySelector('input');
  if (premier) premier.focus();
}

export function ecranConnexion(racine, apres, messageInitial = '') {
  racine.innerHTML = carte('BC Services', 'Connectez-vous pour continuer', `
    ${messageInitial ? `<div class="info">${echapper(messageInitial)}</div>` : ''}
    <label>Identifiant <input name="identifiant" autocomplete="username" required></label>
    <label>Mot de passe <input name="mot_de_passe" type="password" autocomplete="current-password" required></label>
    <button class="btn" type="submit">Se connecter</button>
    <p class="lien-oubli"><button type="button" class="lien" id="lien-mdp-oublie">Mot de passe administrateur oublié ?</button></p>`);
  brancher(racine, async (v) => apres(await api.connexion(v.identifiant, v.mot_de_passe)));
  const lien = racine.querySelector('#lien-mdp-oublie');
  if (lien) lien.onclick = () => ecranReinitialiserAdmin(racine, apres);
}

export function ecranReinitialiserAdmin(racine, apres) {
  racine.innerHTML = carte(
    'Réinitialiser le mot de passe',
    'Réservé au compte administrateur, uniquement sur cet ordinateur. Saisissez l\'identifiant admin et un nouveau mot de passe.',
    `
    <label>Identifiant administrateur <input name="identifiant" autocomplete="username" required placeholder="ex : directeur"></label>
    <label>Nouveau mot de passe <input name="mot_de_passe" type="password" autocomplete="new-password" minlength="8" required></label>
    <span class="aide-champ">8 caractères minimum. Notez-le dans un endroit sûr.</span>
    <label>Confirmez le nouveau mot de passe <input name="confirmation" type="password" autocomplete="new-password" required></label>
    <button class="btn" type="submit">Réinitialiser le mot de passe</button>
    <p class="lien-oubli"><button type="button" class="lien" id="lien-retour-connexion">← Retour à la connexion</button></p>`);
  brancher(racine, async (v) => {
    if (v.mot_de_passe !== v.confirmation) throw new Error('Les deux mots de passe ne sont pas identiques.');
    const r = await api.reinitialiserAdmin({
      identifiant: v.identifiant,
      mot_de_passe: v.mot_de_passe,
      confirmation: v.confirmation,
    });
    ecranConnexion(racine, apres, r.message || 'Mot de passe réinitialisé. Connectez-vous.');
  });
  const retour = racine.querySelector('#lien-retour-connexion');
  if (retour) retour.onclick = () => ecranConnexion(racine, apres);
}

export function ecranConfiguration(racine, apres) {
  racine.innerHTML = carte('Bienvenue sur BC Services', 'Première utilisation : créez le compte administrateur. C\'est lui qui donnera ensuite accès aux autres membres.', `
    <label>Votre nom <input name="nom" autocomplete="name" required></label>
    <label>Identifiant de connexion <input name="identifiant" autocomplete="username" required placeholder="ex : directeur"></label>
    <label>Mot de passe <input name="mot_de_passe" type="password" autocomplete="new-password" minlength="8" required></label>
    <span class="aide-champ">8 caractères minimum. En cas d\'oubli, un bouton de réinitialisation sera disponible sur l\'écran de connexion (sur cet ordinateur uniquement).</span>
    <label>Confirmez le mot de passe <input name="confirmation" type="password" autocomplete="new-password" required></label>
    <button class="btn" type="submit">Créer le compte et commencer</button>`);
  brancher(racine, async (v) => {
    if (v.mot_de_passe !== v.confirmation) throw new Error('Les deux mots de passe ne sont pas identiques.');
    apres(await api.configurationInitiale({ nom: v.nom, identifiant: v.identifiant, mot_de_passe: v.mot_de_passe }));
  });
}

export function ecranMotDePasseTemporaire(racine, apres) {
  racine.innerHTML = carte('Choisissez votre mot de passe', 'Pour votre sécurité, remplacez le mot de passe temporaire reçu de l\'administrateur.', `
    <label>Mot de passe temporaire <input name="ancien" type="password" autocomplete="current-password" required></label>
    <label>Nouveau mot de passe <input name="nouveau" type="password" autocomplete="new-password" minlength="8" required></label>
    <span class="aide-champ">8 caractères minimum.</span>
    <label>Confirmez le nouveau mot de passe <input name="confirmation" type="password" autocomplete="new-password" required></label>
    <button class="btn" type="submit">Enregistrer et continuer</button>`);
  brancher(racine, async (v) => {
    if (v.nouveau !== v.confirmation) throw new Error('Les deux mots de passe ne sont pas identiques.');
    apres(await api.changerMotDePasse(v.ancien, v.nouveau));
  });
}
