import { api } from './api.js';

export const parametres = {
  nom: 'BC Services Sarl',
  adresse: '', telephone: '', email: '', identifiants: '', mentionBancaire: '',
  tvaParDefaut: 18,
  devise: 'FCFA',
  decimales: 0,
  prefixeFacture: 'FAC',
  prefixeDevis: 'DEV',
  validiteDevis: 30,
  conditionsParDefaut: 0,
  majorationVip: 10,
  prefixeLivraison: 'BL',
  modesPaiement: ['Espèces', 'Virement', 'Chèque', 'Mobile Money', 'Carte bancaire', 'Autre'],
  conditionsPaiement: [0, 15, 30, 45, 60],
};

export async function charger() {
  Object.assign(parametres, await api.parametres());
}
