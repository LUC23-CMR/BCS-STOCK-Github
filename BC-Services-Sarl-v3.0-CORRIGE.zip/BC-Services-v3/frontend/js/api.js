async function appeler(methode, url, corps) {
  let reponse;
  try {
    reponse = await fetch(url, {
      method: methode,
      headers: { 'Content-Type': 'application/json' },
      body: corps ? JSON.stringify(corps) : undefined,
    });
  } catch {
    throw new Error('Le serveur ne répond pas. Vérifiez que l\'application est bien lancée, puis rechargez la page.');
  }
  const donnees = await reponse.json().catch(() => ({}));
  if (!reponse.ok) {
    if (donnees.code === 'NON_CONNECTE') window.dispatchEvent(new Event('session-expiree'));
    if (donnees.code === 'MDP_TEMPORAIRE') window.dispatchEvent(new Event('mot-de-passe-temporaire'));
    const erreur = new Error(donnees.erreur || 'Une erreur est survenue.');
    erreur.statut = reponse.status;
    erreur.code = donnees.code;
    throw erreur;
  }
  return donnees;
}

const requete = (objet) => {
  const p = new URLSearchParams();
  for (const [cle, valeur] of Object.entries(objet || {})) if (valeur !== undefined && valeur !== '' && valeur !== null) p.set(cle, valeur);
  const texte = p.toString();
  return texte ? '?' + texte : '';
};

export const api = {
  info:                    () => appeler('GET', '/api/info'),
  arreter:                 () => appeler('POST', '/api/arret'),
  configurationInitiale:   (d) => appeler('POST', '/api/configuration-initiale', d),
  connexion:               (identifiant, mot_de_passe) => appeler('POST', '/api/connexion', { identifiant, mot_de_passe }),
  deconnexion:             () => appeler('POST', '/api/deconnexion'),
  session:                 () => appeler('GET', '/api/session'),
  changerMotDePasse:       (ancien, nouveau) => appeler('POST', '/api/session/mot-de-passe', { ancien, nouveau }),
  reinitialiserAdmin:      (d) => appeler('POST', '/api/session/reinitialiser-admin', d),

  parametres:              () => appeler('GET', '/api/parametres'),
  modifierParametres:      (d) => appeler('PUT', '/api/parametres', d),
  systeme:                 () => appeler('GET', '/api/systeme'),
  reparerApplication:      () => appeler('POST', '/api/systeme/reparer'),
  categories:              () => appeler('GET', '/api/categories'),
  creerCategorie:          (nom) => appeler('POST', '/api/categories', { nom }),
  renommerCategorie:       (id, nom) => appeler('PUT', `/api/categories/${id}`, { nom }),
  supprimerCategorie:      (id) => appeler('DELETE', `/api/categories/${id}`),

  dashboard:               () => appeler('GET', '/api/dashboard'),

  clients:                 () => appeler('GET', '/api/clients'),
  creerClient:             (c) => appeler('POST', '/api/clients', c),
  modifierClient:          (id, c) => appeler('PUT', `/api/clients/${id}`, c),
  supprimerClient:         (id) => appeler('DELETE', `/api/clients/${id}`),

  devis:                   () => appeler('GET', '/api/devis'),
  unDevis:                 (id) => appeler('GET', `/api/devis/${id}`),
  creerDevis:              (d) => appeler('POST', '/api/devis', d),
  modifierDevis:           (id, d) => appeler('PUT', `/api/devis/${id}`, d),
  statutDevis:             (id, statut, raison_refus = '') => appeler('POST', `/api/devis/${id}/statut`, { statut, raison_refus }),
  facturerDevis:           (id) => appeler('POST', `/api/devis/${id}/facturer`),
  supprimerDevis:          (id) => appeler('DELETE', `/api/devis/${id}`),

  factures:                () => appeler('GET', '/api/factures'),
  facture:                 (id) => appeler('GET', `/api/factures/${id}`),
  creerFacture:            (f) => appeler('POST', '/api/factures', f),
  modifierFacture:         (id, f) => appeler('PUT', `/api/factures/${id}`, f),
  validerFacture:          (id) => appeler('POST', `/api/factures/${id}/valider`),
  annulerFacture:          (id) => appeler('POST', `/api/factures/${id}/annuler`),
  supprimerFacture:        (id) => appeler('DELETE', `/api/factures/${id}`),
  enregistrerPaiement:     (id, p) => appeler('POST', `/api/factures/${id}/paiements`, p),
  paiements:               () => appeler('GET', '/api/paiements'),
  supprimerPaiement:       (id) => appeler('DELETE', `/api/paiements/${id}`),

  produits:                () => appeler('GET', '/api/produits'),
  creerProduit:            (p) => appeler('POST', '/api/produits', p),
  modifierProduit:         (id, p) => appeler('PUT', `/api/produits/${id}`, p),
  supprimerProduit:        (id) => appeler('DELETE', `/api/produits/${id}`),
  fournisseurs:            () => appeler('GET', '/api/fournisseurs'),
  creerFournisseur:        (f) => appeler('POST', '/api/fournisseurs', f),
  modifierFournisseur:     (id, f) => appeler('PUT', `/api/fournisseurs/${id}`, f),
  supprimerFournisseur:    (id) => appeler('DELETE', `/api/fournisseurs/${id}`),
  livraisons:              () => appeler('GET', '/api/livraisons'),
  livraisonsDocuments:     () => appeler('GET', '/api/livraisons/documents'),
  uneLivraison:            (id) => appeler('GET', `/api/livraisons/${id}`),
  creerLivraison:          (d) => appeler('POST', '/api/livraisons', d),
  supprimerLivraison:      (id) => appeler('DELETE', `/api/livraisons/${id}`),
  mouvements:              (filtres) => appeler('GET', '/api/mouvements' + requete(filtres)),
  reception:               (d) => appeler('POST', '/api/stock/reception', d),
  sortie:                  (d) => appeler('POST', '/api/stock/sortie', d),
  inventaire:              (d) => appeler('POST', '/api/stock/inventaire', d),

  utilisateurs:            () => appeler('GET', '/api/utilisateurs'),
  creerUtilisateur:        (u) => appeler('POST', '/api/utilisateurs', u),
  modifierUtilisateur:     (id, u) => appeler('PUT', `/api/utilisateurs/${id}`, u),
  activerUtilisateur:      (id, actif) => appeler('POST', `/api/utilisateurs/${id}/activation`, { actif }),
  reinitialiserMotDePasse: (id) => appeler('POST', `/api/utilisateurs/${id}/mot-de-passe`),
  roles:                   () => appeler('GET', '/api/roles'),
  permissions:             () => appeler('GET', '/api/permissions'),
  creerRole:               (r) => appeler('POST', '/api/roles', r),
  modifierRole:            (id, r) => appeler('PUT', `/api/roles/${id}`, r),
  supprimerRole:           (id) => appeler('DELETE', `/api/roles/${id}`),
  journal:                 (filtres) => appeler('GET', '/api/journal' + requete(filtres)),
};
