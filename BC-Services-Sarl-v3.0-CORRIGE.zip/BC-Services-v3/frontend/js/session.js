import { api } from './api.js';

export const session = { utilisateur: null, permissions: new Set() };

export const peut = (droit) => session.permissions.has(droit);

export function definirSession(utilisateur) {
  session.utilisateur = utilisateur;
  session.permissions = new Set(utilisateur ? utilisateur.permissions : []);
}

export async function chargerSession() {
  definirSession(await api.session());
  return session.utilisateur;
}
