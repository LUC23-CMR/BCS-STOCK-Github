import { echapper, montant, dateFr } from './utils.js';
import { parametres } from './parametres.js';

/** Bloc identité entreprise (logo + toutes les coordonnées) */
export function enTeteEntreprise() {
  const p = parametres;
  const lignes = [];
  if (p.adresse) lignes.push(`<div class="doc-ligne">${echapper(p.adresse)}</div>`);
  if (p.telephone) lignes.push(`<div class="doc-ligne">Tél. : ${echapper(p.telephone)}</div>`);
  if (p.email) lignes.push(`<div class="doc-ligne">Email : ${echapper(p.email)}</div>`);
  if (p.identifiants) lignes.push(`<div class="doc-ligne identifiants">${echapper(p.identifiants)}</div>`);

  return `
    <div class="doc-emetteur">
      <img class="doc-logo" src="img/logo.jpg" alt="${echapper(p.nom || 'Logo')}">
      <div class="doc-emetteur-texte">
        <div class="doc-raison-sociale">${echapper(p.nom || 'Entreprise')}</div>
        ${lignes.join('')}
      </div>
    </div>`;
}

/** Bloc client destinataire */
export function blocClient(client, titre = 'Client') {
  if (!client) return '';
  const parts = [
    client.nom ? `<div class="doc-client-nom">${echapper(client.nom)}</div>` : '',
    client.type_client === 'VIP' ? '<div class="doc-badge-vip">Client VIP</div>' : '',
    client.adresse ? `<div class="doc-ligne">${echapper(client.adresse)}</div>` : '',
    client.telephone ? `<div class="doc-ligne">Tél. : ${echapper(client.telephone)}</div>` : '',
    client.email ? `<div class="doc-ligne">${echapper(client.email)}</div>` : '',
  ].filter(Boolean);
  return `
    <div class="doc-bloc-client">
      <div class="doc-bloc-titre">${echapper(titre)}</div>
      ${parts.join('')}
    </div>`;
}

/** Méta document (n°, dates, moyen de paiement…) */
export function metaDocument(items) {
  const rows = items.filter((x) => x && x.valeur).map(({ label, valeur }) =>
    `<div class="doc-meta-item"><span class="doc-meta-label">${echapper(label)}</span><span class="doc-meta-valeur">${valeur}</span></div>`
  ).join('');
  return `<div class="doc-meta">${rows}</div>`;
}

/** Tableau de lignes articles */
export function tableauLignes(lignes, { avecPrix = true } = {}) {
  const head = avecPrix
    ? '<th>Désignation</th><th class="n">Qté</th><th class="n">P.U. HT</th><th class="n">Total HT</th>'
    : '<th>Désignation</th><th class="n">Qté</th><th>Unité</th>';
  const body = (lignes || []).map((l) => {
    if (avecPrix) {
      return `<tr>
        <td>${echapper(l.designation)}</td>
        <td class="n">${l.quantite}</td>
        <td class="n">${montant(l.prix_unitaire)}</td>
        <td class="n">${montant(l.quantite * l.prix_unitaire)}</td>
      </tr>`;
    }
    return `<tr>
      <td>${echapper(l.designation)}</td>
      <td class="n">${l.quantite}</td>
      <td>${echapper(l.unite || 'pièce')}</td>
    </tr>`;
  }).join('');
  return `<table class="doc-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

/** Totaux HT / TVA / TTC */
export function blocTotaux({ total_ht, tva, total_tva, total_ttc, paye, reste, statut }) {
  let extra = '';
  if (statut === 'validée' && paye > 0) {
    extra = `
      <div class="doc-total-ligne"><span>Déjà payé</span><span>${montant(paye)}</span></div>
      <div class="doc-total-ligne doc-reste"><span>Reste à payer</span><span>${montant(reste)}</span></div>`;
  }
  return `
    <div class="doc-totaux">
      <div class="doc-total-ligne"><span>Total HT</span><span>${montant(total_ht)}</span></div>
      <div class="doc-total-ligne"><span>TVA ${tva} %</span><span>${montant(total_tva)}</span></div>
      <div class="doc-total-ligne doc-ttc"><span>Total TTC</span><span>${montant(total_ttc)}</span></div>
      ${extra}
    </div>`;
}

/** Pied de page professionnel */
export function piedDocument({ signatureGauche, signatureDroite, notes, mentionBancaire } = {}) {
  const p = parametres;
  const mentions = [
    p.nom,
    p.adresse,
    p.telephone ? `Tél. ${p.telephone}` : '',
    p.email,
    p.identifiants,
  ].filter(Boolean).join(' · ');

  return `
    ${notes ? `<div class="doc-notes"><b>Notes et conditions</b><div class="doc-notes-corps">${echapper(notes)}</div></div>` : ''}
    ${mentionBancaire || p.mentionBancaire ? `<div class="doc-mention-bancaire">${echapper(mentionBancaire || p.mentionBancaire)}</div>` : ''}
    <div class="doc-signatures">
      <div class="doc-sig"><div class="doc-sig-titre">${echapper(signatureGauche || p.nom || 'L\'entreprise')}</div><div class="doc-sig-zone">Cachet et signature</div></div>
      <div class="doc-sig"><div class="doc-sig-titre">${echapper(signatureDroite || 'Client')}</div><div class="doc-sig-zone">Date et signature</div></div>
    </div>
    <div class="doc-pied">
      <div class="doc-pied-bande"></div>
      <div class="doc-pied-texte">${echapper(mentions)}</div>
      <div class="doc-pied-merci">Merci de votre confiance</div>
    </div>`;
}

/** Enveloppe complète d'un document imprimable */
export function enveloppeDocument({ titre, tampon, meta, client, clientTitre, corps, pied }) {
  return `
    <div id="facture-imprimable" class="doc-pro">
      <div class="doc-bande-haute"></div>
      <div class="doc-entete">
        ${enTeteEntreprise()}
        <div class="doc-titre-bloc">
          ${tampon ? `<span class="tampon ${tampon[0]}">${tampon[1]}</span>` : ''}
          <h3 class="doc-titre">${echapper(titre)}</h3>
          ${meta || ''}
        </div>
      </div>
      <div class="doc-parties">
        ${blocClient(client, clientTitre || 'Facturé à')}
      </div>
      ${corps || ''}
      ${pied || ''}
    </div>`;
}
