import { parametres } from './parametres.js';

export function echapper(texte) {
  return String(texte ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function montant(n) {
  const d = parametres.decimales;
  return Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d }) + ' ' + parametres.devise;
}

export function aujourdhui() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function ajouterJours(iso, jours) {
  const [a, m, j] = iso.split('-').map(Number);
  const d = new Date(a, m - 1, j + jours);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export const dateFr = (iso) => (iso ? iso.slice(0, 10).split('-').reverse().join('/') : '');
export const dateHeureFr = (texte) => (texte ? `${dateFr(texte)} ${texte.slice(11, 16)}` : '');

const arrondir = (x, d) => Math.round((x + Number.EPSILON) * 10 ** d) / 10 ** d;

export function calculerTotaux(lignes, tva) {
  const d = parametres.decimales;
  const ht = arrondir(lignes.reduce((s, l) => s + l.quantite * l.prix_unitaire, 0), d);
  const montantTva = arrondir((ht * tva) / 100, d);
  return { ht, tva: montantTva, ttc: arrondir(ht + montantTva, d) };
}

export function repartirTranches(totalTtc, tranches) {
  const d = parametres.decimales;
  let cumule = 0;
  return tranches.map((t, i) => {
    const derniere = i === tranches.length - 1;
    const m = derniere ? arrondir(totalTtc - cumule, d) : arrondir((totalTtc * t.pourcentage) / 100, d);
    cumule = arrondir(cumule + m, d);
    return { ...t, montant: m };
  });
}

export function badgeTranche(t) {
  if (t.statut === 'payée') return '<span class="badge vert">Payée</span>';
  if (t.en_retard) return `<span class="badge rouge">${t.statut === 'partielle' ? 'Partielle · en retard' : 'En retard'}</span>`;
  if (t.statut === 'partielle') return '<span class="badge orange">Partielle</span>';
  return '<span class="badge violet">À payer</span>';
}

export function badgeFacture(f) {
  if (f.statut === 'brouillon') return '<span class="badge gris">Brouillon</span>';
  if (f.statut === 'annulée') return '<span class="badge gris barre">Annulée</span>';
  if (f.paiement === 'payée') return '<span class="badge vert">Payée</span>';
  const avancement = f.nb_tranches > 1 ? ` <span class="aide-champ">${f.tranches_payees}/${f.nb_tranches} tranches</span>` : '';
  if (f.paiement === 'partielle') return `<span class="badge orange">Partiellement payée</span>${f.en_retard ? ' <span class="badge rouge">En retard</span>' : ''}${avancement}`;
  return (f.en_retard ? '<span class="badge rouge">En retard</span>' : '<span class="badge violet">À payer</span>') + avancement;
}

export function badgeDevis(d) {
  if (d.expire) return '<span class="badge orange">Expiré</span>';
  const styles = { brouillon: ['gris', 'Brouillon'], envoyé: ['violet', 'Envoyé'], accepté: ['vert', 'Accepté'], refusé: ['rouge', 'Refusé'], facturé: ['vert', 'Facturé'] };
  const [classe, texte] = styles[d.statut] || ['gris', d.statut];
  return `<span class="badge ${classe}">${texte}</span>`;
}

export function retarder(fn, delai = 300) {
  let minuteur;
  return (...args) => { clearTimeout(minuteur); minuteur = setTimeout(() => fn(...args), delai); };
}
