let allerVers = () => {};
export const definirNavigation = (fn) => { allerVers = fn; };
export const aller = (page, options) => allerVers(page, options);
