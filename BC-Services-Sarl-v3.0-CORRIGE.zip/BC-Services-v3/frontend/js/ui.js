const fenetre = document.getElementById('fenetre');
const corps = document.getElementById('fenetre-corps');
const titre = document.getElementById('fenetre-titre');

let actions = {};
let surChangement = null;
let surSaisie = null;

export function ouvrir(texteTitre, html, options = {}) {
  titre.textContent = texteTitre;
  corps.innerHTML = html;
  actions = options.actions || {};
  surChangement = options.surChangement || null;
  surSaisie = options.surSaisie || null;
  if (!fenetre.open) fenetre.showModal();
}

export function remplacerCorps(html) {
  corps.innerHTML = html;
}

export function fermer() {
  fenetre.close();
}

export async function essayer(fn) {
  try {
    await fn();
  } catch (erreur) {
    alert(erreur.message);
  }
}

export function notifier(message, type = 'ok') {
  const zone = document.getElementById('notifications');
  const bulle = document.createElement('div');
  bulle.className = 'notification ' + type;
  bulle.textContent = message;
  zone.appendChild(bulle);
  setTimeout(() => bulle.remove(), 3500);
}

fenetre.addEventListener('click', (e) => {
  const bouton = e.target.closest('[data-action]');
  if (!bouton) return;
  const nom = bouton.dataset.action;
  if (nom === 'fermer') return fermer();
  actions[nom]?.(bouton);
});

fenetre.addEventListener('change', (e) => surChangement?.(e));
fenetre.addEventListener('input', (e) => surSaisie?.(e));
