import { api } from '../api.js';
import { echapper, aujourdhui, dateFr } from '../utils.js';
import { parametres } from '../parametres.js';
import { imprimerDocument } from '../impression.js';
import { peut } from '../session.js';
import { ouvrir, fermer, essayer, notifier } from '../ui.js';

export async function afficher(zone) {
  const liste = await api.livraisons();
  const rafraichir = () => afficher(zone);

  zone.innerHTML = `
    <div class="barre">
      <h2>Bordereaux de livraison</h2>
      ${peut('factures.creer') ? '<button class="btn" data-action="nouveau">Nouveau bordereau</button>' : ''}
    </div>
    <p class="aide-champ" style="margin:0 0 12px">Chaque bordereau est obligatoirement relié à une facture ou à un devis. Les lignes sont reprises du document lié.</p>
    <div class="tableau"><table>
      <thead><tr><th>Numéro</th><th>Date</th><th>Client</th><th>Document lié</th><th>Adresse</th><th>Statut</th><th></th></tr></thead>
      <tbody>
        ${liste.map((l) => `
          <tr>
            <td><b>${echapper(l.numero)}</b></td>
            <td>${echapper(l.date_livraison)}</td>
            <td>${echapper(l.client_nom)}</td>
            <td>${l.document_type === 'devis' ? 'Devis' : 'Facture'} ${echapper(l.document_numero || '—')}</td>
            <td>${echapper(l.adresse_livraison)}</td>
            <td>${echapper(l.statut)}</td>
            <td class="actions">
              <button class="btn alt sm" data-action="voir" data-id="${l.id}">Voir / Imprimer</button>
              ${peut('factures.supprimer') ? `<button class="btn alt sm" data-action="supprimer" data-id="${l.id}">Supprimer</button>` : ''}
            </td>
          </tr>`).join('') || '<tr><td colspan="7" class="vide">Aucun bordereau de livraison.</td></tr>'}
      </tbody>
    </table></div>`;

  zone.onclick = (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const bl = liste.find((x) => x.id === Number(btn.dataset.id));
    switch (btn.dataset.action) {
      case 'nouveau': return creer(rafraichir);
      case 'voir': return voir(bl);
      case 'supprimer':
        if (!confirm(`Supprimer le bordereau ${bl.numero} ?`)) return;
        return essayer(async () => {
          await api.supprimerLivraison(bl.id);
          notifier('Bordereau supprimé.');
          await rafraichir();
        });
    }
  };
}

function voir(bl) {
  const feuille = `
    <div id="facture-imprimable" class="doc-pro">
      <div class="doc-bande-haute"></div>
      <div class="doc-entete">
        <div class="doc-emetteur">
          <img class="doc-logo" src="img/logo.jpg" alt="${echapper(parametres.nom)}">
          <div class="doc-emetteur-texte">
            <div class="doc-raison-sociale">${echapper(parametres.nom)}</div>
            ${parametres.adresse ? `<div class="doc-ligne">${echapper(parametres.adresse)}</div>` : ''}
            ${parametres.telephone ? `<div class="doc-ligne">Tél. : ${echapper(parametres.telephone)}</div>` : ''}
            ${parametres.email ? `<div class="doc-ligne">Email : ${echapper(parametres.email)}</div>` : ''}
            ${parametres.identifiants ? `<div class="doc-ligne identifiants">${echapper(parametres.identifiants)}</div>` : ''}
          </div>
        </div>
        <div class="doc-titre-bloc">
          <h3 class="doc-titre">Bordereau de livraison</h3>
          <div class="doc-meta">
            <div class="doc-meta-item"><span class="doc-meta-label">N°</span><span class="doc-meta-valeur">${echapper(bl.numero)}</span></div>
            <div class="doc-meta-item"><span class="doc-meta-label">Date</span><span class="doc-meta-valeur">${echapper(bl.date_livraison)}</span></div>
            <div class="doc-meta-item"><span class="doc-meta-label">Document lié</span><span class="doc-meta-valeur">${bl.document_type === 'devis' ? 'Devis' : 'Facture'} ${echapper(bl.document_numero || '—')}</span></div>
          </div>
        </div>
      </div>
      <div class="doc-parties">
        <div class="doc-bloc-client">
          <div class="doc-bloc-titre">Livré à</div>
          <div class="doc-client-nom">${echapper(bl.client_nom)}</div>
          ${bl.adresse_livraison ? `<div class="doc-ligne"><b>Adresse de livraison :</b> ${echapper(bl.adresse_livraison)}</div>` : ''}
        </div>
      </div>
      <table class="doc-table">
        <thead><tr><th>Désignation</th><th class="n">Qté</th><th>Unité</th></tr></thead>
        <tbody>${(bl.lignes || []).map((l) => `
          <tr><td>${echapper(l.designation)}</td><td class="n">${l.quantite}</td><td>${echapper(l.unite || 'pièce')}</td></tr>`).join('')}
        </tbody>
      </table>
      ${bl.notes ? `<div class="doc-notes"><b>Notes</b><div class="doc-notes-corps">${echapper(bl.notes)}</div></div>` : ''}
      <div class="doc-signatures">
        <div class="doc-sig"><div class="doc-sig-titre">${echapper(parametres.nom)}</div><div class="doc-sig-zone">Cachet et signature du livreur</div></div>
        <div class="doc-sig"><div class="doc-sig-titre">Client</div><div class="doc-sig-zone">Réception conforme — date et signature</div></div>
      </div>
      <div class="doc-pied">
        <div class="doc-pied-bande"></div>
        <div class="doc-pied-texte">${[parametres.nom, parametres.adresse, parametres.telephone, parametres.email, parametres.identifiants].filter(Boolean).map(echapper).join(' · ')}</div>
        <div class="doc-pied-merci">Merci de votre confiance</div>
      </div>
    </div>`;

  ouvrir(bl.numero, `
    <div class="fenetre-contenu">${feuille}</div>
    <div class="fenetre-pied">
      <button class="btn alt" data-action="fermer">Fermer</button>
      <button class="btn" data-action="imprimer">Imprimer</button>
    </div>`, {
    actions: {
      fermer: () => fermer(),
      imprimer: () => imprimerDocument(bl.numero || 'Bordereau'),
    },
  });
}

async function creer(apres) {
  const documents = await api.livraisonsDocuments();
  if (!documents.length) {
    return alert('Aucun devis ou facture disponible.\nCréez d\'abord un devis (accepté/envoyé) ou une facture, puis revenez créer le bordereau.');
  }

  const options = documents.map((d) =>
    `<option value="${d.type}:${d.id}">${d.type === 'devis' ? 'Devis' : 'Facture'} ${echapper(d.numero)} — ${echapper(d.client_nom)} (${echapper(d.date)})</option>`
  ).join('');

  ouvrir('Nouveau bordereau de livraison', `
    <div class="fenetre-contenu"><div class="grille">
      <label>Document lié (obligatoire)
        <select id="bl-doc">${options}</select>
        <span class="aide-champ">Le bordereau doit être relié à une facture ou un devis. Les lignes sont reprises automatiquement.</span>
      </label>
      <label>Date de livraison <input type="date" id="bl-date" value="${aujourdhui()}"></label>
      <label>Adresse de livraison <input id="bl-adresse" placeholder="Adresse (préremplie avec celle du client si vide)"></label>
      <label>Notes <input id="bl-notes"></label>
    </div></div>
    <div class="fenetre-pied"><button class="btn" data-action="enregistrer">Créer le bordereau</button></div>`,
  {
    actions: {
      enregistrer() {
        const raw = document.getElementById('bl-doc').value;
        const [type, idStr] = raw.split(':');
        const id = Number(idStr);
        const data = {
          document_type: type,
          facture_id: type === 'facture' ? id : 0,
          devis_id: type === 'devis' ? id : 0,
          date_livraison: document.getElementById('bl-date').value,
          adresse_livraison: document.getElementById('bl-adresse').value,
          notes: document.getElementById('bl-notes').value,
        };
        essayer(async () => {
          const bl = await api.creerLivraison(data);
          fermer();
          notifier('Bordereau créé : ' + bl.numero + ' (lié à ' + (bl.document_numero || type) + ')');
          await apres();
        });
      },
    },
  });
}
