import { api } from '../api.js';
import { echapper, dateHeureFr, retarder } from '../utils.js';

function badgeAction(action) {
  const classes = {
    'Connexion': 'gris', 'Déconnexion': 'gris', 'Échec de connexion': 'rouge',
    'Création': 'vert', 'Validation': 'vert', 'Facturation': 'vert', 'Conversion': 'vert', 'Paiement': 'vert', 'Réactivation': 'vert',
    'Modification': 'orange', 'Changement de statut': 'orange', 'Mouvement de stock': 'orange', 'Mot de passe': 'orange',
    'Suppression': 'rouge', 'Annulation': 'rouge', 'Désactivation': 'rouge', 'Export': 'violet',
  };
  return `<span class="badge ${classes[action] || 'gris'}">${echapper(action)}</span>`;
}

export async function afficher(zone) {
  const filtres = { q: '', utilisateur: '', action: '', limite: 300 };

  zone.innerHTML = `
    <div class="barre">
      <h2>Journal d'activité</h2>
      <input id="j-recherche" class="recherche" placeholder="Rechercher…">
      <select id="j-utilisateur"><option value="">Tous les utilisateurs</option></select>
      <select id="j-action"><option value="">Toutes les actions</option></select>
    </div>
    <div class="tableau"><table>
      <thead><tr><th>Date et heure</th><th>Utilisateur</th><th>Action</th><th>Objet</th><th>Détail</th></tr></thead>
      <tbody id="j-lignes"></tbody>
    </table></div>
    <p class="pied-tableau" id="j-pied"></p>`;

  async function charger() {
    const r = await api.journal(filtres);
    for (const [id, valeurs, premier] of [['j-utilisateur', r.utilisateurs, 'Tous les utilisateurs'], ['j-action', r.actions, 'Toutes les actions']]) {
      const select = zone.querySelector('#' + id);
      if (select.options.length === 1) select.innerHTML = `<option value="">${premier}</option>` + valeurs.map((v) => `<option>${echapper(v)}</option>`).join('');
    }
    zone.querySelector('#j-lignes').innerHTML = r.entrees.map((e) => `
      <tr><td style="white-space:nowrap">${dateHeureFr(e.date_heure)}</td><td>${echapper(e.utilisateur)}</td><td>${badgeAction(e.action)}</td>
          <td>${echapper(e.objet)}</td><td>${echapper(e.detail)}</td></tr>`).join('') || '<tr><td colspan="5" class="vide">Aucune entrée.</td></tr>';
    zone.querySelector('#j-pied').innerHTML = r.total > r.entrees.length
      ? `${r.entrees.length} entrées affichées sur ${r.total}. <button class="btn alt sm" data-action="plus">Afficher plus</button>`
      : `${r.total} entrée(s).`;
  }

  zone.querySelector('#j-recherche').oninput = retarder((e) => { filtres.q = e.target.value; filtres.limite = 300; charger(); });
  zone.querySelector('#j-utilisateur').onchange = (e) => { filtres.utilisateur = e.target.value; filtres.limite = 300; charger(); };
  zone.querySelector('#j-action').onchange = (e) => { filtres.action = e.target.value; filtres.limite = 300; charger(); };
  zone.onclick = (e) => {
    if (e.target.closest('[data-action="plus"]')) { filtres.limite = Math.min(filtres.limite * 3, 2000); charger(); }
  };
  await charger();
}
