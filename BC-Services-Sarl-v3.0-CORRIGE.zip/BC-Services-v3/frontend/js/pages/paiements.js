import { api } from '../api.js';
import { montant, echapper, dateFr } from '../utils.js';
import { peut } from '../session.js';
import { essayer, notifier } from '../ui.js';

export async function afficher(zone) {
  const liste = await api.paiements();
  let recherche = '';

  zone.innerHTML = `
    <div class="barre"><h2>Paiements</h2><input id="recherche" class="recherche" placeholder="Rechercher (facture, client, mode…)"></div>
    <div class="tableau"><table>
      <thead><tr><th>Date</th><th>Facture</th><th>Client</th><th>Mode</th><th>Référence</th><th class="n">Montant</th><th>Enregistré par</th><th></th></tr></thead>
      <tbody id="lignes"></tbody>
    </table></div>
    <p class="pied-tableau" id="total"></p>`;

  const corps = zone.querySelector('#lignes');
  function dessiner() {
    const q = recherche.toLowerCase();
    const filtres = liste.filter((p) => `${p.numero} ${p.client_nom} ${p.mode} ${p.reference}`.toLowerCase().includes(q));
    corps.innerHTML = filtres.map((p) => `
      <tr>
        <td>${dateFr(p.date_paiement)}</td><td><b>${echapper(p.numero)}</b></td><td>${echapper(p.client_nom)}</td>
        <td>${echapper(p.mode)}</td><td>${echapper(p.reference)}</td><td class="n">${montant(p.montant)}</td><td>${echapper(p.utilisateur)}</td>
        <td class="actions">${peut('paiements.supprimer') ? `<button class="btn alt sm" data-action="supprimer" data-id="${p.id}">Supprimer</button>` : ''}</td>
      </tr>`).join('') || '<tr><td colspan="8" class="vide">Aucun paiement.</td></tr>';
    zone.querySelector('#total').textContent = filtres.length ? `${filtres.length} paiement(s) · total ${montant(filtres.reduce((s, p) => s + p.montant, 0))}` : '';
  }
  dessiner();
  zone.querySelector('#recherche').oninput = (e) => { recherche = e.target.value; dessiner(); };

  zone.onclick = (e) => {
    const bouton = e.target.closest('[data-action="supprimer"]');
    if (!bouton) return;
    if (!confirm('Supprimer ce paiement ? La facture redeviendra impayée (ou partiellement payée).')) return;
    essayer(async () => {
      await api.supprimerPaiement(bouton.dataset.id);
      notifier('Paiement supprimé.');
      await afficher(zone);
    });
  };
}
