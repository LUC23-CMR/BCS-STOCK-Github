import { api } from '../api.js';
import { montant, echapper, aujourdhui, dateFr, dateHeureFr, badgeFacture, badgeTranche } from '../utils.js';
import { peut } from '../session.js';
import { parametres } from '../parametres.js';
import { imprimerDocument } from '../impression.js';
import { ouvrir, fermer, essayer, notifier } from '../ui.js';
import { ouvrirEditeurDocument } from './editeur-document.js';

const FILTRES = [
  ['tous', 'Toutes'], ['brouillons', 'Brouillons'], ['apayer', 'À payer'],
  ['retard', 'En retard'], ['payees', 'Payées'], ['annulees', 'Annulées'],
];
const CORRESPOND = {
  tous: () => true,
  brouillons: (f) => f.statut === 'brouillon',
  apayer: (f) => f.statut === 'validée' && f.paiement !== 'payée',
  retard: (f) => f.en_retard,
  payees: (f) => f.statut === 'validée' && f.paiement === 'payée',
  annulees: (f) => f.statut === 'annulée',
};

export async function afficher(zone, options = {}) {
  const factures = await api.factures();
  let filtre = options.filtre || 'tous';
  let recherche = '';
  const rafraichir = () => afficher(zone, { filtre });

  zone.innerHTML = `
    <div class="barre">
      <h2>Factures</h2>
      <input id="recherche" class="recherche" placeholder="Rechercher (n°, client)…">
      ${peut('factures.creer') ? '<button class="btn" data-action="nouvelle">Nouvelle facture</button>' : ''}
    </div>
    <div class="filtres" id="filtres"></div>
    <div class="tableau"><table>
      <thead><tr><th>N°</th><th>Date</th><th>Client</th><th>Échéance</th><th class="n">Total TTC</th><th class="n">Reste dû</th><th>Statut</th></tr></thead>
      <tbody id="lignes"></tbody>
    </table></div>`;

  const corps = zone.querySelector('#lignes');
  function dessiner() {
    zone.querySelector('#filtres').innerHTML = FILTRES.map(([code, nom]) =>
      `<button class="filtre ${code === filtre ? 'actif' : ''}" data-filtre="${code}">${nom}<span class="n">${factures.filter(CORRESPOND[code]).length}</span></button>`).join('');
    const q = recherche.toLowerCase();
    const filtrees = factures.filter(CORRESPOND[filtre]).filter((f) => `${f.numero} ${f.client_nom}`.toLowerCase().includes(q));
    corps.innerHTML = filtrees.map((f) => `
      <tr class="cliquable" data-action="voir" data-id="${f.id}">
        <td><b>${f.numero ? echapper(f.numero) : '<span class="aide-champ">Brouillon</span>'}</b></td>
        <td>${dateFr(f.date_facture)}</td><td>${echapper(f.client_nom)}</td>
        <td>${f.statut === 'validée' ? dateFr(f.date_echeance) : ''}</td>
        <td class="n">${montant(f.total_ttc)}</td>
        <td class="n">${f.statut === 'validée' && f.reste > 0 ? montant(f.reste) : ''}</td>
        <td>${badgeFacture(f)}</td>
      </tr>`).join('') || '<tr><td colspan="7" class="vide">Aucune facture dans cette vue.</td></tr>';
  }
  dessiner();

  zone.querySelector('#recherche').oninput = (e) => { recherche = e.target.value; dessiner(); };
  zone.onclick = (e) => {
    const chip = e.target.closest('[data-filtre]');
    if (chip) { filtre = chip.dataset.filtre; return dessiner(); }
    const cible = e.target.closest('[data-action]');
    if (!cible) return;
    if (cible.dataset.action === 'nouvelle') return ouvrirEditeur(rafraichir);
    if (cible.dataset.action === 'voir') return ouvrirVue(cible.dataset.id, rafraichir);
  };
}

function feuille(f) {
  const tampon = f.statut === 'brouillon' ? ['brouillon', 'Brouillon']
    : f.statut === 'annulée' ? ['annulee', 'Annulée']
    : f.paiement === 'payée' ? ['payee', 'Payée']
    : f.paiement === 'partielle' ? ['partielle', 'Partiellement payée'] : null;
  const c = f.client || {};

  const meta = `
    <div class="doc-meta">
      ${f.numero ? `<div class="doc-meta-item"><span class="doc-meta-label">N°</span><span class="doc-meta-valeur">${echapper(f.numero)}</span></div>` : ''}
      <div class="doc-meta-item"><span class="doc-meta-label">Date</span><span class="doc-meta-valeur">${dateFr(f.date_facture)}</span></div>
      ${f.date_echeance ? `<div class="doc-meta-item"><span class="doc-meta-label">Échéance</span><span class="doc-meta-valeur">${dateFr(f.date_echeance)}</span></div>` : ''}
      ${f.mode_paiement ? `<div class="doc-meta-item"><span class="doc-meta-label">Paiement</span><span class="doc-meta-valeur">${echapper(f.mode_paiement)}</span></div>` : ''}
      ${f.conditions != null && f.conditions !== '' ? `<div class="doc-meta-item"><span class="doc-meta-label">Délai</span><span class="doc-meta-valeur">${f.conditions} jour(s)</span></div>` : ''}
    </div>`;

  const tranchesHtml = f.tranches?.length ? `
    <p class="doc-section-titre">Échéancier de paiement</p>
    <table class="doc-table">
      <thead><tr><th>Tranche</th><th>Échéance</th><th class="n">Montant</th>${f.statut === 'validée' ? '<th class="n">Payé</th><th class="n">Reste</th><th>Situation</th>' : ''}</tr></thead>
      <tbody>${f.tranches.map((t) => `
        <tr><td>${echapper(t.libelle)} <span style="color:#888;font-size:11px">(${t.pourcentage} %)</span></td>
            <td>${dateFr(t.date_echeance)}</td><td class="n">${montant(t.montant)}</td>
            ${f.statut === 'validée' ? `<td class="n">${montant(t.paye)}</td><td class="n">${montant(t.reste)}</td><td>${badgeTranche(t)}</td>` : ''}
        </tr>`).join('')}
      </tbody>
    </table>` : '';

  const paiementsHtml = f.paiements?.length ? `
    <p class="doc-section-titre">Paiements reçus</p>
    <div style="font-size:12.5px;margin-bottom:12px">${f.paiements.map((p) =>
      `${dateFr(p.date_paiement)} — <b>${montant(p.montant)}</b> (${echapper(p.mode)}${p.reference ? ', réf. ' + echapper(p.reference) : ''})`
    ).join('<br>')}</div>` : '';

  return `
    <div id="facture-imprimable" class="doc-pro">
      <div class="doc-bande-haute"></div>
      <div class="doc-entete">
        <div class="doc-emetteur">
          <img class="doc-logo" src="img/logo.jpg" alt="${echapper(parametres.nom)}">
          <div class="doc-emetteur-texte">
            <div class="doc-raison-sociale">${echapper(parametres.nom)}</div>
            ${parametres.adresse ? `<div class="doc-ligne">${echapper(parametres.adresse)}</div>` : ''}
            ${parametres.telephone ? `<div class="doc-ligne">Tél. : ${echapper(parametres.telephone)}</div>` : ''}
            ${parametres.email ? `<div class="doc-ligne">Email : ${echapper(parametres.email)}</div>` : ''}
            ${parametres.identifiants ? `<div class="doc-ligne identifiants">${echapper(parametres.identifiants)}</div>` : ''}
          </div>
        </div>
        <div class="doc-titre-bloc">
          ${tampon ? `<span class="tampon ${tampon[0]}">${tampon[1]}</span>` : ''}
          <h3 class="doc-titre">Facture</h3>
          ${meta}
        </div>
      </div>
      <div class="doc-parties">
        <div class="doc-bloc-client">
          <div class="doc-bloc-titre">Facturé à</div>
          <div class="doc-client-nom">${echapper(c.nom)}</div>
          ${c.type_client === 'VIP' ? '<div class="doc-badge-vip">Client VIP</div>' : ''}
          ${c.adresse ? `<div class="doc-ligne">${echapper(c.adresse)}</div>` : ''}
          ${c.telephone ? `<div class="doc-ligne">Tél. : ${echapper(c.telephone)}</div>` : ''}
          ${c.email ? `<div class="doc-ligne">${echapper(c.email)}</div>` : ''}
        </div>
      </div>
      <table class="doc-table">
        <thead><tr><th>Désignation</th><th class="n">Qté</th><th class="n">P.U. HT</th><th class="n">Total HT</th></tr></thead>
        <tbody>${(f.lignes || []).map((l) => `
          <tr><td>${echapper(l.designation)}</td><td class="n">${l.quantite}</td>
              <td class="n">${montant(l.prix_unitaire)}</td><td class="n">${montant(l.quantite * l.prix_unitaire)}</td></tr>`).join('')}
        </tbody>
      </table>
      <div class="doc-totaux">
        <div class="doc-total-ligne"><span>Total HT</span><span>${montant(f.total_ht)}</span></div>
        <div class="doc-total-ligne"><span>TVA ${f.tva} %</span><span>${montant(f.total_tva)}</span></div>
        <div class="doc-total-ligne doc-ttc"><span>Total TTC</span><span>${montant(f.total_ttc)}</span></div>
        ${f.statut === 'validée' && f.paye > 0 ? `
          <div class="doc-total-ligne"><span>Déjà payé</span><span>${montant(f.paye)}</span></div>
          <div class="doc-total-ligne doc-reste"><span>Reste à payer</span><span>${montant(f.reste)}</span></div>` : ''}
      </div>
      ${tranchesHtml}
      ${paiementsHtml}
      ${parametres.mentionBancaire ? `<div class="doc-mention-bancaire">${echapper(parametres.mentionBancaire)}</div>` : ''}
      <div class="doc-signatures">
        <div class="doc-sig"><div class="doc-sig-titre">${echapper(parametres.nom)}</div><div class="doc-sig-zone">Cachet et signature</div></div>
        <div class="doc-sig"><div class="doc-sig-titre">Client</div><div class="doc-sig-zone">Bon pour accord</div></div>
      </div>
      <div class="doc-pied">
        <div class="doc-pied-bande"></div>
        <div class="doc-pied-texte">${[parametres.nom, parametres.adresse, parametres.telephone, parametres.email, parametres.identifiants].filter(Boolean).map(echapper).join(' · ')}</div>
        <div class="doc-pied-merci">Merci de votre confiance</div>
      </div>
    </div>`;
}

function lignesPourEditeur(f) {
  const lignes = f.lignes.filter((l) => l.produit_id > 0).map((l) => ({ produit_id: l.produit_id, quantite: l.quantite, prix_unitaire: l.prix_unitaire }));
  const perdues = f.lignes.length - lignes.length;
  if (perdues > 0) alert(`${perdues} ligne(s) n'ont pas été reprises : l'article n'existe plus dans le catalogue.`);
  return lignes;
}

export async function ouvrirVue(id, apres) {
  await essayer(async () => {
    const f = await api.facture(id);
    const brouillon = f.statut === 'brouillon';
    const validee = f.statut === 'validée';
    const boutons = [];
    if (brouillon && peut('factures.valider')) boutons.push('<button class="btn vert" data-action="valider">Valider</button>');
    if (validee && f.reste > 0 && peut('paiements.enregistrer')) boutons.push('<button class="btn" data-action="payer">Enregistrer un paiement</button>');
    if (brouillon && peut('factures.creer')) boutons.push('<button class="btn alt" data-action="modifier">Modifier</button>');
    if (peut('factures.creer')) boutons.push('<button class="btn alt" data-action="dupliquer">Dupliquer</button>');
    boutons.push('<button class="btn alt" data-action="imprimer">Imprimer / PDF</button>');
    if (validee && peut('factures.annuler')) boutons.push('<button class="btn danger" data-action="annuler">Annuler la facture</button>');
    if (brouillon && peut('factures.supprimer')) boutons.push('<button class="btn danger" data-action="supprimer">Supprimer</button>');

    const revenir = async () => { await apres?.(); return ouvrirVue(id, apres); };
    const pourcentage = f.total_ttc > 0 ? Math.min(100, Math.round((f.paye / f.total_ttc) * 100)) : 100;
    const progression = validee ? `
      <div class="progression">
        <div class="progression-texte"><b>${montant(f.paye)}</b> payés sur <b>${montant(f.total_ttc)}</b> (${pourcentage} %) · reste à payer : <b>${montant(f.reste)}</b>${f.nb_tranches > 1 ? ` · ${f.tranches_payees}/${f.nb_tranches} tranches soldées` : ''}${f.en_retard ? ` · <span class="negatif">en retard : ${montant(f.montant_en_retard)}</span>` : ''}</div>
        <div class="barre-progression"><span style="width:${pourcentage}%"></span></div>
      </div>` : '';

    ouvrir(f.numero || `Brouillon #${f.id}`, `
      <div class="actions-facture">${boutons.join('')} <span style="margin-left:auto">${badgeFacture(f)}</span></div>
      ${progression}
      ${feuille(f)}
      <div class="sous-section">
        <h4>Historique</h4>
        <ul class="historique">${f.historique.map((h) =>
          `<li>${dateHeureFr(h.date_heure)} — <b>${echapper(h.utilisateur)}</b> : ${echapper(h.action)}${h.detail ? ' (' + echapper(h.detail) + ')' : ''}</li>`).join('') || '<li>—</li>'}</ul>
        ${f.paiements.length && peut('paiements.supprimer') ? `<h4>Paiements</h4>
          <div class="tableau"><table style="min-width:0"><tbody>${f.paiements.map((p) => `
            <tr><td>${dateFr(p.date_paiement)}</td><td>${echapper(p.mode)}</td><td>${echapper(p.reference)}</td><td class="n">${montant(p.montant)}</td>
            <td class="actions"><button class="btn alt sm" data-action="supprimer-paiement" data-id="${p.id}">Supprimer</button></td></tr>`).join('')}</tbody></table></div>` : ''}
      </div>`, {
      actions: {
        valider() {
          essayer(async () => {
            await api.validerFacture(f.id);
            notifier('Facture validée.');
            await revenir();
          });
        },
        payer: () => ouvrirPaiement(f, apres),
        modifier: () => ouvrirEditeur(apres, { client_id: f.client_id, date_facture: f.date_facture, tva: f.tva, conditions: f.conditions, lignes: lignesPourEditeur(f), tranches: f.tranches }, f.id),
        dupliquer: () => ouvrirEditeur(apres, { client_id: f.client_id, tva: f.tva, conditions: f.conditions, lignes: lignesPourEditeur(f), tranches: f.tranches }),
        imprimer: () => imprimerDocument(document.querySelector('.doc-titre')?.textContent || 'Document'),
        annuler() {
          if (!confirm(`Annuler la facture ${f.numero} ? Les articles seront remis en stock.`)) return;
          essayer(async () => {
            await api.annulerFacture(f.id);
            notifier('Facture annulée.');
            await revenir();
          });
        },
        supprimer() {
          if (!confirm('Supprimer ce brouillon ?')) return;
          essayer(async () => {
            await api.supprimerFacture(f.id);
            fermer();
            notifier('Brouillon supprimé.');
            await apres?.();
          });
        },
        'supprimer-paiement'(bouton) {
          if (!confirm('Supprimer ce paiement ?')) return;
          essayer(async () => {
            await api.supprimerPaiement(bouton.dataset.id);
            notifier('Paiement supprimé.');
            await revenir();
          });
        },
      },
    });
  });
}

function ouvrirPaiement(f, apres) {
  const pas = parametres.decimales > 0 ? (1 / 10 ** parametres.decimales).toFixed(parametres.decimales) : '1';
  const tranche = f.prochaine_tranche;
  const proposition = tranche ? tranche.reste : f.reste;

  ouvrir(`Paiement — ${f.numero}`, `
    <div class="fenetre-contenu">
      <p>Total : <b>${montant(f.total_ttc)}</b> · Déjà payé : <b>${montant(f.paye)}</b> · Reste dû : <b>${montant(f.reste)}</b></p>
      ${tranche ? `<p class="info-tranche">Prochaine tranche : <b>${echapper(tranche.libelle)}</b> — reste <b>${montant(tranche.reste)}</b>, échéance le ${dateFr(tranche.date_echeance)}${tranche.en_retard ? ' <span class="negatif">(en retard)</span>' : ''}</p>` : ''}
      <div class="grille">
        <label>Montant reçu <input type="number" id="pa-montant" min="0" step="${pas}" value="${proposition}"></label>
        <label>Date <input type="date" id="pa-date" value="${aujourdhui()}"></label>
        <label>Mode de paiement
          <select id="pa-mode">${parametres.modesPaiement.map((m) => `<option>${echapper(m)}</option>`).join('')}</select>
        </label>
        <label>Référence <input id="pa-reference" placeholder="n° de chèque, de transaction… (facultatif)"></label>
      </div>
      <div class="modeles-tranches">
        ${tranche ? `<button class="btn alt sm" data-action="montant-tranche">Solder la tranche (${montant(tranche.reste)})</button>` : ''}
        <button class="btn alt sm" data-action="montant-solde">Solder la facture (${montant(f.reste)})</button>
      </div>
    </div>
    <div class="fenetre-pied">
      <button class="btn alt" data-action="retour">Retour</button>
      <button class="btn vert" data-action="enregistrer">Enregistrer le paiement</button>
    </div>`, {
    actions: {
      retour: () => ouvrirVue(f.id, apres),
      'montant-tranche': () => { document.getElementById('pa-montant').value = proposition; },
      'montant-solde': () => { document.getElementById('pa-montant').value = f.reste; },
      enregistrer() {
        essayer(async () => {
          await api.enregistrerPaiement(f.id, {
            montant: document.getElementById('pa-montant').value, date_paiement: document.getElementById('pa-date').value,
            mode: document.getElementById('pa-mode').value, reference: document.getElementById('pa-reference').value,
          });
          notifier('Paiement enregistré.');
          await apres?.();
          await ouvrirVue(f.id, apres);
        });
      },
    },
  });
}

const libelleDelai = (j) => (j === 0 ? 'Paiement immédiat' : `${j} jours`);

export async function ouvrirEditeur(apres, depart = {}, idExistant = null) {
  const [clients, produits] = await Promise.all([api.clients(), api.produits()]);
  if (!clients.length) return alert('Créez d\'abord un client (menu Clients).');
  if (!produits.length) return alert('Ajoutez d\'abord des articles (menu Articles).');

  const delai = depart.conditions ?? parametres.conditionsParDefaut;
  const delais = [...new Set([...(parametres.conditionsPaiement || [0, 15, 30, 45, 60]), delai])].sort((a, b) => a - b);
  const modes = ['Espèces', 'Virement', 'Chèque', 'Mobile Money', 'Carte bancaire', 'Autre'];
  const modeDepart = depart.mode_paiement || modes[0];
  const echeanceLibre = depart.date_echeance || '';
  const majoration = Number(parametres.majorationVip) || 10;

  function appliquerPrixVip(lignes, clientId) {
    const client = clients.find((c) => c.id === clientId);
    if (!client || client.type_client !== 'VIP') return lignes;
    const coef = 1 + majoration / 100;
    return lignes.map((l) => {
      const p = produits.find((x) => x.id === l.produit_id);
      if (!p) return l;
      return { ...l, prix_unitaire: Math.round(p.prix_unitaire * coef) };
    });
  }

  async function enregistrer(b, valider) {
    const typeChoisi = b.extra.type_client || 'Standard';
    const client = clients.find((c) => c.id === b.client_id);
    if (client && client.type_client !== typeChoisi && peut('clients.modifier')) {
      await api.modifierClient(client.id, {
        nom: client.nom, telephone: client.telephone, email: client.email, adresse: client.adresse,
        type_client: typeChoisi,
      });
      client.type_client = typeChoisi;
    }
    const envoi = {
      client_id: b.client_id, date_facture: b.date, tva: b.tva, conditions: b.extra.conditions,
      lignes: b.lignes, tranches: b.tranches, valider,
      mode_paiement: b.extra.mode_paiement, date_echeance: b.extra.date_echeance,
    };
    const facture = idExistant ? await api.modifierFacture(idExistant, envoi) : await api.creerFacture(envoi);
    notifier(valider ? 'Facture validée.' : 'Brouillon enregistré.');
    await apres?.();
    ouvrirVue(facture.id, apres);
  }

  const clientDepart = clients.find((c) => c.id === (depart.client_id || clients[0].id));
  const typeDepart = clientDepart?.type_client || 'Standard';

  const lignesInitiales = depart.lignes && depart.lignes.length
    ? depart.lignes
    : appliquerPrixVip([{ produit_id: produits[0].id, quantite: 1, prix_unitaire: produits[0].prix_unitaire }], depart.client_id || clients[0].id);

  ouvrirEditeurDocument({
    titre: idExistant ? 'Modifier le brouillon' : 'Nouvelle facture',
    clients, produits,
    depart: {
      client_id: depart.client_id, date: depart.date_facture, tva: depart.tva,
      lignes: lignesInitiales, tranches: depart.tranches,
      extra: { conditions: delai, mode_paiement: modeDepart, date_echeance: echeanceLibre, type_client: typeDepart },
    },
    libelleDate: 'Date',
    libelleDelaiTranche: 'Échéance (jours après la facture)',
    extraHtml: (b) => {
      const type = b.extra.type_client || 'Standard';
      return `
        <label>Type de client (Standard / VIP)
          <select id="x-type-client">
            <option value="Standard" ${type === 'Standard' ? 'selected' : ''}>Standard</option>
            <option value="VIP" ${type === 'VIP' ? 'selected' : ''}>VIP (+${majoration} % sur les prix)</option>
          </select>
          <span class="aide-champ">Vous désignez vous-même si ce client est Standard ou VIP pour cette facture.</span>
        </label>
        ${b.tranches.length ? '' : `<label>Délai de paiement (jours)
          <select id="x-conditions">${delais.map((j) => `<option value="${j}" ${j === b.extra.conditions ? 'selected' : ''}>${libelleDelai(j)}</option>`).join('')}</select>
        </label>`}
        <label>Échéance de paiement (date libre)
          <input type="date" id="x-echeance" value="${b.extra.date_echeance || ''}">
          <span class="aide-champ">Vous fixez vous-même la date d'échéance.</span>
        </label>
        <label>Moyen de paiement
          <select id="x-mode">${modes.map((m) => `<option value="${m}" ${m === b.extra.mode_paiement ? 'selected' : ''}>${m}</option>`).join('')}</select>
        </label>
        ${type === 'VIP' ? `<div class="info-tranche">Client <b>VIP</b> — majoration : +${majoration} %. Ajustez les prix unitaires si besoin.</div>` : ''}`;
    },
    lireExtra: (b) => {
      const choix = document.getElementById('x-conditions');
      if (choix) b.extra.conditions = Number(choix.value) || 0;
      b.extra.mode_paiement = document.getElementById('x-mode')?.value || '';
      b.extra.date_echeance = document.getElementById('x-echeance')?.value || '';
      b.extra.type_client = document.getElementById('x-type-client')?.value || 'Standard';
    },
    aide: 'Un brouillon n\'a pas de numéro et ne touche pas au stock. Désignez le client Standard ou VIP vous-même.',
    boutons: [
      { action: 'enregistrer', libelle: 'Enregistrer le brouillon', classe: 'alt', enregistrer: (b) => enregistrer(b, false) },
      ...(peut('factures.valider') ? [{ action: 'enregistrer-valider', libelle: 'Enregistrer et valider', classe: 'vert', enregistrer: (b) => enregistrer(b, true) }] : []),
    ],
    reouvrir: (b) => ouvrirEditeur(apres, {
      client_id: b.client_id, date_facture: b.date, tva: b.tva, conditions: b.extra.conditions,
      lignes: b.lignes, tranches: b.tranches, mode_paiement: b.extra.mode_paiement, date_echeance: b.extra.date_echeance,
    }, idExistant),
  });
}
