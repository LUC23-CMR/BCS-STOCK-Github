import { api } from '../api.js';
import { montant, echapper } from '../utils.js';
import { peut } from '../session.js';
import { essayer, notifier } from '../ui.js';
import { formulaireClient } from './formulaire-client.js';
import { ouvrirEditeur } from './factures.js';

export async function afficher(zone) {
  const clients = await api.clients();
  let recherche = '';

  zone.innerHTML = `
    <div class="barre">
      <h2>Clients</h2>
      <input id="recherche" class="recherche" placeholder="Rechercher un client…">
      ${peut('clients.modifier') ? '<button class="btn" data-action="nouveau">Nouveau client</button>' : ''}
    </div>
    <div class="tableau"><table>
      <thead><tr><th>Nom</th><th>Type</th><th>Téléphone</th><th>Email</th><th>Adresse</th><th class="n">Factures</th><th class="n">Facturé TTC</th><th class="n">Reste à payer</th><th></th></tr></thead>
      <tbody id="lignes-clients"></tbody>
    </table></div>`;

  const corps = zone.querySelector('#lignes-clients');
  function dessinerLignes() {
    const q = recherche.toLowerCase();
    const filtres = clients.filter((c) => (c.nom + ' ' + c.telephone + ' ' + c.email + ' ' + (c.type_client || '')).toLowerCase().includes(q));
    corps.innerHTML = filtres.map((c) => `
      <tr>
        <td><b>${echapper(c.nom)}</b></td>
        <td>${c.type_client === 'VIP' ? '<span class="badge vip">VIP</span>' : '<span class="badge">Standard</span>'}</td>
        <td>${echapper(c.telephone)}</td><td>${echapper(c.email)}</td><td>${echapper(c.adresse)}</td>
        <td class="n">${c.nb_factures}</td><td class="n">${montant(c.total_facture)}</td>
        <td class="n">${c.reste_du > 0 ? `<span class="negatif">${montant(c.reste_du)}</span>` : '—'}</td>
        <td class="actions">
          ${peut('factures.creer') ? `<button class="btn sm" data-action="facturer" data-id="${c.id}">Nouvelle facture</button>` : ''}
          ${peut('clients.modifier') ? `<button class="btn alt sm" data-action="modifier" data-id="${c.id}">Modifier</button>` : ''}
          ${peut('clients.supprimer') ? `<button class="btn alt sm" data-action="supprimer" data-id="${c.id}">Supprimer</button>` : ''}
        </td>
      </tr>`).join('') || '<tr><td colspan="9" class="vide">Aucun client trouvé.</td></tr>';
  }
  dessinerLignes();

  zone.querySelector('#recherche').oninput = (e) => { recherche = e.target.value; dessinerLignes(); };

  zone.onclick = (e) => {
    const bouton = e.target.closest('[data-action]');
    if (!bouton) return;
    const rafraichir = () => afficher(zone);
    const client = clients.find((c) => c.id === Number(bouton.dataset.id));

    switch (bouton.dataset.action) {
      case 'nouveau':
        return formulaireClient(null, rafraichir);
      case 'modifier':
        return formulaireClient(client, rafraichir);
      case 'facturer':
        return ouvrirEditeur(rafraichir, { client_id: client.id });
      case 'supprimer':
        if (!confirm(`Supprimer le client « ${client.nom} » ?`)) return;
        return essayer(async () => {
          await api.supprimerClient(client.id);
          notifier('Client supprimé.');
          await rafraichir();
        });
    }
  };
}
