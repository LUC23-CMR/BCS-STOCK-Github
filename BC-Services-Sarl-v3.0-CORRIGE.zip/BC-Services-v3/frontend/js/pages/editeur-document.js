import { montant, echapper, aujourdhui, calculerTotaux, repartirTranches } from '../utils.js';
import { peut } from '../session.js';
import { parametres } from '../parametres.js';
import { ouvrir, remplacerCorps, essayer } from '../ui.js';
import { formulaireClient } from './formulaire-client.js';

const MODELES = [
  { nom: '50 % / 50 %', tranches: [['Acompte à la commande', 50, 0], ['Solde à la fin', 50, 30]] },
  { nom: '30 % / 40 % / 30 %', tranches: [['Acompte à la commande', 30, 0], ['Livraison du matériel', 40, 15], ['Solde à la fin', 30, 30]] },
  { nom: '70 % / 30 %', tranches: [['Acompte à la commande', 70, 0], ['Solde à la fin', 30, 30]] },
];
const depuisModele = (m) => m.tranches.map(([libelle, pourcentage, delai_jours]) => ({ libelle, pourcentage, delai_jours }));

export function ouvrirEditeurDocument(config) {
  const { clients, produits } = config;
  const depart = config.depart || {};
  const nouvelleLigne = (p) => ({ produit_id: p.id, quantite: 1, prix_unitaire: p.prix_unitaire });

  const brouillon = {
    client_id: clients.some((c) => c.id === depart.client_id) ? depart.client_id : clients[0].id,
    date: depart.date || aujourdhui(),
    tva: depart.tva ?? parametres.tvaParDefaut,
    lignes: depart.lignes && depart.lignes.length ? depart.lignes : [nouvelleLigne(produits[0])],
    extra: { ...(depart.extra || {}) },
    tranches: (depart.tranches || []).map((t) => ({ libelle: t.libelle, pourcentage: t.pourcentage, delai_jours: t.delai_jours })),
  };

  const choixArticles = (idChoisi) => produits.map((p) => `
    <option value="${p.id}" ${p.id === idChoisi ? 'selected' : ''}>
      ${echapper(p.designation)}${p.type === 'produit' ? ` (stock ${p.stock})` : ' (service)'}
    </option>`).join('');

  function optionsClients(filtre) {
    const q = filtre.trim().toLowerCase();
    const trouves = q ? clients.filter((c) => (c.nom + ' ' + c.telephone).toLowerCase().includes(q)) : clients;
    if (!trouves.length) return '<option value="">Aucun client trouvé</option>';
    const choisi = trouves.some((c) => c.id === brouillon.client_id) ? brouillon.client_id : trouves[0].id;
    return trouves.map((c) => `<option value="${c.id}" ${c.id === choisi ? 'selected' : ''}>${echapper(c.nom)}${c.telephone ? ' · ' + echapper(c.telephone) : ''}</option>`).join('');
  }

  function totauxHtml() {
    const t = calculerTotaux(brouillon.lignes, brouillon.tva);
    return `<div><span>Total HT</span><span>${montant(t.ht)}</span></div>
            <div><span>TVA</span><span>${montant(t.tva)}</span></div>
            <div class="ttc"><span>Total TTC</span><span>${montant(t.ttc)}</span></div>`;
  }

  function texteTotalTranches() {
    const total = Math.round(brouillon.tranches.reduce((s, t) => s + (Number(t.pourcentage) || 0), 0) * 100) / 100;
    return total === 100 ? '<span class="positif">Total : 100 %</span>' : `<span class="negatif">Total : ${total} % (doit faire 100 %)</span>`;
  }

  function tranchesHtml() {
    const actif = brouillon.tranches.length > 0;
    const montants = repartirTranches(calculerTotaux(brouillon.lignes, brouillon.tva).ttc, brouillon.tranches);
    return `
      <label class="interrupteur"><input type="checkbox" data-champ="tranches-actif" ${actif ? 'checked' : ''}> Le client paie en plusieurs fois (par tranches)</label>
      ${actif ? `
        <div class="modeles-tranches">Modèles : ${MODELES.map((m, i) => `<button class="btn alt sm" data-action="tranche-modele" data-i="${i}">${m.nom}</button>`).join('')}</div>
        <div class="tranche-ligne entete"><span>Libellé</span><span>%</span><span>${config.libelleDelaiTranche || 'Délai (jours)'}</span><span>Montant TTC</span><span></span></div>
        ${brouillon.tranches.map((t, k) => `
          <div class="tranche-ligne">
            <input data-champ="tr-libelle" data-k="${k}" value="${echapper(t.libelle)}" placeholder="Tranche ${k + 1}">
            <input type="number" min="0" max="100" step="any" data-champ="tr-pct" data-k="${k}" value="${t.pourcentage}" aria-label="Pourcentage">
            <input type="number" min="0" step="1" data-champ="tr-delai" data-k="${k}" value="${t.delai_jours}" aria-label="Délai en jours">
            <span class="montant-tranche" data-montant="${k}">${montant(montants[k].montant)}</span>
            <button class="btn alt sm" data-action="tranche-retirer" data-k="${k}" aria-label="Retirer la tranche">✕</button>
          </div>`).join('')}
        <div class="tranche-pied"><button class="btn alt sm" data-action="tranche-ajouter">Ajouter une tranche</button><span id="tr-total">${texteTotalTranches()}</span></div>` : ''}`;
  }

  function contenu() {
    return `
      <div class="fenetre-contenu">
        <div class="grille">
          <label>Client
            <input id="f-client-recherche" placeholder="Rechercher un client…" autocomplete="off">
            <select id="f-client">${optionsClients('')}</select>
            ${peut('clients.modifier') ? '<button class="btn alt sm" style="margin-top:6px" data-action="nouveau-client">+ Nouveau client</button>' : ''}
          </label>
          <label>${config.libelleDate || 'Date'} <input type="date" id="f-date" value="${brouillon.date}"></label>
          ${config.extraHtml ? config.extraHtml(brouillon) : ''}
          <label>TVA (%) <input type="number" id="f-tva" min="0" value="${brouillon.tva}" data-champ="tva"></label>
        </div>

        <p style="margin:16px 0 0;font-weight:800">Lignes</p>
        ${brouillon.lignes.map((l, k) => `
          <div class="ligne-facture">
            <select data-champ="produit" data-k="${k}">${choixArticles(l.produit_id)}</select>
            <input type="number" min="1" value="${l.quantite}" data-champ="quantite" data-k="${k}" aria-label="Quantité">
            <input type="number" min="0" step="any" value="${l.prix_unitaire}" data-champ="prix" data-k="${k}" aria-label="Prix unitaire">
            <button class="btn alt sm" data-action="retirer" data-k="${k}" aria-label="Retirer la ligne">✕</button>
          </div>`).join('')}
        <button class="btn alt sm" style="margin-top:8px" data-action="ajouter">Ajouter une ligne</button>

        <div class="totaux" id="f-totaux">${totauxHtml()}</div>
        <div class="tranches" id="f-tranches">${tranchesHtml()}</div>
        ${config.apresTotauxHtml ? config.apresTotauxHtml(brouillon) : ''}
        ${config.aide ? `<p class="aide-champ">${config.aide}</p>` : ''}
      </div>
      <div class="fenetre-pied">
        <button class="btn alt" data-action="fermer">Annuler</button>
        ${config.boutons.map((b) => `<button class="btn ${b.classe || ''}" data-action="${b.action}">${b.libelle}</button>`).join('')}
      </div>`;
  }

  function lireEntete() {
    brouillon.client_id = Number(document.getElementById('f-client').value) || brouillon.client_id;
    brouillon.date = document.getElementById('f-date').value;
    brouillon.tva = Number(document.getElementById('f-tva').value) || 0;
    if (config.lireExtra) config.lireExtra(brouillon);
  }
  const dessiner = () => remplacerCorps(contenu());
  const majTranches = () => {
    const montants = repartirTranches(calculerTotaux(brouillon.lignes, brouillon.tva).ttc, brouillon.tranches);
    for (const cellule of document.querySelectorAll('.montant-tranche')) cellule.textContent = montant(montants[Number(cellule.dataset.montant)].montant);
    const total = document.getElementById('tr-total');
    if (total) total.innerHTML = texteTotalTranches();
  };
  const majTotaux = () => { document.getElementById('f-totaux').innerHTML = totauxHtml(); majTranches(); };

  const actions = {
    'nouveau-client'() {
      lireEntete();
      formulaireClient(null, (nouveau) => config.reouvrir({ ...brouillon, client_id: nouveau.id }));
    },
    ajouter() { lireEntete(); brouillon.lignes.push(nouvelleLigne(produits[0])); dessiner(); },
    retirer(bouton) { lireEntete(); brouillon.lignes.splice(Number(bouton.dataset.k), 1); dessiner(); },
    'tranche-modele'(bouton) { lireEntete(); brouillon.tranches = depuisModele(MODELES[Number(bouton.dataset.i)]); dessiner(); },
    'tranche-ajouter'() {
      lireEntete();
      const deja = brouillon.tranches.reduce((s, t) => s + (Number(t.pourcentage) || 0), 0);
      const dernierDelai = brouillon.tranches.length ? Number(brouillon.tranches[brouillon.tranches.length - 1].delai_jours) || 0 : 0;
      brouillon.tranches.push({ libelle: '', pourcentage: Math.max(0, Math.round((100 - deja) * 100) / 100), delai_jours: dernierDelai + 15 });
      dessiner();
    },
    'tranche-retirer'(bouton) { lireEntete(); brouillon.tranches.splice(Number(bouton.dataset.k), 1); dessiner(); },
  };
  for (const b of config.boutons) {
    actions[b.action] = () => { lireEntete(); essayer(() => b.enregistrer(brouillon)); };
  }

  ouvrir(config.titre, contenu(), {
    actions,
    surSaisie(e) {
      if (e.target.id !== 'f-client-recherche') return;
      const liste = document.getElementById('f-client');
      liste.innerHTML = optionsClients(e.target.value);
      brouillon.client_id = Number(liste.value) || brouillon.client_id;
    },
    surChangement(e) {
      const champ = e.target.dataset.champ;
      const k = Number(e.target.dataset.k);
      if (champ === 'produit') {
        lireEntete();
        brouillon.lignes[k] = { ...nouvelleLigne(produits.find((p) => p.id === Number(e.target.value))), quantite: brouillon.lignes[k].quantite };
        dessiner();
      } else if (champ === 'quantite') {
        brouillon.lignes[k].quantite = Math.max(1, parseInt(e.target.value) || 1);
        majTotaux();
      } else if (champ === 'prix') {
        brouillon.lignes[k].prix_unitaire = Math.max(0, Number(e.target.value) || 0);
        majTotaux();
      } else if (champ === 'tva') {
        brouillon.tva = Number(e.target.value) || 0;
        majTotaux();
      } else if (champ === 'tranches-actif') {
        lireEntete();
        brouillon.tranches = e.target.checked ? depuisModele(MODELES[0]) : [];
        dessiner();
      } else if (champ === 'tr-libelle') {
        brouillon.tranches[k].libelle = e.target.value;
      } else if (champ === 'tr-pct') {
        brouillon.tranches[k].pourcentage = Math.max(0, Number(e.target.value) || 0);
        majTranches();
      } else if (champ === 'tr-delai') {
        brouillon.tranches[k].delai_jours = Math.max(0, parseInt(e.target.value) || 0);
      }
    },
  });
}
