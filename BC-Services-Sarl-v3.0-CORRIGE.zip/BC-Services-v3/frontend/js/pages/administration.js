import { api } from '../api.js';
import { echapper, dateHeureFr, aujourdhui } from '../utils.js';
import { peut, session } from '../session.js';
import { aller } from '../navigation.js';
import { formulaireUtilisateur } from './utilisateurs.js';

export async function afficher(zone) {
  const gererUtilisateurs = peut('admin.utilisateurs');
  const voirRoles = peut('admin.roles') || gererUtilisateurs;
  const voirJournal = peut('admin.journal');
  const reglages = peut('admin.parametres');

  const [utilisateurs, roles, journal, systeme] = await Promise.all([
    gererUtilisateurs ? api.utilisateurs() : null,
    voirRoles ? api.roles() : null,
    voirJournal ? api.journal({ limite: 8 }) : null,
    reglages ? api.systeme() : null,
  ]);
  const rafraichir = () => afficher(zone);
  let html = `<div class="barre"><h2>Centre d'administration</h2>${gererUtilisateurs ? '<button class="btn" data-action="nouvel-utilisateur">Créer un utilisateur</button>' : ''}</div>`;

  const kpis = [];
  if (utilisateurs) {
    const actifs = utilisateurs.filter((u) => u.actif);
    const aujourd = utilisateurs.filter((u) => (u.derniere_connexion || '').startsWith(aujourdhui()));
    kpis.push(`<div class="kpi cliquable" data-aller="utilisateurs"><b>${actifs.length}</b><span>Utilisateur${actifs.length > 1 ? 's' : ''} actif${actifs.length > 1 ? 's' : ''}${utilisateurs.length > actifs.length ? ` (${utilisateurs.length - actifs.length} désactivé${utilisateurs.length - actifs.length > 1 ? 's' : ''})` : ''}</span></div>`);
    kpis.push(`<div class="kpi"><b>${aujourd.length}</b><span>Connecté${aujourd.length > 1 ? 's' : ''} aujourd'hui</span></div>`);
  }
  if (roles) kpis.push(`<div class="kpi cliquable" data-aller="roles"><b>${roles.length}</b><span>Rôles définis</span></div>`);
  if (kpis.length) html += `<div class="kpis">${kpis.join('')}</div>`;

  html += '<div class="deux-colonnes">';

  if (utilisateurs) {
    html += `<div>
      <h3 class="section">Utilisateurs</h3>
      <div class="tableau"><table style="min-width:0">
        <thead><tr><th>Nom</th><th>Rôle</th><th>Dernière connexion</th></tr></thead>
        <tbody>${utilisateurs.slice(0, 8).map((u) => `
          <tr class="${u.actif ? '' : 'inactif'}">
            <td><b>${echapper(u.nom)}</b>${u.id === session.utilisateur.id ? ' <span class="aide-champ">(vous)</span>' : ''}${u.actif ? '' : ' <span class="badge gris">Désactivé</span>'}</td>
            <td><span class="badge violet">${echapper(u.role)}</span></td>
            <td>${u.derniere_connexion ? dateHeureFr(u.derniere_connexion) : '<span class="aide-champ">jamais</span>'}</td>
          </tr>`).join('')}</tbody></table></div>
      <p class="pied-tableau"><button class="btn alt sm" data-aller="utilisateurs">Gérer tous les utilisateurs</button></p>
    </div>`;
  }

  if (roles) {
    html += `<div>
      <h3 class="section">Rôles et droits</h3>
      <div class="tableau"><table style="min-width:0">
        <thead><tr><th>Rôle</th><th class="n">Utilisateurs</th></tr></thead>
        <tbody>${roles.map((r) => `<tr><td><b>${echapper(r.nom)}</b><br><small class="aide-champ">${echapper(r.description)}</small></td><td class="n">${r.nb_utilisateurs}</td></tr>`).join('')}</tbody></table></div>
      ${peut('admin.roles') ? '<p class="pied-tableau"><button class="btn alt sm" data-aller="roles">Gérer les rôles et les droits</button></p>' : ''}
    </div>`;
  }

  if (journal) {
    html += `<div>
      <h3 class="section">Activité récente</h3>
      <div class="tableau"><table style="min-width:0"><tbody>${journal.entrees.map((e) => `
        <tr><td style="white-space:nowrap">${dateHeureFr(e.date_heure)}</td>
        <td><b>${echapper(e.utilisateur)}</b> — ${echapper(e.action)}${e.objet ? ' · ' + echapper(e.objet) : ''}</td></tr>`).join('') || '<tr><td class="vide">Aucune activité.</td></tr>'}</tbody></table></div>
      <p class="pied-tableau"><button class="btn alt sm" data-aller="journal">Voir tout le journal</button></p>
    </div>`;
  }

  if (systeme) {
    html += `<div>
      <h3 class="section">Entreprise et données</h3>
      <p>Base de données : <b>${echapper(systeme.fichier)}</b><br><span class="aide-champ">${echapper(systeme.chemin)}</span></p>
      <p class="aide-champ">Sauvegardes automatiques chaque jour dans : ${echapper(systeme.dossier_sauvegardes)}</p>
      <p><button class="btn alt sm" data-aller="reglages">Réglages de l'entreprise</button></p>
      <p class="aide-champ">Adresse à donner aux collègues pour se connecter : <b>${echapper(location.origin)}</b></p>
    </div>`;
  }
  html += '</div>';

  zone.innerHTML = html;
  zone.onclick = (e) => {
    const lien = e.target.closest('[data-aller]');
    if (lien) return aller(lien.dataset.aller);
    if (e.target.closest('[data-action="nouvel-utilisateur"]')) formulaireUtilisateur(null, roles, rafraichir);
  };
}
