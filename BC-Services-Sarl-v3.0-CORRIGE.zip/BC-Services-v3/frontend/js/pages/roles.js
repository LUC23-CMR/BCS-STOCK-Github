import { api } from '../api.js';
import { echapper } from '../utils.js';
import { ouvrir, fermer, essayer, notifier } from '../ui.js';

export async function afficher(zone) {
  const [liste, definitions] = await Promise.all([api.roles(), api.permissions()]);
  const nbDroitsTotal = definitions.modules.reduce((n, m) => n + m.permissions.length, 0);
  const rafraichir = () => afficher(zone);

  zone.innerHTML = `
    <div class="barre"><h2>Rôles et droits</h2><button class="btn" data-action="nouveau">Nouveau rôle</button></div>
    <div class="tableau"><table>
      <thead><tr><th>Rôle</th><th>Description</th><th class="n">Utilisateurs</th><th class="n">Droits</th><th></th></tr></thead>
      <tbody>${liste.map((r) => `
        <tr>
          <td><b>${echapper(r.nom)}</b>${r.systeme ? ' <span class="badge gris">Système</span>' : ''}</td>
          <td>${echapper(r.description)}</td>
          <td class="n">${r.nb_utilisateurs}</td><td class="n">${r.permissions.length} / ${nbDroitsTotal}</td>
          <td class="actions">
            <button class="btn alt sm" data-action="modifier" data-id="${r.id}">${r.systeme ? 'Voir' : 'Modifier'}</button>
            <button class="btn alt sm" data-action="dupliquer" data-id="${r.id}">Dupliquer</button>
            ${r.systeme ? '' : `<button class="btn alt sm" data-action="supprimer" data-id="${r.id}">Supprimer</button>`}
          </td>
        </tr>`).join('')}
      </tbody></table></div>
    <p class="pied-tableau">Chaque utilisateur a un rôle. Pour donner un accès particulier à quelqu'un, créez un rôle sur mesure (bouton « Dupliquer » pour partir d'un rôle existant).</p>`;

  zone.onclick = (e) => {
    const bouton = e.target.closest('[data-action]');
    if (!bouton) return;
    const role = liste.find((r) => r.id === Number(bouton.dataset.id));
    switch (bouton.dataset.action) {
      case 'nouveau': return editeur(null, definitions, rafraichir);
      case 'modifier': return editeur(role, definitions, rafraichir);
      case 'dupliquer': return editeur({ ...role, id: null, systeme: false, nom: `${role.nom} (copie)`, nb_utilisateurs: 0 }, definitions, rafraichir, true);
      case 'supprimer':
        if (!confirm(`Supprimer le rôle « ${role.nom} » ?`)) return;
        return essayer(async () => {
          await api.supprimerRole(role.id);
          notifier('Rôle supprimé.');
          await rafraichir();
        });
    }
  };
}

function editeur(role, definitions, apres, estCopie = false) {
  const lectureSeule = !!(role && role.systeme);
  const r = role || { nom: '', description: '', permissions: [] };
  const implique = definitions.implique;

  function avecRequis(codes) {
    const res = new Set(codes);
    for (let change = true; change;) {
      change = false;
      for (const c of [...res]) for (const requis of implique[c] || []) if (!res.has(requis)) { res.add(requis); change = true; }
    }
    return res;
  }
  const cases = () => [...document.querySelectorAll('.case-droit')];

  function synchroniser() {
    const coches = avecRequis(cases().filter((i) => i.checked).map((i) => i.dataset.code));
    const requis = new Set();
    for (const c of coches) for (const dep of implique[c] || []) requis.add(dep);
    for (const i of cases()) {
      i.checked = coches.has(i.dataset.code);
      i.disabled = lectureSeule || requis.has(i.dataset.code);
      i.closest('.droit').classList.toggle('requis', requis.has(i.dataset.code));
    }
  }

  ouvrir(lectureSeule ? `Rôle ${r.nom}` : role && !estCopie ? 'Modifier le rôle' : 'Nouveau rôle', `
    <div class="fenetre-contenu">
      ${lectureSeule ? '<p class="avertissement">Le rôle Administrateur a toujours tous les droits : il ne peut pas être modifié.</p>' : ''}
      <div class="grille">
        <label>Nom du rôle <input id="r-nom" value="${echapper(r.nom)}" ${lectureSeule ? 'disabled' : ''}></label>
        <label>Description <input id="r-description" value="${echapper(r.description)}" ${lectureSeule ? 'disabled' : ''}></label>
      </div>
      ${definitions.modules.map((m) => `
        <div class="module-droits">
          <h4>${echapper(m.nom)}</h4>
          ${m.permissions.map((p) => `
            <label class="droit">
              <input type="checkbox" class="case-droit" data-code="${p.code}" ${r.permissions.includes(p.code) ? 'checked' : ''}>
              <span>${echapper(p.libelle)}${p.aide ? `<small>${echapper(p.aide)}</small>` : ''}</span>
            </label>`).join('')}
        </div>`).join('')}
      <p class="aide-champ">Les droits grisés sont nécessaires aux droits cochés (par exemple, valider une facture suppose de pouvoir la créer et la voir).</p>
    </div>
    ${lectureSeule ? '' : '<div class="fenetre-pied"><button class="btn" data-action="enregistrer">Enregistrer le rôle</button></div>'}`, {
    surChangement(e) { if (e.target.classList.contains('case-droit')) synchroniser(); },
    actions: {
      enregistrer() {
        const donnees = {
          nom: document.getElementById('r-nom').value,
          description: document.getElementById('r-description').value,
          permissions: cases().filter((i) => i.checked).map((i) => i.dataset.code),
        };
        essayer(async () => {
          if (role && !estCopie) await api.modifierRole(role.id, donnees);
          else await api.creerRole(donnees);
          fermer();
          notifier('Rôle enregistré.');
          await apres();
        });
      },
    },
  });
  synchroniser();
}
