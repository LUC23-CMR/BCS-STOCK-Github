import { api } from '../api.js';
import { montant, echapper, dateFr } from '../utils.js';
import { aller } from '../navigation.js';

function court(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(1).replace('.', ',') + ' M';
  if (n >= 1e3) return Math.round(n / 1e3) + ' k';
  return String(Math.round(n));
}

function graphique(mois) {
  const L = 640, H = 210, bas = 30, haut = 22, marge = 12;
  const max = Math.max(...mois.map((m) => m.total), 1);
  const pas = (L - 2 * marge) / mois.length;
  const largeur = pas * 0.58;
  const dernier = mois.length - 1;
  const barres = mois.map((m, i) => {
    const h = (m.total / max) * (H - bas - haut);
    const x = marge + i * pas + (pas - largeur) / 2;
    const y = H - bas - h;
    const [a, mm] = m.mois.split('-').map(Number);
    const nom = new Date(a, mm - 1, 1).toLocaleDateString('fr-FR', { month: 'short' }).replace('.', '');
    return `<rect class="barre-svg ${i === dernier ? 'courant' : ''}" x="${x}" y="${y}" width="${largeur}" height="${Math.max(h, 1)}" rx="2"><title>${nom} ${a} : ${montant(m.total)}</title></rect>
      <text class="valeur" x="${x + largeur / 2}" y="${y - 5}" text-anchor="middle">${m.total ? court(m.total) : ''}</text>
      <text x="${x + largeur / 2}" y="${H - 10}" text-anchor="middle">${nom}</text>`;
  }).join('');
  return `<div class="graphique"><svg viewBox="0 0 ${L} ${H}" role="img" aria-label="Chiffre d'affaires HT par mois">${barres}</svg></div>`;
}

export async function afficher(zone) {
  const d = await api.dashboard();
  let html = '';

  if (d.devis) {
    const v = d.devis;
    html += `
      <div class="barre"><h2>Ventes</h2></div>
      <div class="kpis">
        <div class="kpi cliquable" data-aller="devis" data-filtre="encours"><b>${montant(v.en_cours.montant)}</b><span>Devis en cours (${v.en_cours.nb})</span></div>
        <div class="kpi cliquable" data-aller="devis" data-filtre="acceptes"><b>${montant(v.a_facturer.montant)}</b><span>Acceptés, à facturer (${v.a_facturer.nb})</span></div>
      </div>`;
  }

  if (d.facturation) {
    const f = d.facturation;
    html += `
      <div class="barre"><h2>Facturation</h2></div>
      <div class="kpis">
        <div class="kpi cliquable" data-aller="factures" data-filtre="apayer"><b>${montant(f.a_encaisser.montant)}</b><span>À encaisser (${f.a_encaisser.nb} facture${f.a_encaisser.nb > 1 ? 's' : ''})</span></div>
        <div class="kpi cliquable ${f.en_retard.nb ? 'alerte' : ''}" data-aller="factures" data-filtre="retard"><b>${montant(f.en_retard.montant)}</b><span>En retard (${f.en_retard.nb})</span></div>
        <div class="kpi"><b>${montant(f.encaisse_mois)}</b><span>Encaissé ce mois-ci</span></div>
        <div class="kpi cliquable" data-aller="factures" data-filtre="brouillons"><b>${f.brouillons}</b><span>Brouillon${f.brouillons > 1 ? 's' : ''} à valider</span></div>
      </div>
      <h3 class="section">Chiffre d'affaires HT par mois</h3>
      ${graphique(f.ca_mensuel)}`;
  }

  if (d.inventaire) {
    const i = d.inventaire;
    html += `
      <div class="barre"><h2>Inventaire</h2></div>
      <div class="kpis">
        ${i.valeur_stock !== undefined ? `<div class="kpi"><b>${montant(i.valeur_stock)}</b><span>Valeur du stock</span></div>` : ''}
        <div class="kpi"><b>${i.nb_articles}</b><span>Articles en stock</span></div>
        <div class="kpi cliquable ${i.alertes.length ? 'alerte' : ''}" data-aller="articles" data-filtre="alerte"><b>${i.alertes.length}</b><span>À réapprovisionner</span></div>
      </div>
      <div class="deux-colonnes">
        <div>
          <h3 class="section">Alertes de stock</h3>
          ${i.alertes.length ? `<div class="tableau"><table style="min-width:0">
            <thead><tr><th>Article</th><th class="n">Stock</th><th class="n">Seuil</th></tr></thead>
            <tbody>${i.alertes.map((p) => `<tr><td>${echapper(p.designation)}<br><small class="aide-champ">${echapper(p.reference)}</small></td>
              <td class="n"><span class="negatif">${p.stock}</span></td><td class="n">${p.seuil_alerte}</td></tr>`).join('')}</tbody></table></div>`
            : '<p class="vide">Aucune alerte : tous les stocks sont au-dessus du seuil.</p>'}
        </div>
        ${i.derniers_mouvements ? `<div>
          <h3 class="section">Derniers mouvements</h3>
          ${i.derniers_mouvements.length ? `<div class="tableau"><table style="min-width:0">
            <thead><tr><th>Date</th><th>Article</th><th class="n">Qté</th></tr></thead>
            <tbody>${i.derniers_mouvements.map((m) => `<tr><td>${dateFr(m.date_mouvement)}</td><td>${echapper(m.designation)}<br><small class="aide-champ">${echapper(m.type)}</small></td>
              <td class="n"><span class="${m.quantite > 0 ? 'positif' : 'negatif'}">${m.quantite > 0 ? '+' : ''}${m.quantite}</span></td></tr>`).join('')}</tbody></table></div>`
            : '<p class="vide">Aucun mouvement.</p>'}
        </div>` : ''}
      </div>`;
  }

  zone.innerHTML = html || '<p class="vide">Rien à afficher pour votre rôle.</p>';

  zone.onclick = (e) => {
    const cible = e.target.closest('[data-aller]');
    if (cible) aller(cible.dataset.aller, { filtre: cible.dataset.filtre });
  };
}
