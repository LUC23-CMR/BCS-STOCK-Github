import { api } from '../api.js';
import { montant, echapper, aujourdhui, ajouterJours, dateFr, dateHeureFr, badgeDevis } from '../utils.js';
import { peut } from '../session.js';
import { parametres } from '../parametres.js';
import { imprimerDocument } from '../impression.js';
import { ouvrir, fermer, essayer, notifier } from '../ui.js';
import { ouvrirEditeurDocument } from './editeur-document.js';
import { ouvrirVue as ouvrirFacture } from './factures.js';

const FILTRES = [
  ['tous', 'Tous'], ['encours', 'En cours'], ['acceptes', 'Acceptés'],
  ['refuses', 'Refusés'], ['factures', 'Facturés'], ['expires', 'Expirés'],
];
const CORRESPOND = {
  tous: () => true,
  encours: (d) => (d.statut === 'brouillon' || d.statut === 'envoyé') && !d.expire,
  acceptes: (d) => d.statut === 'accepté',
  refuses: (d) => d.statut === 'refusé',
  factures: (d) => d.statut === 'facturé',
  expires: (d) => d.expire,
};

export async function afficher(zone, options = {}) {
  const liste = await api.devis();
  let filtre = options.filtre || 'tous';
  let recherche = '';
  const rafraichir = () => afficher(zone, { filtre });

  zone.innerHTML = `
    <div class="barre">
      <h2>Devis</h2>
      <input id="recherche" class="recherche" placeholder="Rechercher (n°, client)…">
      ${peut('devis.creer') ? '<button class="btn" data-action="nouveau">Nouveau devis</button>' : ''}
    </div>
    <div class="filtres" id="filtres"></div>
    <div class="tableau"><table>
      <thead><tr><th>N°</th><th>Date</th><th>Client</th><th>Valable jusqu'au</th><th class="n">Total TTC</th><th>Statut</th></tr></thead>
      <tbody id="lignes"></tbody>
    </table></div>`;

  const corps = zone.querySelector('#lignes');
  function dessiner() {
    zone.querySelector('#filtres').innerHTML = FILTRES.map(([code, nom]) =>
      `<button class="filtre ${code === filtre ? 'actif' : ''}" data-filtre="${code}">${nom}<span class="n">${liste.filter(CORRESPOND[code]).length}</span></button>`).join('');
    const q = recherche.toLowerCase();
    const filtres = liste.filter(CORRESPOND[filtre]).filter((d) => `${d.numero} ${d.client_nom}`.toLowerCase().includes(q));
    corps.innerHTML = filtres.map((d) => `
      <tr class="cliquable" data-action="voir" data-id="${d.id}">
        <td><b>${echapper(d.numero)}</b></td><td>${dateFr(d.date_devis)}</td><td>${echapper(d.client_nom)}</td>
        <td>${dateFr(d.date_validite)}</td><td class="n">${montant(d.total_ttc)}</td><td>${badgeDevis(d)}</td>
      </tr>`).join('') || '<tr><td colspan="6" class="vide">Aucun devis dans cette vue.</td></tr>';
  }
  dessiner();

  zone.querySelector('#recherche').oninput = (e) => { recherche = e.target.value; dessiner(); };
  zone.onclick = (e) => {
    const chip = e.target.closest('[data-filtre]');
    if (chip) { filtre = chip.dataset.filtre; return dessiner(); }
    const cible = e.target.closest('[data-action]');
    if (!cible) return;
    if (cible.dataset.action === 'nouveau') return ouvrirEditeur(rafraichir);
    if (cible.dataset.action === 'voir') return ouvrirVue(cible.dataset.id, rafraichir);
  };
}

function feuille(d) {
  const c = d.client || {};
  const tampon = d.expire ? ['annulee', 'Expiré'] : d.statut === 'refusé' ? ['annulee', 'Refusé']
    : d.statut === 'accepté' ? ['payee', 'Accepté'] : d.statut === 'facturé' ? ['payee', 'Facturé'] : null;

  const meta = `
    <div class="doc-meta">
      <div class="doc-meta-item"><span class="doc-meta-label">N°</span><span class="doc-meta-valeur">${echapper(d.numero)}</span></div>
      <div class="doc-meta-item"><span class="doc-meta-label">Date</span><span class="doc-meta-valeur">${dateFr(d.date_devis)}</span></div>
      <div class="doc-meta-item"><span class="doc-meta-label">Valable jusqu'au</span><span class="doc-meta-valeur">${dateFr(d.date_validite)}</span></div>
      ${d.date_echeance ? `<div class="doc-meta-item"><span class="doc-meta-label">Échéance</span><span class="doc-meta-valeur">${dateFr(d.date_echeance)}</span></div>` : ''}
      ${d.mode_paiement ? `<div class="doc-meta-item"><span class="doc-meta-label">Paiement</span><span class="doc-meta-valeur">${echapper(d.mode_paiement)}</span></div>` : ''}
    </div>`;

  const tranchesHtml = d.tranches?.length ? `
    <p class="doc-section-titre">Modalités de paiement</p>
    <table class="doc-table">
      <thead><tr><th>Tranche</th><th class="n">%</th><th class="n">Montant TTC</th><th>Échéance</th></tr></thead>
      <tbody>${d.tranches.map((t) => `
        <tr><td>${echapper(t.libelle)}</td><td class="n">${t.pourcentage} %</td><td class="n">${montant(t.montant)}</td>
        <td>${t.delai_jours === 0 ? 'À la commande' : t.delai_jours + ' jours après'}</td></tr>`).join('')}
      </tbody>
    </table>` : '';

  const refusHtml = d.statut === 'refusé' && d.raison_refus
    ? `<div class="doc-notes" style="border-color:#fca5a5;background:#fef2f2"><b>Raison du refus</b><div class="doc-notes-corps">${echapper(d.raison_refus)}</div></div>`
    : '';

  return `
    <div id="facture-imprimable" class="doc-pro">
      <div class="doc-bande-haute"></div>
      <div class="doc-entete">
        <div class="doc-emetteur">
          <img class="doc-logo" src="img/logo.jpg" alt="${echapper(parametres.nom)}">
          <div class="doc-emetteur-texte">
            <div class="doc-raison-sociale">${echapper(parametres.nom)}</div>
            ${parametres.adresse ? `<div class="doc-ligne">${echapper(parametres.adresse)}</div>` : ''}
            ${parametres.telephone ? `<div class="doc-ligne">Tél. : ${echapper(parametres.telephone)}</div>` : ''}
            ${parametres.email ? `<div class="doc-ligne">Email : ${echapper(parametres.email)}</div>` : ''}
            ${parametres.identifiants ? `<div class="doc-ligne identifiants">${echapper(parametres.identifiants)}</div>` : ''}
          </div>
        </div>
        <div class="doc-titre-bloc">
          ${tampon ? `<span class="tampon ${tampon[0]}">${tampon[1]}</span>` : ''}
          <h3 class="doc-titre">Devis</h3>
          ${meta}
        </div>
      </div>
      <div class="doc-parties">
        <div class="doc-bloc-client">
          <div class="doc-bloc-titre">Client</div>
          <div class="doc-client-nom">${echapper(c.nom)}</div>
          ${c.type_client === 'VIP' ? '<div class="doc-badge-vip">Client VIP</div>' : ''}
          ${c.adresse ? `<div class="doc-ligne">${echapper(c.adresse)}</div>` : ''}
          ${c.telephone ? `<div class="doc-ligne">Tél. : ${echapper(c.telephone)}</div>` : ''}
          ${c.email ? `<div class="doc-ligne">${echapper(c.email)}</div>` : ''}
        </div>
      </div>
      <table class="doc-table">
        <thead><tr><th>Désignation</th><th class="n">Qté</th><th class="n">P.U. HT</th><th class="n">Total HT</th></tr></thead>
        <tbody>${(d.lignes || []).map((l) => `
          <tr><td>${echapper(l.designation)}</td><td class="n">${l.quantite}</td>
              <td class="n">${montant(l.prix_unitaire)}</td><td class="n">${montant(l.quantite * l.prix_unitaire)}</td></tr>`).join('')}
        </tbody>
      </table>
      <div class="doc-totaux">
        <div class="doc-total-ligne"><span>Total HT</span><span>${montant(d.total_ht)}</span></div>
        <div class="doc-total-ligne"><span>TVA ${d.tva} %</span><span>${montant(d.total_tva)}</span></div>
        <div class="doc-total-ligne doc-ttc"><span>Total TTC</span><span>${montant(d.total_ttc)}</span></div>
      </div>
      ${tranchesHtml}
      ${refusHtml}
      ${d.notes ? `<div class="doc-notes"><b>Notes et conditions</b><div class="doc-notes-corps">${echapper(d.notes)}</div></div>` : ''}
      ${parametres.mentionBancaire ? `<div class="doc-mention-bancaire">${echapper(parametres.mentionBancaire)}</div>` : ''}
      <div class="doc-signatures">
        <div class="doc-sig"><div class="doc-sig-titre">${echapper(parametres.nom)}</div><div class="doc-sig-zone">Cachet et signature</div></div>
        <div class="doc-sig"><div class="doc-sig-titre">Client</div><div class="doc-sig-zone">Bon pour accord — date et signature</div></div>
      </div>
      <div class="doc-pied">
        <div class="doc-pied-bande"></div>
        <div class="doc-pied-texte">${[parametres.nom, parametres.adresse, parametres.telephone, parametres.email, parametres.identifiants].filter(Boolean).map(echapper).join(' · ')}</div>
        <div class="doc-pied-merci">Merci de votre confiance</div>
      </div>
    </div>`;
}

function lignesPourEditeur(d) {
  const lignes = d.lignes.filter((l) => l.produit_id > 0).map((l) => ({ produit_id: l.produit_id, quantite: l.quantite, prix_unitaire: l.prix_unitaire }));
  if (lignes.length < d.lignes.length) alert(`${d.lignes.length - lignes.length} ligne(s) n'ont pas été reprises : l'article n'existe plus dans le catalogue.`);
  return lignes;
}

export async function ouvrirVue(id, apres) {
  await essayer(async () => {
    const d = await api.unDevis(id);
    const ouvert = d.statut === 'brouillon' || d.statut === 'envoyé';
    const boutons = [];

    if (peut('devis.creer')) {
      if (d.statut === 'brouillon') boutons.push('<button class="btn" data-action="envoyer">Marquer comme envoyé</button>');
      if (ouvert) boutons.push('<button class="btn vert" data-action="accepter">Accepté par le client</button>');
    }
    if (peut('devis.facturer') && (ouvert || d.statut === 'accepté')) boutons.push('<button class="btn vert" data-action="facturer">Créer la facture</button>');
    if (d.statut === 'facturé' && d.facture && peut('factures.voir')) {
      boutons.push(`<button class="btn" data-action="voir-facture">Voir la facture ${echapper(d.facture.numero || 'brouillon #' + d.facture.id)}</button>`);
    }
    if (peut('devis.creer') && ouvert) boutons.push('<button class="btn alt" data-action="modifier">Modifier</button>');
    if (peut('devis.creer')) boutons.push('<button class="btn alt" data-action="dupliquer">Dupliquer</button>');
    boutons.push('<button class="btn alt" data-action="imprimer">Imprimer / PDF</button>');
    if (peut('devis.creer') && ouvert) boutons.push('<button class="btn danger" data-action="refuser">Refusé</button>');
    if (peut('devis.creer') && (d.statut === 'refusé' || d.statut === 'accepté')) boutons.push('<button class="btn alt" data-action="brouillon">Remettre en brouillon</button>');
    if (peut('devis.supprimer') && d.statut !== 'facturé') boutons.push('<button class="btn danger" data-action="supprimer">Supprimer</button>');

    const revenir = async () => { await apres?.(); return ouvrirVue(id, apres); };
    const statut = (nouveau, message) => () => essayer(async () => {
      await api.statutDevis(d.id, nouveau);
      notifier(message);
      await revenir();
    });
    const depart = { client_id: d.client_id, tva: d.tva, lignes: lignesPourEditeur(d), notes: d.notes, tranches: d.tranches, mode_paiement: d.mode_paiement, date_echeance: d.date_echeance };

    ouvrir(d.numero, `
      <div class="actions-facture">${boutons.join('')} <span style="margin-left:auto">${badgeDevis(d)}</span></div>
      ${feuille(d)}
      ${d.statut === 'refusé' && d.raison_refus ? `<div class="info-tranche" style="margin:12px 0"><b>Raison du refus :</b> ${echapper(d.raison_refus)}</div>` : ''}
      <div class="sous-section">
        <h4>Historique</h4>
        <ul class="historique">${d.historique.map((h) =>
          `<li>${dateHeureFr(h.date_heure)} — <b>${echapper(h.utilisateur)}</b> : ${echapper(h.action)}${h.detail ? ' (' + echapper(h.detail) + ')' : ''}</li>`).join('') || '<li>—</li>'}</ul>
      </div>`, {
      actions: {
        envoyer: statut('envoyé', 'Devis marqué comme envoyé.'),
        accepter: statut('accepté', 'Devis accepté.'),
        refuser() {
          const raison = prompt('Indiquez la raison du refus du devis (obligatoire) :');
          if (raison === null) return;
          if (!String(raison).trim()) { alert('La raison du refus est obligatoire.'); return; }
          essayer(async () => {
            await api.statutDevis(d.id, 'refusé', String(raison).trim());
            notifier('Devis refusé. La raison a été enregistrée.');
            await revenir();
          });
        },
        brouillon: statut('brouillon', 'Devis remis en brouillon.'),
        facturer() {
          if (!confirm(`Créer un brouillon de facture à partir du devis ${d.numero} ?`)) return;
          essayer(async () => {
            const r = await api.facturerDevis(d.id);
            notifier('Brouillon de facture créé : vérifiez-le puis validez-le.');
            await apres?.();
            ouvrirFacture(r.facture.id);
          });
        },
        'voir-facture': () => ouvrirFacture(d.facture.id),
        modifier: () => ouvrirEditeur(apres, { ...depart, date_devis: d.date_devis, date_validite: d.date_validite }, d.id),
        dupliquer: () => ouvrirEditeur(apres, depart),
        imprimer: () => imprimerDocument(document.querySelector('.doc-titre')?.textContent || 'Document'),
        supprimer() {
          if (!confirm(`Supprimer le devis ${d.numero} ?`)) return;
          essayer(async () => {
            await api.supprimerDevis(d.id);
            fermer();
            notifier('Devis supprimé.');
            await apres?.();
          });
        },
      },
    });
  });
}

export async function ouvrirEditeur(apres, depart = {}, idExistant = null) {
  const [clients, produits] = await Promise.all([api.clients(), api.produits()]);
  if (!clients.length) return alert('Créez d\'abord un client (menu Clients).');
  if (!produits.length) return alert('Ajoutez d\'abord des articles (menu Articles).');

  const date = depart.date_devis || aujourdhui();
  const validite = depart.date_validite || ajouterJours(date, parametres.validiteDevis);
  const modes = ['Espèces', 'Virement', 'Chèque', 'Mobile Money', 'Carte bancaire', 'Autre'];
  const modeDepart = depart.mode_paiement || modes[0];
  const echeanceDepart = depart.date_echeance || '';
  const majoration = Number(parametres.majorationVip) || 10;

  // Appliquer majoration VIP si client VIP et nouvelles lignes
  function appliquerPrixVip(lignes, clientId) {
    const client = clients.find((c) => c.id === clientId);
    if (!client || client.type_client !== 'VIP') return lignes;
    const coef = 1 + majoration / 100;
    return lignes.map((l) => {
      const p = produits.find((x) => x.id === l.produit_id);
      if (!p) return l;
      return { ...l, prix_unitaire: Math.round(p.prix_unitaire * coef) };
    });
  }

  async function enregistrer(b) {
    const typeChoisi = b.extra.type_client || 'Standard';
    const client = clients.find((c) => c.id === b.client_id);
    if (client && client.type_client !== typeChoisi && peut('clients.modifier')) {
      await api.modifierClient(client.id, {
        nom: client.nom, telephone: client.telephone, email: client.email, adresse: client.adresse,
        type_client: typeChoisi,
      });
      client.type_client = typeChoisi;
    }
    const envoi = {
      client_id: b.client_id, date_devis: b.date, date_validite: b.extra.validite, tva: b.tva,
      notes: b.extra.notes, lignes: b.lignes, tranches: b.tranches,
      mode_paiement: b.extra.mode_paiement, date_echeance: b.extra.date_echeance,
    };
    const devis = idExistant ? await api.modifierDevis(idExistant, envoi) : await api.creerDevis(envoi);
    notifier('Devis enregistré.');
    await apres?.();
    ouvrirVue(devis.id, apres);
  }

  const clientDepart = clients.find((c) => c.id === (depart.client_id || clients[0].id));
  const typeDepart = clientDepart?.type_client || 'Standard';

  const lignesInitiales = depart.lignes && depart.lignes.length
    ? depart.lignes
    : appliquerPrixVip([{ produit_id: produits[0].id, quantite: 1, prix_unitaire: produits[0].prix_unitaire }], depart.client_id || clients[0].id);

  ouvrirEditeurDocument({
    titre: idExistant ? 'Modifier le devis' : 'Nouveau devis',
    clients, produits,
    depart: {
      client_id: depart.client_id, date, tva: depart.tva, lignes: lignesInitiales, tranches: depart.tranches,
      extra: { validite, notes: depart.notes || '', mode_paiement: modeDepart, date_echeance: echeanceDepart, type_client: typeDepart },
    },
    libelleDate: 'Date du devis',
    libelleDelaiTranche: 'Échéance (jours après la commande)',
    extraHtml: (b) => {
      const type = b.extra.type_client || 'Standard';
      return `
        <label>Type de client (Standard / VIP)
          <select id="x-type-client">
            <option value="Standard" ${type === 'Standard' ? 'selected' : ''}>Standard</option>
            <option value="VIP" ${type === 'VIP' ? 'selected' : ''}>VIP (+${majoration} % sur les prix)</option>
          </select>
          <span class="aide-champ">Vous désignez vous-même si ce client est Standard ou VIP pour ce devis.</span>
        </label>
        <label>Valable jusqu'au <input type="date" id="x-validite" value="${b.extra.validite}"></label>
        <label>Échéance de paiement (libre)
          <input type="date" id="x-echeance" value="${b.extra.date_echeance || ''}">
          <span class="aide-champ">Vous fixez vous-même la date d'échéance.</span>
        </label>
        <label>Moyen de paiement
          <select id="x-mode">${modes.map((m) => `<option value="${m}" ${m === b.extra.mode_paiement ? 'selected' : ''}>${m}</option>`).join('')}</select>
        </label>
        ${type === 'VIP' ? `<div class="info-tranche">Client <b>VIP</b> — majoration : +${majoration} %. Ajustez les prix unitaires si besoin.</div>` : ''}`;
    },
    lireExtra: (b) => {
      b.extra.validite = document.getElementById('x-validite').value;
      b.extra.notes = document.getElementById('x-notes').value;
      b.extra.mode_paiement = document.getElementById('x-mode').value;
      b.extra.date_echeance = document.getElementById('x-echeance').value;
      b.extra.type_client = document.getElementById('x-type-client')?.value || 'Standard';
    },
    apresTotauxHtml: (b) => `<label style="margin-top:14px">Notes et conditions
      <textarea id="x-notes" placeholder="Délai de livraison, conditions de paiement, remarques…">${echapper(b.extra.notes)}</textarea></label>`,
    aide: 'Un devis ne touche pas au stock. Désignez le client Standard ou VIP vous-même.',
    boutons: [{ action: 'enregistrer', libelle: 'Enregistrer le devis', classe: '', enregistrer }],
    reouvrir: (b) => ouvrirEditeur(apres, {
      client_id: b.client_id, date_devis: b.date, date_validite: b.extra.validite, tva: b.tva,
      lignes: b.lignes, notes: b.extra.notes, tranches: b.tranches,
      mode_paiement: b.extra.mode_paiement, date_echeance: b.extra.date_echeance,
    }, idExistant),
  });
}
