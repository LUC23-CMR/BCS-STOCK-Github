import { api } from '../api.js';
import { echapper, dateHeureFr } from '../utils.js';
import { session } from '../session.js';
import { ouvrir, fermer, essayer, notifier } from '../ui.js';

export async function afficher(zone) {
  const [liste, roles] = await Promise.all([api.utilisateurs(), api.roles()]);
  const rafraichir = () => afficher(zone);

  zone.innerHTML = `
    <div class="barre"><h2>Utilisateurs</h2><button class="btn" data-action="nouveau">Nouvel utilisateur</button></div>
    <div class="tableau"><table>
      <thead><tr><th>Nom</th><th>Identifiant</th><th>Rôle</th><th>Dernière connexion</th><th>Statut</th><th></th></tr></thead>
      <tbody>${liste.map((u) => {
        const moi = u.id === session.utilisateur.id;
        return `<tr class="${u.actif ? '' : 'inactif'}">
          <td><b>${echapper(u.nom)}</b>${moi ? ' <span class="aide-champ">(vous)</span>' : ''}</td>
          <td>${echapper(u.identifiant)}</td>
          <td>${u.role_valide ? `<span class="badge violet">${echapper(u.role)}</span>` : `<span class="badge rouge" title="Ce rôle n'existe plus : aucun droit">${echapper(u.role)} ?</span>`}</td>
          <td>${u.derniere_connexion ? dateHeureFr(u.derniere_connexion) : '<span class="aide-champ">jamais</span>'}${u.doit_changer_mdp ? ' <span class="badge orange">Mot de passe temporaire</span>' : ''}</td>
          <td>${u.actif ? '<span class="badge vert">Actif</span>' : '<span class="badge gris">Désactivé</span>'}</td>
          <td class="actions">
            <button class="btn alt sm" data-action="modifier" data-id="${u.id}">Modifier</button>
            <button class="btn alt sm" data-action="motdepasse" data-id="${u.id}">Nouveau mot de passe</button>
            ${moi ? '' : `<button class="btn alt sm" data-action="activation" data-id="${u.id}" data-actif="${u.actif ? 0 : 1}">${u.actif ? 'Désactiver' : 'Réactiver'}</button>`}
          </td></tr>`;
      }).join('')}</tbody>
    </table></div>
    <p class="pied-tableau">Un utilisateur désactivé ne peut plus se connecter (et est déconnecté immédiatement). On ne supprime pas les comptes : le journal garde l'historique de leurs actions.</p>`;

  zone.onclick = (e) => {
    const bouton = e.target.closest('[data-action]');
    if (!bouton) return;
    const u = liste.find((x) => x.id === Number(bouton.dataset.id));
    switch (bouton.dataset.action) {
      case 'nouveau': return formulaireUtilisateur(null, roles, rafraichir);
      case 'modifier': return formulaireUtilisateur(u, roles, rafraichir);
      case 'activation':
        return essayer(async () => {
          const actif = bouton.dataset.actif === '1';
          if (!actif && !confirm(`Désactiver ${u.nom} ? Cette personne sera déconnectée immédiatement.`)) return;
          await api.activerUtilisateur(u.id, actif);
          notifier(actif ? 'Compte réactivé.' : 'Compte désactivé.');
          await rafraichir();
        });
      case 'motdepasse':
        if (!confirm(`Générer un nouveau mot de passe temporaire pour ${u.nom} ? L'ancien ne fonctionnera plus.`)) return;
        return essayer(async () => {
          const r = await api.reinitialiserMotDePasse(u.id);
          montrerIdentifiants(u.nom, u.identifiant, r.mot_de_passe_temporaire, rafraichir);
        });
    }
  };
}

export function formulaireUtilisateur(utilisateur, roles, apres) {
  const u = utilisateur || { nom: '', identifiant: '', role: roles.find((r) => !r.systeme)?.nom || roles[0].nom };
  const description = (nom) => echapper((roles.find((r) => r.nom === nom) || {}).description || '');

  ouvrir(utilisateur ? 'Modifier l\'utilisateur' : 'Nouvel utilisateur', `
    <div class="fenetre-contenu">
      <div class="grille">
        <label>Nom complet <input id="u-nom" value="${echapper(u.nom)}"></label>
        <label>Identifiant de connexion <input id="u-identifiant" value="${echapper(u.identifiant)}" autocomplete="off"></label>
        <label>Rôle
          <select id="u-role">${roles.map((r) => `<option ${r.nom === u.role ? 'selected' : ''}>${echapper(r.nom)}</option>`).join('')}</select>
          <span class="aide-champ" id="u-role-aide">${description(u.role)}</span>
        </label>
      </div>
      ${utilisateur ? '' : '<p class="aide-champ" style="margin-top:14px">Un mot de passe temporaire sera généré. L\'utilisateur devra le remplacer à sa première connexion.</p>'}
    </div>
    <div class="fenetre-pied"><button class="btn" data-action="enregistrer">${utilisateur ? 'Enregistrer' : 'Créer le compte'}</button></div>`, {
    surChangement(e) {
      if (e.target.id === 'u-role') document.getElementById('u-role-aide').innerHTML = description(e.target.value);
    },
    actions: {
      enregistrer() {
        const donnees = {
          nom: document.getElementById('u-nom').value,
          identifiant: document.getElementById('u-identifiant').value,
          role: document.getElementById('u-role').value,
        };
        essayer(async () => {
          if (utilisateur) {
            await api.modifierUtilisateur(utilisateur.id, donnees);
            fermer();
            notifier('Utilisateur modifié.');
            await apres();
          } else {
            const r = await api.creerUtilisateur(donnees);
            await apres();
            montrerIdentifiants(r.utilisateur.nom, r.utilisateur.identifiant, r.mot_de_passe_temporaire, apres);
          }
        });
      },
    },
  });
}

export function montrerIdentifiants(nom, identifiant, motDePasse, apres) {
  ouvrir('Identifiants de connexion', `
    <div class="fenetre-contenu">
      <p>Communiquez ces informations à <b>${echapper(nom)}</b> :</p>
      <div class="identifiants">
        <span class="aide-champ">Adresse de l'application</span><code>${echapper(location.origin)}</code>
        <span class="aide-champ">Identifiant</span><code>${echapper(identifiant)}</code>
        <span class="aide-champ">Mot de passe temporaire</span><code>${echapper(motDePasse)}</code>
      </div>
      <p class="avertissement">Notez-le maintenant : ce mot de passe <b>ne sera plus affiché</b>. À la première connexion, la personne devra en choisir un nouveau.</p>
    </div>
    <div class="fenetre-pied">
      <button class="btn alt" data-action="copier">Copier</button>
      <button class="btn" data-action="termine">Terminé</button>
    </div>`, {
    actions: {
      async copier() {
        const texte = `Application : ${location.origin}\nIdentifiant : ${identifiant}\nMot de passe temporaire : ${motDePasse}`;
        try { await navigator.clipboard.writeText(texte); notifier('Copié.'); }
        catch { notifier('Copie impossible : recopiez les informations à la main.', 'erreur'); }
      },
      termine() { fermer(); apres?.(); },
    },
  });
}
