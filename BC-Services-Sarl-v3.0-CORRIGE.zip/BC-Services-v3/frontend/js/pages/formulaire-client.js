import { api } from '../api.js';
import { echapper } from '../utils.js';
import { ouvrir, fermer, essayer, notifier } from '../ui.js';

export function formulaireClient(client, apres) {
  const c = client || { nom: '', type_client: 'Standard', telephone: '', email: '', adresse: '' };
  const type = c.type_client || 'Standard';

  ouvrir(client ? 'Modifier le client' : 'Nouveau client', `
    <div class="fenetre-contenu"><div class="grille">
      <label>Nom / société <input id="c-nom" value="${echapper(c.nom)}"></label>
      <label>Type de client
        <select id="c-type">
          <option value="Standard" ${type === 'Standard' ? 'selected' : ''}>Standard</option>
          <option value="VIP" ${type === 'VIP' ? 'selected' : ''}>VIP</option>
        </select>
      </label>
      <label>Téléphone <input id="c-tel" value="${echapper(c.telephone)}"></label>
      <label>Email <input id="c-email" value="${echapper(c.email)}"></label>
      <label>Adresse <input id="c-adresse" value="${echapper(c.adresse)}"></label>
    </div></div>
    <div class="fenetre-pied"><button class="btn" data-action="enregistrer">Enregistrer</button></div>`,
  {
    actions: {
      enregistrer() {
        const donnees = {
          nom: document.getElementById('c-nom').value,
          type_client: document.getElementById('c-type').value,
          telephone: document.getElementById('c-tel').value,
          email: document.getElementById('c-email').value,
          adresse: document.getElementById('c-adresse').value,
        };
        essayer(async () => {
          const enregistre = client ? await api.modifierClient(client.id, donnees) : await api.creerClient(donnees);
          fermer();
          notifier('Client enregistré.');
          await apres(enregistre);
        });
      },
    },
  });
}
