import { api } from '../api.js';
import { echapper } from '../utils.js';
import { session } from '../session.js';
import { ouvrir, fermer, essayer, notifier } from '../ui.js';

export function ouvrirCompte(deconnexion) {
  const u = session.utilisateur;
  ouvrir('Mon compte', `
    <div class="fenetre-contenu">
      <p><b>${echapper(u.nom)}</b><br><span class="aide-champ">Identifiant : ${echapper(u.identifiant)} · Rôle : ${echapper(u.role)}</span></p>
      <h4 style="margin:18px 0 4px;color:var(--violet)">Changer mon mot de passe</h4>
      <div class="grille">
        <label>Mot de passe actuel <input type="password" id="mdp-ancien" autocomplete="current-password"></label>
        <label>Nouveau mot de passe <input type="password" id="mdp-nouveau" autocomplete="new-password"></label>
        <label>Confirmation <input type="password" id="mdp-confirmation" autocomplete="new-password"></label>
      </div>
      <span class="aide-champ">8 caractères minimum.</span>
    </div>
    <div class="fenetre-pied">
      <button class="btn danger" data-action="deconnexion">Se déconnecter</button>
      <button class="btn" data-action="changer">Changer le mot de passe</button>
    </div>`, {
    actions: {
      deconnexion() { fermer(); deconnexion(); },
      changer() {
        const [ancien, nouveau, confirmation] = ['mdp-ancien', 'mdp-nouveau', 'mdp-confirmation'].map((id) => document.getElementById(id).value);
        essayer(async () => {
          if (nouveau !== confirmation) throw new Error('Les deux mots de passe ne sont pas identiques.');
          await api.changerMotDePasse(ancien, nouveau);
          fermer();
          notifier('Mot de passe modifié.');
        });
      },
    },
  });
}
