import { api } from '../api.js';
import { montant, echapper } from '../utils.js';
import { peut } from '../session.js';
import { aller } from '../navigation.js';

/**
 * Comparateur de prix fournisseurs / marges
 * Affiche les articles par catégorie avec coût, prix de vente, marge et fournisseur.
 * Permet de repérer rapidement les meilleurs prix d'achat et les marges.
 */
export async function afficher(zone) {
  const [produits, categories] = await Promise.all([
    api.produits(),
    api.categories(),
  ]);
  const voirCouts = peut('articles.couts');

  let recherche = '';
  let categorie = '';
  let tri = 'marge'; // marge | cout_asc | prix_asc | nom

  zone.innerHTML = `
    <div class="barre">
      <h2>Comparateur de prix</h2>
      <input id="recherche" class="recherche" placeholder="Rechercher un article…">
      <select id="filtre-categorie">
        <option value="">Toutes les catégories</option>
        ${categories.map((c) => `<option value="${echapper(c.nom)}">${echapper(c.nom)}</option>`).join('')}
      </select>
      <select id="tri">
        <option value="marge">Tri : meilleure marge</option>
        <option value="cout_asc">Coût d'achat ↑ (moins cher)</option>
        <option value="prix_asc">Prix de vente ↑</option>
        <option value="nom">Nom</option>
      </select>
      ${peut('articles.voir') ? '<button class="btn alt" data-action="articles">Voir l\'inventaire</button>' : ''}
    </div>
    <p class="aide-champ" style="margin:0 0 12px">
      Comparez les coûts d'achat et les marges par fournisseur et catégorie.
      Utile pour préparer un devis global ou choisir le meilleur prix d'achat.
    </p>
    <div id="resume" class="info-tranche" style="margin-bottom:14px"></div>
    <div class="tableau"><table>
      <thead><tr>
        <th>Catégorie</th>
        <th>Réf.</th>
        <th>Désignation</th>
        <th>Fournisseur</th>
        <th class="n">Prix vente HT</th>
        ${voirCouts ? '<th class="n">Coût achat</th><th class="n">Marge</th><th class="n">Marge %</th>' : ''}
        <th class="n">Stock</th>
      </tr></thead>
      <tbody id="lignes"></tbody>
    </table></div>`;

  const corps = zone.querySelector('#lignes');
  const resume = zone.querySelector('#resume');
  const selTri = zone.querySelector('#tri');
  const selCat = zone.querySelector('#filtre-categorie');
  const champRecherche = zone.querySelector('#recherche');

  function marge(p) {
    return (p.prix_unitaire || 0) - (p.cout || 0);
  }
  function margePct(p) {
    if (!p.prix_unitaire) return 0;
    return (marge(p) / p.prix_unitaire) * 100;
  }

  function dessiner() {
    let liste = produits.filter((p) => {
      const q = recherche.toLowerCase();
      const matchTexte = !q || (p.designation + p.reference + (p.fournisseur_nom || '') + p.categorie).toLowerCase().includes(q);
      const matchCat = !categorie || p.categorie === categorie;
      return matchTexte && matchCat;
    });

    if (tri === 'marge') liste.sort((a, b) => marge(b) - marge(a));
    else if (tri === 'cout_asc') liste.sort((a, b) => (a.cout || 0) - (b.cout || 0));
    else if (tri === 'prix_asc') liste.sort((a, b) => (a.prix_unitaire || 0) - (b.prix_unitaire || 0));
    else liste.sort((a, b) => a.designation.localeCompare(b.designation, 'fr'));

    // Résumé global
    const avecCout = liste.filter((p) => p.cout != null);
    const totalMarge = avecCout.reduce((s, p) => s + marge(p), 0);
    const meilleur = [...liste].sort((a, b) => marge(b) - marge(a))[0];
    const moinsCherAchat = voirCouts && [...liste].filter((p) => p.cout > 0).sort((a, b) => a.cout - b.cout)[0];

    resume.innerHTML = `
      <b>Comparaison</b> — ${liste.length} article(s)
      ${voirCouts && avecCout.length ? ` · Marge cumulée (unitaire) : <b>${montant(totalMarge)}</b>` : ''}
      ${meilleur ? `<br>Meilleure marge : <b>${echapper(meilleur.designation)}</b>
        ${voirCouts ? ` — ${montant(marge(meilleur))} (${margePct(meilleur).toFixed(0)} %)` : ''}` : ''}
      ${moinsCherAchat ? `<br>Moins cher à l'achat : <b>${echapper(moinsCherAchat.designation)}</b> à ${montant(moinsCherAchat.cout)}
        ${moinsCherAchat.fournisseur_nom ? `(${echapper(moinsCherAchat.fournisseur_nom)})` : ''}` : ''}
    `;

    // Groupement visuel par catégorie
    let derniereCat = null;
    corps.innerHTML = liste.map((p) => {
      const catCell = p.categorie !== derniereCat
        ? `<td rowspan="1" class="cat-cell"><b>${echapper(p.categorie || '—')}</b></td>`
        : `<td class="cat-cell"></td>`;
      derniereCat = p.categorie;

      const m = marge(p);
      const pct = margePct(p);
      const classeMarge = m > 0 ? 'positif' : (m < 0 ? 'negatif' : '');

      return `<tr>
        ${catCell}
        <td>${echapper(p.reference || '')}</td>
        <td>${echapper(p.designation)}</td>
        <td>${echapper(p.fournisseur_nom || '—')}</td>
        <td class="n">${montant(p.prix_unitaire)}</td>
        ${voirCouts ? `
          <td class="n">${p.cout != null ? montant(p.cout) : '—'}</td>
          <td class="n ${classeMarge}">${p.cout != null ? montant(m) : '—'}</td>
          <td class="n ${classeMarge}">${p.cout != null ? pct.toFixed(0) + ' %' : '—'}</td>
        ` : ''}
        <td class="n">${p.type === 'produit' ? p.stock : '—'}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="9" class="vide">Aucun article trouvé.</td></tr>';
  }

  champRecherche.oninput = () => { recherche = champRecherche.value; dessiner(); };
  selCat.onchange = () => { categorie = selCat.value; dessiner(); };
  selTri.onchange = () => { tri = selTri.value; dessiner(); };

  zone.onclick = (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    if (btn.dataset.action === 'articles') aller('articles');
  };

  dessiner();
}
