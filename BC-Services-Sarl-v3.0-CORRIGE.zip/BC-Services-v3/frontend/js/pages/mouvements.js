import { api } from '../api.js';
import { echapper, dateFr } from '../utils.js';
import { peut } from '../session.js';
import { ouvrir, fermer, essayer, notifier } from '../ui.js';

const TYPES = ['Stock initial', 'Réception', 'Livraison', 'Annulation', 'Sortie', 'Inventaire'];

function badgeType(m) {
  const classe = m.type === 'Inventaire' ? 'orange' : m.quantite > 0 ? 'vert' : 'rouge';
  return `<span class="badge ${classe}">${echapper(m.type || 'Mouvement')}</span>`;
}

export async function afficher(zone) {
  const liste = await api.mouvements({ limite: 300 });
  let recherche = '';
  let type = '';
  const rafraichir = () => afficher(zone);

  zone.innerHTML = `
    <div class="barre">
      <h2>Mouvements de stock</h2>
      <input id="recherche" class="recherche" placeholder="Rechercher un article ou un motif…">
      <select id="filtre-type"><option value="">Tous les types</option>${TYPES.map((t) => `<option>${t}</option>`).join('')}</select>
      ${peut('stock.operer') ? `
        <button class="btn" data-op="reception">Réception</button>
        <button class="btn alt" data-op="sortie">Sortie</button>
        <button class="btn alt" data-op="inventaire">Inventaire</button>` : ''}
    </div>
    <div class="tableau"><table>
      <thead><tr><th>Date</th><th>Type</th><th>Article</th><th class="n">Quantité</th><th>Motif</th><th>Fait par</th></tr></thead>
      <tbody id="lignes"></tbody>
    </table></div>
    <p class="pied-tableau">${liste.length >= 300 ? 'Les 300 mouvements les plus récents sont affichés. Utilisez « Exporter en Excel » pour tout l\'historique.' : ''}</p>`;

  const corps = zone.querySelector('#lignes');
  function dessiner() {
    const q = recherche.toLowerCase();
    corps.innerHTML = liste.filter((m) => (!type || m.type === type) && `${m.designation} ${m.motif}`.toLowerCase().includes(q)).map((m) => `
      <tr>
        <td>${dateFr(m.date_mouvement)}</td><td>${badgeType(m)}</td><td>${echapper(m.designation)}</td>
        <td class="n"><span class="${m.quantite > 0 ? 'positif' : 'negatif'}">${m.quantite > 0 ? '+' : ''}${m.quantite}</span> ${echapper(m.unite)}</td>
        <td>${echapper(m.motif)}</td><td>${echapper(m.utilisateur)}</td>
      </tr>`).join('') || '<tr><td colspan="6" class="vide">Aucun mouvement.</td></tr>';
  }
  dessiner();

  zone.querySelector('#recherche').oninput = (e) => { recherche = e.target.value; dessiner(); };
  zone.querySelector('#filtre-type').onchange = (e) => { type = e.target.value; dessiner(); };
  zone.onclick = (e) => {
    const bouton = e.target.closest('[data-op]');
    if (bouton) ouvrirOperation(bouton.dataset.op, null, rafraichir);
  };
}

export async function ouvrirOperation(operation, produitId, apres) {
  const produits = (await api.produits()).filter((p) => p.type === 'produit');
  if (!produits.length) return alert('Aucun article en stock : créez d\'abord un article de type « produit ».');
  const choisi = produits.find((p) => p.id === produitId) || produits[0];

  const titres = { reception: 'Réception de marchandise', sortie: 'Sortie de stock', inventaire: 'Inventaire physique' };
  const selection = `
    <label>Article
      <select id="op-article">${produits.map((p) => `<option value="${p.id}" ${p.id === choisi.id ? 'selected' : ''}>${echapper(p.designation)} (stock : ${p.stock} ${echapper(p.unite)})</option>`).join('')}</select>
    </label>`;

  const champs = {
    reception: `${selection}
      <label>Quantité reçue <input type="number" id="op-quantite" min="1" value="1"></label>
      ${peut('articles.couts') ? '<label>Coût d\'achat unitaire <input type="number" id="op-cout" min="0" placeholder="facultatif"><span class="aide-champ">Si renseigné, le coût de l\'article est recalculé (moyenne pondérée).</span></label>' : ''}
      <label>Fournisseur <input id="op-fournisseur" placeholder="facultatif"></label>
      <label>N° de bon de livraison <input id="op-reference" placeholder="facultatif"></label>`,
    sortie: `${selection}
      <label>Quantité sortie <input type="number" id="op-quantite" min="1" value="1"></label>
      <label>Motif <input id="op-motif" placeholder="casse, perte, usage interne…"></label>`,
    inventaire: `${selection}
      <label>Quantité réellement comptée <input type="number" id="op-reelle" min="0" value="${choisi.stock}"></label>
      <label>Remarque <input id="op-motif" placeholder="facultatif"></label>`,
  };

  const valeur = (id) => (document.getElementById(id) || {}).value;
  ouvrir(titres[operation], `
    <div class="fenetre-contenu"><div class="grille large">${champs[operation]}</div></div>
    <div class="fenetre-pied"><button class="btn" data-action="valider">Valider</button></div>`, {
    surChangement(e) {
      if (operation === 'inventaire' && e.target.id === 'op-article') {
        document.getElementById('op-reelle').value = produits.find((p) => p.id === Number(e.target.value)).stock;
      }
    },
    actions: {
      valider() {
        const produit_id = Number(valeur('op-article'));
        essayer(async () => {
          if (operation === 'reception') {
            await api.reception({ produit_id, quantite: valeur('op-quantite'), cout_unitaire: valeur('op-cout'), fournisseur: valeur('op-fournisseur'), reference: valeur('op-reference') });
          } else if (operation === 'sortie') {
            await api.sortie({ produit_id, quantite: valeur('op-quantite'), motif: valeur('op-motif') });
          } else {
            await api.inventaire({ produit_id, quantite_reelle: valeur('op-reelle'), motif: valeur('op-motif') });
          }
          fermer();
          notifier('Mouvement enregistré.');
          await apres();
        });
      },
    },
  });
}
