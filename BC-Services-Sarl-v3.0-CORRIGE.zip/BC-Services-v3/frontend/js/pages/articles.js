import { api } from '../api.js';
import { montant, echapper } from '../utils.js';
import { peut } from '../session.js';
import { ouvrir, fermer, essayer, notifier } from '../ui.js';
import { ouvrirOperation } from './mouvements.js';
import { aller } from '../navigation.js';

export async function afficher(zone, options = {}) {
  const [produits, categories, fournisseurs] = await Promise.all([
    api.produits(), api.categories(), api.fournisseurs().catch(() => []),
  ]);
  const afficherCouts = peut('articles.couts');
  let recherche = '';
  let categorie = '';
  let stockBas = options.filtre === 'alerte';
  let tri = options.tri || 'nom';
  const rafraichir = () => afficher(zone, { filtre: stockBas ? 'alerte' : '', tri });

  zone.innerHTML = `
    <div class="barre">
      <h2>Articles & inventaire</h2>
      <input id="recherche" class="recherche" placeholder="Rechercher…">
      <select id="filtre-categorie">
        <option value="">Toutes les catégories</option>
        ${categories.map((c) => `<option value="${echapper(c.nom)}">${echapper(c.nom)}</option>`).join('')}
      </select>
      <select id="tri">
        <option value="nom">Tri : nom</option>
        <option value="prix_asc">Prix vente ↑ (moins cher)</option>
        <option value="prix_desc">Prix vente ↓ (plus cher)</option>
        ${afficherCouts ? '<option value="cout_asc">Coût ↑ (moins cher)</option><option value="cout_desc">Coût ↓ (plus cher)</option><option value="marge">Marge ↑</option>' : ''}
        <option value="stock">Stock</option>
      </select>
      ${peut('articles.modifier') ? '<button class="btn" data-action="nouveau">Nouvel article</button>' : ''}
      ${peut('articles.modifier') ? '<button class="btn alt" data-action="fournisseurs">Fournisseurs</button>' : ''}
      <button class="btn alt" data-action="comparateur">Comparateur</button>
    </div>
    <div class="filtres">
      <button class="filtre" data-bas="0">Tous</button>
      <button class="filtre" data-bas="1">Stock bas</button>
    </div>
    <div id="resume-inventaire" class="info-tranche" style="margin-bottom:12px"></div>
    <div class="tableau"><table>
      <thead><tr>
        <th>Réf.</th><th>Désignation</th><th>Catégorie</th><th>Fournisseur</th>
        <th class="n">Prix de vente HT</th>
        ${afficherCouts ? '<th class="n">Coût</th><th class="n">Marge</th>' : ''}
        <th class="n">Stock</th><th class="n">Valeur stock</th><th></th>
      </tr></thead>
      <tbody id="lignes-stock"></tbody>
    </table></div>`;

  const corps = zone.querySelector('#lignes-stock');
  const resume = zone.querySelector('#resume-inventaire');
  zone.querySelector('#tri').value = tri;

  function dessiner() {
    for (const f of zone.querySelectorAll('.filtre')) f.classList.toggle('actif', (f.dataset.bas === '1') === stockBas);
    let filtres = produits.filter((p) =>
      (!categorie || p.categorie === categorie) &&
      (!stockBas || (p.type === 'produit' && p.stock <= p.seuil_alerte)) &&
      (p.designation + p.reference + (p.fournisseur_nom || '')).toLowerCase().includes(recherche.toLowerCase()));

    const marge = (p) => (p.prix_unitaire || 0) - (p.cout || 0);
    if (tri === 'prix_asc') filtres.sort((a, b) => (a.prix_unitaire || 0) - (b.prix_unitaire || 0));
    else if (tri === 'prix_desc') filtres.sort((a, b) => (b.prix_unitaire || 0) - (a.prix_unitaire || 0));
    else if (tri === 'cout_asc') filtres.sort((a, b) => (a.cout || 0) - (b.cout || 0));
    else if (tri === 'cout_desc') filtres.sort((a, b) => (b.cout || 0) - (a.cout || 0));
    else if (tri === 'marge') filtres.sort((a, b) => marge(b) - marge(a));
    else if (tri === 'stock') filtres.sort((a, b) => (b.stock || 0) - (a.stock || 0));
    else filtres.sort((a, b) => a.designation.localeCompare(b.designation, 'fr'));

    const avecStock = filtres.filter((p) => p.type === 'produit');
    const totalValeur = avecStock.reduce((s, p) => s + (p.stock || 0) * (p.cout || p.prix_unitaire || 0), 0);
    const plusCher = [...filtres].sort((a, b) => (b.prix_unitaire || 0) - (a.prix_unitaire || 0))[0];
    const moinsCher = [...filtres].sort((a, b) => (a.prix_unitaire || 0) - (b.prix_unitaire || 0))[0];
    const plusCout = afficherCouts && [...filtres].sort((a, b) => (b.cout || 0) - (a.cout || 0))[0];
    const moinsCout = afficherCouts && [...filtres].sort((a, b) => (a.cout || 0) - (b.cout || 0))[0];

    resume.innerHTML = `
      <b>Inventaire global</b> — ${filtres.length} article(s)
      ${avecStock.length ? ` · Valeur stock (au coût) : <b>${montant(totalValeur)}</b>` : ''}
      ${plusCher ? `<br>Plus cher (vente) : <b>${echapper(plusCher.designation)}</b> à ${montant(plusCher.prix_unitaire)}
        ${plusCher.fournisseur_nom ? `(fournisseur : ${echapper(plusCher.fournisseur_nom)})` : ''}
        ${afficherCouts && plusCher.cout ? ` — coût ${montant(plusCher.cout)}, marge ${montant(marge(plusCher))}` : ''}` : ''}
      ${moinsCher ? `<br>Moins cher (vente) : <b>${echapper(moinsCher.designation)}</b> à ${montant(moinsCher.prix_unitaire)}
        ${moinsCher.fournisseur_nom ? `(fournisseur : ${echapper(moinsCher.fournisseur_nom)})` : ''}
        ${afficherCouts && moinsCher.cout ? ` — coût ${montant(moinsCher.cout)}, marge ${montant(marge(moinsCher))}` : ''}` : ''}
      ${plusCout ? `<br>Coût d'achat le plus élevé : <b>${echapper(plusCout.designation)}</b> à ${montant(plusCout.cout)}
        ${plusCout.fournisseur_nom ? `(chez ${echapper(plusCout.fournisseur_nom)})` : ''}` : ''}
      ${moinsCout ? `<br>Coût d'achat le plus bas : <b>${echapper(moinsCout.designation)}</b> à ${montant(moinsCout.cout)}
        ${moinsCout.fournisseur_nom ? `(chez ${echapper(moinsCout.fournisseur_nom)})` : ''}` : ''}
    `;

    corps.innerHTML = filtres.map((p) => {
      const four = p.fournisseur_nom || (p.fournisseur_id ? `#${p.fournisseur_id}` : '—');
      const val = p.type === 'produit' ? (p.stock || 0) * (p.cout || p.prix_unitaire || 0) : 0;
      return `
      <tr>
        <td>${echapper(p.reference)}</td>
        <td><b>${echapper(p.designation)}</b></td>
        <td>${echapper(p.categorie)}</td>
        <td>${echapper(four)}</td>
        <td class="n">${montant(p.prix_unitaire)}</td>
        ${afficherCouts ? `<td class="n">${p.cout ? montant(p.cout) : '—'}</td>
          <td class="n">${p.cout != null ? montant(marge(p)) : '—'}</td>` : ''}
        <td class="n">${p.type === 'service' ? '<span class="badge gris">Service</span>'
          : `<span class="${p.stock <= p.seuil_alerte ? 'negatif' : 'positif'}">${p.stock}</span> ${echapper(p.unite)}`}</td>
        <td class="n">${p.type === 'produit' ? montant(val) : '—'}</td>
        <td class="actions">
          ${p.type === 'produit' && peut('stock.operer') ? `
            <button class="btn alt sm" data-action="reception" data-id="${p.id}">Réception</button>
            <button class="btn alt sm" data-action="inventaire" data-id="${p.id}">Inventaire</button>` : ''}
          ${peut('articles.modifier') ? `<button class="btn alt sm" data-action="modifier" data-id="${p.id}">Modifier</button>` : ''}
          ${peut('articles.supprimer') ? `<button class="btn alt sm" data-action="supprimer" data-id="${p.id}">Supprimer</button>` : ''}
        </td>
      </tr>`;
    }).join('') || `<tr><td colspan="${afficherCouts ? 10 : 8}" class="vide">Aucun article trouvé.</td></tr>`;
  }
  dessiner();

  zone.querySelector('#recherche').oninput = (e) => { recherche = e.target.value; dessiner(); };
  zone.querySelector('#filtre-categorie').onchange = (e) => { categorie = e.target.value; dessiner(); };
  zone.querySelector('#tri').onchange = (e) => { tri = e.target.value; dessiner(); };

  zone.onclick = (e) => {
    const filtre = e.target.closest('.filtre');
    if (filtre) { stockBas = filtre.dataset.bas === '1'; return dessiner(); }

    const bouton = e.target.closest('[data-action]');
    if (!bouton) return;
    const produit = produits.find((p) => p.id === Number(bouton.dataset.id));

    switch (bouton.dataset.action) {
      case 'nouveau': return formulaire(null, categories, fournisseurs, rafraichir);
      case 'modifier': return formulaire(produit, categories, fournisseurs, rafraichir);
      case 'fournisseurs': return gererFournisseurs(fournisseurs, rafraichir);
      case 'comparateur': return aller('comparateur');
      case 'reception': return ouvrirOperation('reception', produit.id, rafraichir);
      case 'inventaire': return ouvrirOperation('inventaire', produit.id, rafraichir);
      case 'supprimer':
        if (!confirm(`Supprimer l'article « ${produit.designation} » ?\nLes factures déjà créées ne changent pas.`)) return;
        return essayer(async () => {
          await api.supprimerProduit(produit.id);
          notifier('Article supprimé.');
          await rafraichir();
        });
    }
  };
}

function formulaire(produit, categories, fournisseurs, apres) {
  const p = produit || { reference: '', designation: '', categorie: categories[0] ? categories[0].nom : '', type: 'produit', unite: 'pièce', prix_unitaire: 0, cout: 0, stock: 0, seuil_alerte: 0, fournisseur_id: 0 };
  const optionsFour = `<option value="0">— Aucun fournisseur —</option>` +
    (fournisseurs || []).map((f) => `<option value="${f.id}" ${Number(p.fournisseur_id) === f.id ? 'selected' : ''}>${echapper(f.nom)}${f.telephone ? ' — ' + echapper(f.telephone) : ''}</option>`).join('');

  ouvrir(produit ? 'Modifier l\'article' : 'Nouvel article', `
    <div class="fenetre-contenu"><div class="grille">
      <label>Référence <input id="p-ref" value="${echapper(p.reference)}"></label>
      <label>Désignation <input id="p-designation" value="${echapper(p.designation)}"></label>
      <label>Catégorie
        <select id="p-categorie">${categories.map((c) => `<option value="${echapper(c.nom)}" ${c.nom === p.categorie ? 'selected' : ''}>${echapper(c.nom)}</option>`).join('')}</select>
      </label>
      <label>Type
        <select id="p-type">
          <option value="produit" ${p.type === 'produit' ? 'selected' : ''}>Produit (stock suivi)</option>
          <option value="service" ${p.type === 'service' ? 'selected' : ''}>Service / main d'œuvre</option>
        </select>
      </label>
      <label>Unité <input id="p-unite" list="unites" value="${echapper(p.unite)}"></label>
      <datalist id="unites"><option>pièce</option><option>rouleau</option><option>mètre</option><option>kit</option><option>lot</option><option>forfait</option><option>heure</option></datalist>
      <label>Fournisseur
        <select id="p-fournisseur">${optionsFour}</select>
        <span class="aide-champ">Liste des fournisseurs pour comparer les prix d'achat.</span>
      </label>
      <label>Prix de vente HT <input type="number" id="p-prix" min="0" value="${p.prix_unitaire}"></label>
      ${peut('articles.couts') ? `<label>Coût d'achat <input type="number" id="p-cout" min="0" value="${p.cout || 0}"><span class="aide-champ">Permet de comparer et d'expliquer les écarts de prix.</span></label>` : ''}
      ${produit
        ? `<label>Stock actuel <input value="${p.stock}" disabled><span class="aide-champ">Se modifie par une réception, une sortie ou un inventaire.</span></label>`
        : '<label>Stock initial <input type="number" id="p-stock" min="0" value="0"></label>'}
      <label>Seuil d'alerte <input type="number" id="p-seuil" min="0" value="${p.seuil_alerte}"></label>
    </div></div>
    <div class="fenetre-pied"><button class="btn" data-action="enregistrer">Enregistrer</button></div>`,
  {
    actions: {
      enregistrer() {
        const valeur = (id) => (document.getElementById(id) || {}).value;
        const donnees = {
          reference: valeur('p-ref'), designation: valeur('p-designation'), categorie: valeur('p-categorie'),
          type: valeur('p-type'), unite: valeur('p-unite'), prix_unitaire: valeur('p-prix'), seuil_alerte: valeur('p-seuil'),
          fournisseur_id: valeur('p-fournisseur'),
        };
        if (peut('articles.couts')) donnees.cout = valeur('p-cout');
        if (!produit) donnees.stock = valeur('p-stock');
        essayer(async () => {
          if (produit) await api.modifierProduit(produit.id, donnees);
          else await api.creerProduit(donnees);
          fermer();
          notifier('Article enregistré.');
          await apres();
        });
      },
    },
  });
}

function gererFournisseurs(liste, apres) {
  let fournisseurs = [...(liste || [])];

  function dessiner() {
    ouvrir('Fournisseurs', `
      <div class="fenetre-contenu">
        <div class="barre" style="margin-bottom:12px">
          <button class="btn sm" data-action="nouveau-f">Nouveau fournisseur</button>
        </div>
        <div class="tableau"><table>
          <thead><tr><th>Nom</th><th>Téléphone</th><th>Email</th><th>Contact</th><th>Adresse</th><th></th></tr></thead>
          <tbody>
            ${fournisseurs.map((f) => `
              <tr>
                <td><b>${echapper(f.nom)}</b></td>
                <td>${echapper(f.telephone)}</td>
                <td>${echapper(f.email)}</td>
                <td>${echapper(f.contact)}</td>
                <td>${echapper(f.adresse)}</td>
                <td class="actions">
                  <button class="btn alt sm" data-action="mod-f" data-id="${f.id}">Modifier</button>
                  <button class="btn alt sm" data-action="sup-f" data-id="${f.id}">Supprimer</button>
                </td>
              </tr>`).join('') || '<tr><td colspan="6" class="vide">Aucun fournisseur. Ajoutez-en pour lier les articles et comparer les prix.</td></tr>'}
          </tbody>
        </table></div>
      </div>
      <div class="fenetre-pied"><button class="btn alt" data-action="fermer-f">Fermer</button></div>`,
    {
      actions: {
        'fermer-f': () => { fermer(); apres(); },
        'nouveau-f': () => formulaireFournisseur(null, async () => {
          fournisseurs = await api.fournisseurs();
          dessiner();
        }),
        'mod-f'(btn) {
          const f = fournisseurs.find((x) => x.id === Number(btn.dataset.id));
          formulaireFournisseur(f, async () => {
            fournisseurs = await api.fournisseurs();
            dessiner();
          });
        },
        'sup-f'(btn) {
          const f = fournisseurs.find((x) => x.id === Number(btn.dataset.id));
          if (!confirm(`Supprimer le fournisseur « ${f.nom} » ?`)) return;
          essayer(async () => {
            await api.supprimerFournisseur(f.id);
            notifier('Fournisseur supprimé.');
            fournisseurs = await api.fournisseurs();
            dessiner();
          });
        },
      },
    });
  }
  dessiner();
}

function formulaireFournisseur(f, apres) {
  const x = f || { nom: '', telephone: '', email: '', adresse: '', contact: '', notes: '' };
  ouvrir(f ? 'Modifier le fournisseur' : 'Nouveau fournisseur', `
    <div class="fenetre-contenu"><div class="grille">
      <label>Nom / société <input id="f-nom" value="${echapper(x.nom)}"></label>
      <label>Téléphone <input id="f-tel" value="${echapper(x.telephone)}"></label>
      <label>Email <input id="f-email" value="${echapper(x.email)}"></label>
      <label>Personne de contact <input id="f-contact" value="${echapper(x.contact)}"></label>
      <label>Adresse <input id="f-adresse" value="${echapper(x.adresse)}"></label>
      <label>Notes <input id="f-notes" value="${echapper(x.notes)}"></label>
    </div></div>
    <div class="fenetre-pied"><button class="btn" data-action="enreg-f">Enregistrer</button></div>`,
  {
    actions: {
      'enreg-f'() {
        const donnees = {
          nom: document.getElementById('f-nom').value,
          telephone: document.getElementById('f-tel').value,
          email: document.getElementById('f-email').value,
          contact: document.getElementById('f-contact').value,
          adresse: document.getElementById('f-adresse').value,
          notes: document.getElementById('f-notes').value,
        };
        essayer(async () => {
          if (f) await api.modifierFournisseur(f.id, donnees);
          else await api.creerFournisseur(donnees);
          fermer();
          notifier('Fournisseur enregistré.');
          await apres();
        });
      },
    },
  });
}
