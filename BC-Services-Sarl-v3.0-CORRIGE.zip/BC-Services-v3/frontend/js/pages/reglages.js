import { api } from '../api.js';
import { echapper } from '../utils.js';
import { charger as chargerParametres } from '../parametres.js';
import { essayer, notifier } from '../ui.js';

export async function afficher(zone) {
  const [p, categories, systeme] = await Promise.all([api.parametres(), api.categories(), api.systeme()]);
  const rafraichir = () => afficher(zone);
  const champ = (id, libelle, valeur, type = 'text', aide = '') =>
    `<label>${libelle}<input id="${id}" type="${type}" value="${echapper(valeur)}" ${type === 'number' ? 'min="0" step="any"' : ''}>${aide ? `<span class="aide-champ">${aide}</span>` : ''}</label>`;

  zone.innerHTML = `
    <div class="barre"><h2>Réglages</h2><button class="btn" data-action="enregistrer">Enregistrer</button></div>

    <h3 class="section">Entreprise</h3>
    <div class="grille large">
      ${champ('r-nom', 'Nom de l\'entreprise', p.nom)}
      ${champ('r-adresse', 'Adresse', p.adresse)}
      ${champ('r-telephone', 'Téléphone', p.telephone)}
      ${champ('r-email', 'Email', p.email)}
      ${champ('r-identifiants', 'Identifiants (RCCM, NIF…)', p.identifiants)}
      ${champ('r-mention', 'Mention bancaire', p.mentionBancaire, 'text', 'Affichée en bas des factures')}
    </div>

    <h3 class="section">Facturation</h3>
    <div class="grille large">
      ${champ('r-tva', 'TVA par défaut (%)', p.tvaParDefaut, 'number')}
      ${champ('r-devise', 'Devise', p.devise)}
      ${champ('r-decimales', 'Décimales des montants', p.decimales, 'number', '0 pour le FCFA, 2 pour l\'euro')}
      ${champ('r-prefixe', 'Préfixe des factures', p.prefixeFacture, 'text', 'Donne FAC-2026-0001…')}
      ${champ('r-prefixe-devis', 'Préfixe des devis', p.prefixeDevis, 'text', 'Donne DEV-2026-0001…')}
      ${champ('r-prefixe-bl', 'Préfixe des bordereaux de livraison', p.prefixeLivraison || 'BL', 'text', 'Donne BL-2026-0001…')}
      ${champ('r-validite', 'Validité des devis (jours)', p.validiteDevis, 'number')}
      ${champ('r-delai', 'Délai de paiement par défaut (jours)', p.conditionsParDefaut, 'number', '0 = paiement immédiat')}
      ${champ('r-majoration-vip', 'Majoration clients VIP (%)', p.majorationVip ?? 10, 'number', 'Pourcentage ajouté aux prix de vente pour les clients VIP (ex. 10 = +10 %)')}
    </div>

    <h3 class="section">Catégories d'articles</h3>
    <div class="tableau"><table style="min-width:0">
      <tbody>${categories.map((c) => `
        <tr><td>${echapper(c.nom)}</td>
        <td class="actions"><button class="btn alt sm" data-action="renommer" data-id="${c.id}">Renommer</button>
        <button class="btn alt sm" data-action="supprimer-categorie" data-id="${c.id}">Supprimer</button></td></tr>`).join('')}
      </tbody></table></div>
    <div class="barre" style="margin-top:10px"><input id="r-nouvelle-categorie" placeholder="Nouvelle catégorie…"><button class="btn alt" data-action="ajouter-categorie">Ajouter</button></div>

    <h3 class="section">Base de données</h3>
    <p>Fichier Excel : <b>${echapper(systeme.fichier)}</b><br><span class="aide-champ">${echapper(systeme.chemin)}</span><br>
    <span class="aide-champ">Sauvegardes automatiques : ${echapper(systeme.dossier_sauvegardes)}</span></p>
    <p class="aide-champ">Pour changer l'emplacement de la base, l'informaticien modifie <code>configuration.json</code>.</p>
    <p style="margin:14px 0">
      <button class="btn" data-action="reparer">Réparer l'application</button>
      <span class="aide-champ">En cas de bug, base corrompue ou comportement anormal : nettoie les fichiers temporaires, complète la structure et restaure la dernière sauvegarde si besoin.</span>
    </p>
    <p><button class="btn danger" data-action="arreter">Arrêter l'application</button> <span class="aide-champ">Déconnecte tous les utilisateurs. Pour la relancer : double-clic sur BC Services.</span></p>`;

  const valeur = (id) => document.getElementById(id).value;
  zone.onclick = (e) => {
    const bouton = e.target.closest('[data-action]');
    if (!bouton) return;
    const categorie = categories.find((c) => c.id === Number(bouton.dataset.id));

    switch (bouton.dataset.action) {
      case 'enregistrer':
        return essayer(async () => {
          await api.modifierParametres({
            nom: valeur('r-nom'), adresse: valeur('r-adresse'), telephone: valeur('r-telephone'), email: valeur('r-email'),
            identifiants: valeur('r-identifiants'), mentionBancaire: valeur('r-mention'),
            tvaParDefaut: valeur('r-tva'), devise: valeur('r-devise'), decimales: valeur('r-decimales'),
            prefixeFacture: valeur('r-prefixe'), conditionsParDefaut: valeur('r-delai'),
            prefixeDevis: valeur('r-prefixe-devis'), validiteDevis: valeur('r-validite'),
            prefixeLivraison: valeur('r-prefixe-bl'), majorationVip: valeur('r-majoration-vip'),
          });
          await chargerParametres();
          const titre = document.querySelector('aside h1');
          if (titre) titre.textContent = valeur('r-nom');
          notifier('Réglages enregistrés.');
        });
      case 'reparer':
        if (!confirm('Réparer l\'application maintenant ?\n\nUne sauvegarde de sécurité sera créée, puis la structure sera vérifiée. Si la base est endommagée, la dernière sauvegarde sera restaurée.')) return;
        return essayer(async () => {
          const r = await api.reparerApplication();
          const detail = (r.actions || []).map((a) => '• ' + a).join('\n');
          alert((r.message || 'Réparation terminée.') + (detail ? '\n\n' + detail : ''));
          notifier(r.ok ? 'Réparation terminée.' : 'Réparation incomplète.');
          await rafraichir();
        });
      case 'arreter':
        if (!confirm('Arrêter BC Services ? Tous les utilisateurs connectés seront déconnectés.')) return;
        return essayer(async () => {
          await api.arreter();
          document.getElementById('racine').innerHTML = '<div class="ecran-acces"><div class="demarrage"><img src="img/icone-256.png" alt="BC Services Sarl" width="110" height="110" style="animation:none"><p>BC Services est arrêté</p><p class="aide-champ" style="font-weight:400">Vous pouvez fermer cette fenêtre.</p></div></div>';
        });
      case 'ajouter-categorie':
        return essayer(async () => {
          await api.creerCategorie(valeur('r-nouvelle-categorie'));
          notifier('Catégorie ajoutée.');
          await rafraichir();
        });
      case 'renommer': {
        const nom = prompt('Nouveau nom de la catégorie :', categorie.nom);
        if (!nom) return;
        return essayer(async () => { await api.renommerCategorie(categorie.id, nom); notifier('Catégorie renommée.'); await rafraichir(); });
      }
      case 'supprimer-categorie':
        if (!confirm(`Supprimer la catégorie « ${categorie.nom} » ?`)) return;
        return essayer(async () => { await api.supprimerCategorie(categorie.id); notifier('Catégorie supprimée.'); await rafraichir(); });
    }
  };
}
