import { api } from '../api.js';
import { montant, echapper } from '../utils.js';
import { peut } from '../session.js';
import { aller } from '../navigation.js';

/**
 * Inventaire global — vue d'ensemble du stock :
 * valeur totale, répartition par catégorie, alertes stock bas,
 * articles les plus valorisés, synthèse fournisseurs.
 */
export async function afficher(zone) {
  const [produits, categories] = await Promise.all([
    api.produits(),
    api.categories(),
  ]);
  const voirCouts = peut('articles.couts');

  const articles = produits.filter((p) => p.type === 'produit');
  const services = produits.filter((p) => p.type === 'service');

  // Valeur stock (au coût si disponible, sinon prix de vente)
  const valeur = (p) => (p.stock || 0) * (voirCouts && p.cout != null ? p.cout : (p.prix_unitaire || 0));
  const totalValeur = articles.reduce((s, p) => s + valeur(p), 0);
  const totalUnites = articles.reduce((s, p) => s + (p.stock || 0), 0);
  const alertes = articles.filter((p) => p.stock <= (p.seuil_alerte || 0));

  // Par catégorie
  const parCat = new Map();
  for (const p of articles) {
    const cat = p.categorie || 'Sans catégorie';
    if (!parCat.has(cat)) parCat.set(cat, { nom: cat, nb: 0, unites: 0, valeur: 0, alertes: 0 });
    const c = parCat.get(cat);
    c.nb += 1;
    c.unites += p.stock || 0;
    c.valeur += valeur(p);
    if (p.stock <= (p.seuil_alerte || 0)) c.alertes += 1;
  }
  const categoriesResume = [...parCat.values()].sort((a, b) => b.valeur - a.valeur);

  // Top articles par valeur de stock
  const topValeur = [...articles]
    .filter((p) => (p.stock || 0) > 0)
    .sort((a, b) => valeur(b) - valeur(a))
    .slice(0, 8);

  // Par fournisseur
  const parFour = new Map();
  for (const p of articles) {
    const nom = p.fournisseur_nom || 'Sans fournisseur';
    if (!parFour.has(nom)) parFour.set(nom, { nom, nb: 0, unites: 0, valeur: 0 });
    const f = parFour.get(nom);
    f.nb += 1;
    f.unites += p.stock || 0;
    f.valeur += valeur(p);
  }
  const fournisseursResume = [...parFour.values()].sort((a, b) => b.valeur - a.valeur).slice(0, 6);

  zone.innerHTML = `
    <div class="barre">
      <h2>Inventaire global</h2>
      <button class="btn alt" data-action="articles">Articles & inventaire</button>
      ${peut('articles.voir') ? '<button class="btn alt" data-action="comparateur">Comparateur de prix</button>' : ''}
      ${peut('stock.voir') ? '<button class="btn alt" data-action="mouvements">Mouvements</button>' : ''}
    </div>

    <div class="kpis" style="margin-bottom:18px">
      <div class="kpi">
        <b>${montant(totalValeur)}</b>
        <span>Valeur totale du stock${voirCouts ? ' (au coût)' : ''}</span>
      </div>
      <div class="kpi">
        <b>${totalUnites}</b>
        <span>Unités en stock (${articles.length} références)</span>
      </div>
      <div class="kpi ${alertes.length ? 'alerte' : ''}">
        <b>${alertes.length}</b>
        <span>Alerte${alertes.length > 1 ? 's' : ''} stock bas</span>
      </div>
      <div class="kpi">
        <b>${services.length}</b>
        <span>Service${services.length > 1 ? 's' : ''} (hors stock)</span>
      </div>
    </div>

    ${alertes.length ? `
      <h3 class="section">Stock bas — à réapprovisionner</h3>
      <div class="tableau" style="margin-bottom:18px"><table>
        <thead><tr>
          <th>Réf.</th><th>Désignation</th><th>Catégorie</th><th>Fournisseur</th>
          <th class="n">Stock</th><th class="n">Seuil</th>
          ${voirCouts ? '<th class="n">Coût unit.</th>' : ''}
        </tr></thead>
        <tbody>
          ${alertes.map((p) => `
            <tr>
              <td>${echapper(p.reference || '')}</td>
              <td><b>${echapper(p.designation)}</b></td>
              <td>${echapper(p.categorie || '')}</td>
              <td>${echapper(p.fournisseur_nom || '—')}</td>
              <td class="n negatif">${p.stock}</td>
              <td class="n">${p.seuil_alerte || 0}</td>
              ${voirCouts ? `<td class="n">${p.cout != null ? montant(p.cout) : '—'}</td>` : ''}
            </tr>`).join('')}
        </tbody>
      </table></div>
    ` : '<p class="info-tranche" style="margin-bottom:18px">Aucun article sous le seuil d\'alerte.</p>'}

    <h3 class="section">Répartition par catégorie</h3>
    <div class="tableau" style="margin-bottom:18px"><table>
      <thead><tr>
        <th>Catégorie</th>
        <th class="n">Références</th>
        <th class="n">Unités</th>
        <th class="n">Valeur stock</th>
        <th class="n">Alertes</th>
      </tr></thead>
      <tbody>
        ${categoriesResume.map((c) => `
          <tr>
            <td><b>${echapper(c.nom)}</b></td>
            <td class="n">${c.nb}</td>
            <td class="n">${c.unites}</td>
            <td class="n">${montant(c.valeur)}</td>
            <td class="n ${c.alertes ? 'negatif' : ''}">${c.alertes || '—'}</td>
          </tr>`).join('') || '<tr><td colspan="5" class="vide">Aucune catégorie.</td></tr>'}
      </tbody>
      <tfoot>
        <tr>
          <td><b>Total</b></td>
          <td class="n"><b>${articles.length}</b></td>
          <td class="n"><b>${totalUnites}</b></td>
          <td class="n"><b>${montant(totalValeur)}</b></td>
          <td class="n"><b>${alertes.length || '—'}</b></td>
        </tr>
      </tfoot>
    </table></div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
      <div>
        <h3 class="section">Top valeur en stock</h3>
        <div class="tableau"><table>
          <thead><tr>
            <th>Article</th>
            <th class="n">Stock</th>
            <th class="n">Valeur</th>
          </tr></thead>
          <tbody>
            ${topValeur.map((p) => `
              <tr>
                <td>${echapper(p.designation)}</td>
                <td class="n">${p.stock}</td>
                <td class="n">${montant(valeur(p))}</td>
              </tr>`).join('') || '<tr><td colspan="3" class="vide">Stock vide.</td></tr>'}
          </tbody>
        </table></div>
      </div>
      <div>
        <h3 class="section">Par fournisseur</h3>
        <div class="tableau"><table>
          <thead><tr>
            <th>Fournisseur</th>
            <th class="n">Réf.</th>
            <th class="n">Unités</th>
            <th class="n">Valeur</th>
          </tr></thead>
          <tbody>
            ${fournisseursResume.map((f) => `
              <tr>
                <td>${echapper(f.nom)}</td>
                <td class="n">${f.nb}</td>
                <td class="n">${f.unites}</td>
                <td class="n">${montant(f.valeur)}</td>
              </tr>`).join('') || '<tr><td colspan="4" class="vide">Aucun fournisseur.</td></tr>'}
          </tbody>
        </table></div>
      </div>
    </div>
  `;

  zone.onclick = (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    if (btn.dataset.action === 'articles') aller('articles');
    if (btn.dataset.action === 'comparateur') aller('comparateur');
    if (btn.dataset.action === 'mouvements') aller('mouvements');
  };
}
