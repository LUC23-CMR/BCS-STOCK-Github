Option Explicit

Dim shell, fso, dossier, journal, adresseFichier, erreurFichier, marqueur, i, pret, message, f, ligne, dernieresLignes, cmd, nodeCmd, pidFichier

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dossier = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = dossier
journal = dossier & "\serveur.log"
adresseFichier = dossier & "\adresse-serveur.txt"
erreurFichier = dossier & "\erreur-demarrage.txt"
marqueur = dossier & "\.raccourci-cree"
pidFichier = dossier & "\serveur.pid"

Function Accents(texte)
  texte = Replace(texte, "{e}", ChrW(233))
  texte = Replace(texte, "{g}", ChrW(232))
  texte = Replace(texte, "{a}", ChrW(224))
  texte = Replace(texte, "{c}", ChrW(231))
  texte = Replace(texte, "{u}", ChrW(249))
  texte = Replace(texte, "{o}", ChrW(244))
  Accents = texte
End Function

Function CommandeNode()
  If fso.FileExists(dossier & "\node\node.exe") Then
    CommandeNode = """" & dossier & "\node\node.exe"""
  Else
    CommandeNode = "node"
  End If
End Function

Function Lancer(commande, attendre)
  Lancer = shell.Run("cmd /s /c """ & commande & """", 0, attendre)
End Function

Function LireFichierSafe(chemin)
  On Error Resume Next
  Dim t, stream
  t = ""
  If fso.FileExists(chemin) Then
    Set stream = fso.OpenTextFile(chemin, 1, False, -1)
    If Err.Number = 0 Then
      t = stream.ReadAll
      stream.Close
    End If
  End If
  On Error GoTo 0
  LireFichierSafe = t
End Function

Function DernieresLignesLog(chemin, maxLignes)
  Dim contenu, lignes, i, debut, resultat
  contenu = LireFichierSafe(chemin)
  If contenu = "" Then
    DernieresLignesLog = ""
    Exit Function
  End If
  lignes = Split(Replace(contenu, vbCrLf, vbLf), vbLf)
  debut = UBound(lignes) - maxLignes + 1
  If debut < 0 Then debut = 0
  resultat = ""
  For i = debut To UBound(lignes)
    If Trim(lignes(i)) <> "" Then resultat = resultat & lignes(i) & vbCrLf
  Next
  DernieresLignesLog = resultat
End Function

Sub CreerRaccourci()
  Dim bureau, lien
  If fso.FileExists(marqueur) Then Exit Sub
  On Error Resume Next
  bureau = shell.SpecialFolders("Desktop")
  Set lien = shell.CreateShortcut(bureau & "\BC Services.lnk")
  lien.TargetPath = shell.ExpandEnvironmentStrings("%WINDIR%") & "\System32\wscript.exe"
  lien.Arguments = """" & WScript.ScriptFullName & """"
  lien.WorkingDirectory = dossier
  lien.IconLocation = dossier & "\frontend\img\BC_Services.ico"
  lien.Description = "BC Services"
  lien.Save
  If Err.Number = 0 Then
    Set f = fso.CreateTextFile(marqueur, True)
    f.Close
    fso.GetFile(marqueur).Attributes = 2
  End If
  On Error GoTo 0
End Sub

' --- Vérification Node.js ---
If Lancer(CommandeNode() & " -v >nul 2>nul", True) <> 0 Then
  MsgBox Accents("Le programme Node.js n'est pas install{e} sur cet ordinateur.") & vbCrLf & vbCrLf & _
    Accents("Il est n{e}cessaire une seule fois. La page de t{e}l{e}chargement va s'ouvrir : choisissez la version LTS, installez-la, puis relancez BC Services."), vbExclamation, "BC Services"
  shell.Run "https://nodejs.org/fr/download"
  WScript.Quit 1
End If

' --- Nettoyage des fichiers de signalisation ---
On Error Resume Next
If fso.FileExists(journal) Then
  If fso.GetFile(journal).Size > 2000000 Then fso.DeleteFile journal, True
End If
If fso.FileExists(adresseFichier) Then fso.DeleteFile adresseFichier, True
If fso.FileExists(erreurFichier) Then fso.DeleteFile erreurFichier, True
If fso.FileExists(pidFichier) Then fso.DeleteFile pidFichier, True
On Error GoTo 0

' --- Lancement du serveur (chemin absolu + redirection robuste) ---
nodeCmd = CommandeNode()
' On force le répertoire de travail et on utilise start /b pour un lancement plus fiable sous Windows
cmd = "cd /d """ & dossier & """ && " & nodeCmd & " backend\server.js >> """ & journal & """ 2>&1"
Lancer cmd, False

' --- Attente allongée (jusqu'à ~75 secondes) ---
pret = False
For i = 1 To 150
  WScript.Sleep 500
  If fso.FileExists(adresseFichier) Then
    pret = True
    Exit For
  End If
  If fso.FileExists(erreurFichier) Then Exit For
Next

If Not pret Then
  message = ""
  WScript.Sleep 500
  message = Trim(LireFichierSafe(erreurFichier))
  If message = "" Then
    dernieresLignes = DernieresLignesLog(journal, 12)
    If dernieresLignes <> "" Then
      message = Accents("Le serveur ne r{e}pond pas.") & vbCrLf & vbCrLf & _
                Accents("Derniers messages techniques :") & vbCrLf & vbCrLf & dernieresLignes
    Else
      message = Accents("Le serveur ne r{e}pond pas. Consultez le fichier serveur.log.")
    End If
  End If
  MsgBox Accents("BC Services n'a pas pu d{e}marrer.") & vbCrLf & vbCrLf & message & vbCrLf & vbCrLf & _
         Accents("Essayez « Diagnostic - Demarrer avec fenetre.bat » pour voir l'erreur complète.") & vbCrLf & _
         Accents("Contactez votre informaticien si le problème continue."), vbCritical, "BC Services"
  WScript.Quit 1
End If

CreerRaccourci
' Le serveur ouvre lui-même la fenêtre (configuration ouvrirNavigateur = true)
WScript.Quit 0
