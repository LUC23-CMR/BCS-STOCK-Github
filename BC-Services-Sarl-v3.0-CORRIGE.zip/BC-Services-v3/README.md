# BC Services Sarl — Devis, facturation et gestion de stock

Application web professionnelle (inspirée d'Odoo) pour **BC Services Sarl** :
ventes, facturation, inventaire, comparateur de prix fournisseurs et inventaire global.

- Comptes, rôles et droits gérés par un administrateur central
- Paiement par tranches
- Base de données au format Excel (`database/BC_Services_Base.xlsx`)
- Installateur graphique Windows
- Documentation utilisateur : `LISEZ-MOI.txt`

Le code ne contient volontairement aucun commentaire : toute la documentation est ici et dans `LISEZ-MOI.txt`.

---

## Installation (entreprise)

| Fichier | Rôle |
|---------|------|
| **Lancer l'installateur.bat** | Lance l'assistant graphique (recommandé) |
| **Installer BC Services.ps1** | Assistant PowerShell (5 étapes) |

L'installateur :
1. Présente les modules
2. Demande le dossier d'installation
3. Vérifie Node.js 18+ (lien LTS si absent)
4. Copie les fichiers et crée les raccourcis Bureau + Menu Démarrer
5. Propose de lancer l'application

---

## Lancer l'application

**Utilisateur (Windows)** : double-clic sur `Demarrer BC Services.vbs`.  
Aucune fenêtre de commande : le serveur démarre en arrière-plan, l'application s'ouvre dans sa propre fenêtre (Edge ou Chrome en mode application, logo BC Services).

| Fichier | Rôle |
|---------|------|
| `Demarrer BC Services.vbs` | Démarre sans fenêtre, attend la disponibilité, gère les erreurs, crée le raccourci |
| `Arreter BC Services.vbs` | Arrêt propre (`POST /api/arret`) |
| `Diagnostic - Demarrer avec fenetre.bat` | Console visible (diagnostic) |
| `serveur.log` | Sortie du serveur |

Si Node.js n'est pas installé, le `.vbs` l'explique et ouvre la page de téléchargement.  
Alternative : placer `node.exe` dans un dossier `node/` à côté du `.vbs`.

**Développeur** : Node.js 18+, puis :

| Commande | Effet |
|----------|-------|
| `npm start` | Lance l'application et ouvre la fenêtre |
| `npm run dev` | Relance à chaque modification (sans fenêtre) |
| `npm test` | Tests (classeur temporaire) |
| `npm run sauvegarde` | Copie le classeur dans `sauvegardes/` |
| `npm run motdepasse -- identifiant` | Réinitialise un mot de passe (secours) |

### Comportement du démarrage
- Déjà lancé : ouverture sur l'instance existante.
- Port occupé : port suivant utilisé.
- Signal de présence toutes les 30 s. Sans signal pendant `arretAutomatiqueMinutes` (10 par défaut), arrêt automatique. Mettre `0` pour un poste permanent.

---

## Modules

| Module | Description |
|--------|-------------|
| **Devis** | Brouillon → Envoyé → Accepté / Refusé → Facturé. Aucun effet stock. Tranches de paiement. |
| **Factures** | Brouillon → Validée → Payée. Validation = sortie de stock. |
| **Clients** | Standard / VIP (majoration configurable). |
| **Inventaire global** | Valeur stock, alertes, répartition par catégorie, top valeur, synthèse fournisseurs. |
| **Comparateur de prix** | Coûts, prix de vente, marges par fournisseur et catégorie. |
| **Articles & stock** | Catalogue, fournisseurs, réceptions, sorties, inventaire physique. |
| **Livraisons** | Bordereaux liés aux documents. |
| **Administration** | Utilisateurs, rôles, journal, réglages. |

---

## Rôles et droits

| Rôle | Périmètre |
|------|-----------|
| Administrateur | Tout (système) |
| Gestionnaire | Facturation, clients, stock, rapports |
| Comptable | Validation factures, paiements |
| Commercial | Ses devis et brouillons |
| Magasinier | Articles, coûts, mouvements |
| Lecture seule | Consultation seule |

Les droits sont vérifiés côté serveur à chaque requête. Un changement de rôle s'applique immédiatement. Il reste toujours au moins un administrateur actif.

---

## Sécurité

| Mesure | Détail |
|--------|--------|
| Mots de passe | Empreinte scrypt salée, 8 caractères minimum |
| Session | Cookie HttpOnly + SameSite=Strict, expiration configurable |
| Force brute | 5 échecs → blocage 5 minutes |
| Origine | Contrôle Origin, CSP, X-Frame-Options |
| Export Excel | Exclut Utilisateurs, Roles, Journal |
| Journal | Connexions, créations, validations, paiements, exports… |

**Limites** : HTTP (réseau de confiance) ; le fichier Excel doit être protégé par les droits Windows ; sessions en mémoire (redémarrage = déconnexion).

---

## Accès réseau

Par défaut (`"hote": ""`), écoute sur le réseau local.  
`"hote": "127.0.0.1"` limite à la machine.  
Manifeste et icônes fournis pour « Installer comme application » (Edge / Chrome).

---

## Cycles de vie

```
Devis    : brouillon → envoyé → accepté (ou refusé) → facturé
Facture  : brouillon → validée → payée / partielle (ou annulée)
```

---

## Configuration

Fichier `configuration.json` :

| Clé | Défaut | Rôle |
|-----|--------|------|
| `fichierExcel` | `database/BC_Services_Base.xlsx` | Classeur |
| `port` | `3000` | Port HTTP |
| `hote` | `""` | Interface d'écoute |
| `ouvrirNavigateur` | `true` | Ouvre la fenêtre au démarrage |
| `fenetreApplication` | `true` | Mode application (sans barre de navigation) |
| `arretAutomatiqueMinutes` | `10` | Arrêt sans présence (0 = jamais) |
| `sauvegardeAuto` | `true` | Sauvegarde quotidienne |
| `dureeSessionHeures` | `8` | Durée de session inactive |

---

## Structure du projet

```
bc-services/
├── Lancer l'installateur.bat
├── Installer BC Services.ps1
├── Demarrer BC Services.vbs
├── Arreter BC Services.vbs
├── LISEZ-MOI.txt              ← guide utilisateur
├── README.md                  ← ce fichier
├── configuration.json
├── package.json
├── backend/                   ← serveur Node
├── frontend/                  ← interface web
├── database/                  ← Excel + moteur
├── outils/                    ← sauvegarde, réparation, mot de passe
└── tests/
```

---

## Métiers couverts

Vidéosurveillance • Contrôle d'accès • Alarme incendie • Installation solaire  
Électricité bâtiment • Réseau informatique • Alarme intrusion • Matériel informatique
